test_that("title is shiny.tag.list class", {
  expect_s3_class(
    object = utils_title(),
    class = c("shiny.tag.list", "list"),
    exact = TRUE
  )
})

test_that("title length is > 0", {
  expect_gt(object = length(utils_title()), expected = 0)
})
