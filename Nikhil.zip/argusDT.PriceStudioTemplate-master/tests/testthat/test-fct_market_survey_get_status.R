test_that("returns correct counts", {
  # Create mock dt_pivot
  dt_pivot <- data.table::as.data.table(tibble::tribble(
    ~REGION  , ~MARKET  , ~QUOTE_ID , ~SOURCE , ~LOW , ~HIGH , ~MID , ~TRADER_ID , ~PRICE_CATEGORY_ID , ~COMM_METHOD_ID , ~COMM_CONTACT_NAME , ~PORT_ID , ~DELIVERY_PERIOD_ID , ~DELIVERY_YEAR , ~NOTES , ~EDITED ,
    "Europe" , "Timing" ,         1 , "MS"    ,    1 ,     2 , 1.5  ,        100 , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Europe" , "Timing" ,         1 , "MS"    , NA   , NA    , NA   , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Europe" , "Timing" ,         2 , "MS"    ,    2 ,     3 , 2.5  , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Europe" , "Timing" ,         2 , "NEW"   , NA   , NA    , NA   ,        200 , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Europe" , "Timing" ,         3 , "NEW"   , NA   , NA    , NA   , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Europe" , "Timing" ,         3 , "NEW"   , NA   , NA    , NA   , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE
  ))

  status <- fct_market_survey_get_status(
    dt_pivot = dt_pivot,
    dt_available_files = NULL,
    region = "Europe",
    market = "Timing",
    report_date = lubridate::today()
  )

  # Total tables = 3 unique QUOTE_IDs
  expect_equal(status$tables_total, 3)

  # Saved tables = 2 QUOTE_IDs with SOURCE == "MS"
  expect_equal(status$tables_saved, 2)

  # Total rows = 6
  expect_equal(status$rows_total, 6)

  # Saved rows = 3 with SOURCE == "MS"
  expect_equal(status$rows_saved, 3)

  # Updated total = 6 (all rows)
  expect_equal(status$updated_total, 6)

  # Updated count = 3 rows with values (row 1, 3 have prices; row 4 has TRADER_ID)
  expect_equal(status$updated_count, 3)

  # Files count = 0
  expect_equal(status$files_count, 0)
})

test_that("handles empty dt_pivot", {
  status <- fct_market_survey_get_status(
    dt_pivot = data.table::data.table(),
    dt_available_files = NULL,
    region = "Europe",
    market = "Timing",
    report_date = lubridate::today()
  )

  expect_equal(status$tables_total, 0)
  expect_equal(status$tables_saved, 0)
  expect_equal(status$rows_total, 0)
  expect_equal(status$rows_saved, 0)
  expect_equal(status$updated_total, 0)
  expect_equal(status$updated_count, 0)
  expect_equal(status$files_count, 0)
})

test_that("handles NULL dt_pivot", {
  status <- fct_market_survey_get_status(
    dt_pivot = NULL,
    dt_available_files = NULL,
    region = "Europe",
    market = "Timing",
    report_date = lubridate::today()
  )

  expect_equal(status$tables_total, 0)
  expect_equal(status$tables_saved, 0)
  expect_equal(status$rows_total, 0)
  expect_equal(status$rows_saved, 0)
  expect_equal(status$updated_total, 0)
  expect_equal(status$updated_count, 0)
  expect_equal(status$files_count, 0)
})

test_that("counts files correctly", {
  dt_pivot <- data.table::as.data.table(tibble::tribble(
    ~REGION  , ~MARKET  , ~QUOTE_ID , ~SOURCE , ~LOW     , ~HIGH    , ~MID     , ~TRADER_ID , ~PRICE_CATEGORY_ID , ~COMM_METHOD_ID , ~COMM_CONTACT_NAME , ~PORT_ID , ~DELIVERY_PERIOD_ID , ~DELIVERY_YEAR , ~NOTES , ~EDITED ,
    "Europe" , "Timing" ,         1 , "NEW"   , NA_real_ , NA_real_ , NA_real_ , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE
  ))

  dt_files <- data.table::data.table(
    Key = c("path/file1.pdf", "path/file2.xlsx", "path/file3.docx")
  )

  status <- fct_market_survey_get_status(
    dt_pivot = dt_pivot,
    dt_available_files = dt_files,
    region = "Europe",
    market = "Timing",
    report_date = lubridate::today()
  )

  expect_equal(status$files_count, 3)
})

test_that("filters by region and market", {
  dt_pivot <- data.table::as.data.table(tibble::tribble(
    ~REGION  , ~MARKET  , ~QUOTE_ID , ~SOURCE , ~LOW , ~HIGH , ~MID , ~TRADER_ID , ~PRICE_CATEGORY_ID , ~COMM_METHOD_ID , ~COMM_CONTACT_NAME , ~PORT_ID , ~DELIVERY_PERIOD_ID , ~DELIVERY_YEAR , ~NOTES , ~EDITED ,
    "Europe" , "Timing" ,         1 , "MS"    ,    1 ,     2 , 1.5  , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Europe" , "Other"  ,         2 , "MS"    ,    2 ,     3 , 2.5  , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Asia"   , "Timing" ,         3 , "MS"    ,    3 ,     4 , 3.5  , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE   ,
    "Asia"   , "Timing" ,         4 , "MS"    ,    4 ,     5 , 4.5  , NA         , NA                 , NA              , NA                 , NA       , NA                  , NA             , NA     , FALSE
  ))

  status <- fct_market_survey_get_status(
    dt_pivot = dt_pivot,
    dt_available_files = NULL,
    region = "Europe",
    market = "Timing",
    report_date = lubridate::today()
  )

  # Only 1 row matches Europe + Timing
  expect_equal(status$rows_total, 1)
  expect_equal(status$rows_saved, 1)
  expect_equal(status$updated_count, 1)
})
