test_that("returns locked when script already has a fresh lock", {
  withr::local_options(list())

  script_name <- "my_script"
  options(script.locks = list(my_script = list(user_id = "other_user", time = Sys.time())))

  res <- fct_run_sched_script(
    db_env = "dev",
    selected_script_name = script_name,
    selected_script_guid = "GUID",
    user_id = "me"
  )

  expect_type(res, "list")
  expect_equal(res$script_name, script_name)
  expect_equal(res$status, "locked")
  expect_match(res$message, "already running")
  expect_equal(res$locked_by, "other_user")
  expect_true(inherits(res$locked_at, "POSIXt"))
})

test_that("overwrites stale lock and triggers script successfully", {
  withr::local_options(list())

  script_name <- "stale_script"
  stale_time <- Sys.time() - (60 * 11) # 11 minutes ago
  options(script.locks = list(stale_script = list(user_id = "old_user", time = stale_time)))

  # monkey-patch the external calls
  assignInNamespace(
    "fct_get_secret",
    function(secret_path) list("x", "y", "FAKE_API_KEY"),
    ns = "argusDT.PriceStudioMain"
  )
  assignInNamespace(
    "connect",
    function(server, api_key) list(server = server, api_key = api_key),
    ns = "connectapi"
  )
  assignInNamespace("content_item", function(client, guid) list(guid = guid), ns = "connectapi")
  assignInNamespace(
    "content_render",
    function(content) list(task_id = "TASK-123"),
    ns = "connectapi"
  )

  res <- fct_run_sched_script(
    db_env = "dev",
    selected_script_name = script_name,
    selected_script_guid = "GUID-123",
    user_id = "new_user"
  )

  expect_equal(res$status, "triggered")
  expect_equal(res$script_name, script_name)
  expect_equal(res$task_id, "TASK-123")
  expect_match(res$message, "triggered successfully")
})

test_that("on connect error the function returns error and removes lock", {
  withr::local_options(list())

  script_name <- "error_script"
  options(script.locks = list())

  assignInNamespace(
    "fct_get_secret",
    function(secret_path) list("x", "y", "FAKE_API_KEY"),
    ns = "argusDT.PriceStudioMain"
  )
  assignInNamespace(
    "connect",
    function(server, api_key) list(server = server, api_key = api_key),
    ns = "connectapi"
  )
  assignInNamespace(
    "content_item",
    function(client, guid) stop("connectapi failure"),
    ns = "connectapi"
  )

  res <- fct_run_sched_script(
    db_env = "dev",
    selected_script_name = script_name,
    selected_script_guid = "GUID-ERR",
    user_id = "user_err"
  )

  expect_true(is.null(getOption("script.locks")[[script_name]]))
})
