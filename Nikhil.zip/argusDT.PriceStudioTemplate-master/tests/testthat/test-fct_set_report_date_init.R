dates <- seq(lubridate::ymd('2024-06-01'), lubridate::ymd('2024-06-15'), by = '1 day')

###---Daily------------------------------------------------------------------###

frequency <- "Daily"
publish_day <- 0

lapply(dates, function(x) {
  test_that(paste("fct_set_report_date_init (", frequency, "):", x), {
    expect_equal(
      fct_set_report_date_init(today = x, frequency = frequency, publish_day = publish_day),
      expected = x
    )
  })
})

###---Weekly-----------------------------------------------------------------###

frequency <- "Weekly"
publish_day <- c(1:7)

all_vectors <- expand.grid(a = dates, b = frequency, c = publish_day)

mapply(
  function(x, y, z) {
    test_that(paste("fct_set_report_date_init (", z, "):", x), {
      expect_equal(
        fct_set_report_date_init(
          today = x,
          frequency = as.character(y),
          publish_day = as.numeric(z)
        ),
        expected = lubridate::ceiling_date(
          x,
          unit = "week",
          week_start = as.numeric(z),
          change_on_boundary = FALSE
        )
      )
    })
  },
  all_vectors$a,
  all_vectors$b,
  all_vectors$c
)

###---Monthly----------------------------------------------------------------###

frequency <- "Monthly"
publish_day <- 1

lapply(dates, function(x) {
  test_that(paste("fct_set_report_date_init (", frequency, "):", x), {
    expect_equal(
      fct_set_report_date_init(today = x, frequency = frequency, publish_day = publish_day),
      expected = lubridate::ceiling_date(x, unit = "month", change_on_boundary = FALSE) -
        1 +
        publish_day
    )
  })
})

###---Fortnightly------------------------------------------------------------###

frequency <- "Fortnightly"
publish_day <- 5
date <- as.Date("2024-06-20")

test_that(paste("fct_set_report_date_init (", frequency, "):", date), {
  expect_equal(
    fct_set_report_date_init(today = date, frequency = frequency, publish_day = publish_day),
    expected = as.Date("2024-06-21")
  )
})

###---Fortnightly------------------------------------------------------------###

frequency <- "Fortnightly"
publish_day <- 12
date <- as.Date("2024-06-20")

test_that(paste("fct_set_report_date_init (", frequency, "):", date), {
  expect_equal(
    fct_set_report_date_init(today = date, frequency = frequency, publish_day = publish_day),
    expected = as.Date("2024-06-28")
  )
})

###---Quarterly--------------------------------------------------------------###

frequency <- "Quarterly"
publish_day <- 12
date <- as.Date("2024-06-20")

test_that(paste("fct_set_report_date_init (", frequency, "):", date), {
  expect_equal(
    fct_set_report_date_init(today = date, frequency = frequency, publish_day = publish_day),
    expected = as.Date("2024-07-12")
  )
})

###---Annual-----------------------------------------------------------------###

frequency <- "Annual"
publish_day <- 12
date <- as.Date("2024-06-20")

test_that(paste("fct_set_report_date_init (", frequency, "):", date), {
  expect_equal(
    fct_set_report_date_init(today = date, frequency = frequency, publish_day = publish_day),
    expected = as.Date("2024-06-20")
  )
})

###---Biannual---------------------------------------------------------------###

frequency <- "Biannual"
publish_day <- 12
date <- as.Date("2024-06-20")

test_that(paste("fct_set_report_date_init (", frequency, "):", date), {
  expect_equal(
    fct_set_report_date_init(today = date, frequency = frequency, publish_day = publish_day),
    expected = as.Date("2024-06-20")
  )
})

###---Twice weekly-----------------------------------------------------------###

frequency <- "Twice weekly"
publish_day <- 12
date <- as.Date("2024-06-20")

test_that(paste("fct_set_report_date_init (", frequency, "):", date), {
  expect_equal(
    fct_set_report_date_init(today = date, frequency = frequency, publish_day = publish_day),
    expected = as.Date("2024-06-20")
  )
})

###---Hourly-----------------------------------------------------------------###

frequency <- "Hourly"
publish_day <- 12
date <- as.Date("2024-06-20")

test_that(paste("fct_set_report_date_init (", frequency, "):", date), {
  expect_equal(
    fct_set_report_date_init(today = date, frequency = frequency, publish_day = publish_day),
    expected = as.Date("2024-06-20")
  )
})

###---Daily with app end date------------------------------------------------###

frequency <- "Daily"
publish_day <- 0

lapply(dates, function(x) {
  test_that(paste("fct_set_report_date_init (", frequency, "):", x), {
    expect_equal(
      fct_set_report_date_init(
        today = x,
        frequency = frequency,
        publish_day = publish_day,
        app_end_date = as.Date("2024-05-15")
      ),
      expected = as.Date("2024-05-15")
    )
  })
})

###---Weekly with app end date ----------------------------------------------###

frequency <- "Weekly"
publish_day <- c(1:7)

all_vectors <- expand.grid(a = dates, b = frequency, c = publish_day)

mapply(
  function(x, y, z) {
    test_that(paste("fct_set_report_date_init (", z, "):", x), {
      expect_equal(
        fct_set_report_date_init(
          today = x,
          frequency = as.character(y),
          publish_day = as.numeric(z),
          app_end_date = as.Date("2024-05-15")
        ),
        expected = as.Date("2024-05-15")
      )
    })
  },
  all_vectors$a,
  all_vectors$b,
  all_vectors$c
)

###--- App end date as NA -------------------------------------------------###

frequency <- "Daily"
publish_day <- 0

lapply(dates, function(x) {
  test_that(paste("fct_set_report_date_init (", frequency, "):", x), {
    expect_equal(
      fct_set_report_date_init(
        today = x,
        frequency = frequency,
        publish_day = publish_day,
        app_end_date = NA
      ),
      expected = x
    )
  })
})
