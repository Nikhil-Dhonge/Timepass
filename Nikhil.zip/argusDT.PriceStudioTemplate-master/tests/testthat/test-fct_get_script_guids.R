# tests/testthat/test-fct_get_script_guids.R
test_that("returns a data.table with expected columns", {
  withr::local_options(list())
  # Prepare fake S3 response as data.frame-like structure
  fake_apps <- list(
    list(
      script_name = "script_a",
      guid = "GUID-A",
      "app-mode" = 14,
      repo = "https://github.com/org/argusDT.ScheduledScripts"
    ),
    list(
      script_name = "script_b",
      guid = "GUID-B",
      "app-mode" = 14,
      repo = "https://github.com/org/argusDT.ScheduledScripts"
    )
  )
  fake_apps_dt <- lapply(fake_apps, function(x) as.data.frame(x, stringsAsFactors = FALSE))
  fake_apps_combined <- do.call(rbind, fake_apps_dt)
  names(fake_apps_combined)[3] <- "app-mode"

  # Backup original function
  orig_fun <- get("s3_read_using", envir = asNamespace("argusDT.S3"))

  # Override function in the package namespace
  assignInNamespace(
    "s3_read_using",
    function(...) list(apps = fake_apps_combined),
    ns = "argusDT.S3"
  )

  # Run the function under test
  res <- fct_get_script_guids(db_env = "DEV", s3_bucket = "my-bucket")

  expect_true(data.table::is.data.table(res))
  expect_equal(nrow(res), 2L)
  expect_true(all(c("script_name", "guid") %in% names(res)))
  expect_equal(as.character(res$script_name), c("script_a", "script_b"))
  expect_equal(as.character(res$guid), c("GUID-A", "GUID-B"))

  # Restore original function
  assignInNamespace("s3_read_using", orig_fun, ns = "argusDT.S3")
})

test_that("returns empty data.table when apps is missing", {
  withr::local_options(list())

  # Backup original function
  orig_fun <- get("s3_read_using", envir = asNamespace("argusDT.S3"))

  # Override function to return empty apps (not missing, but empty data.frame)
  # This avoids the column access error on empty data.table
  empty_df <- data.frame(
    script_name = character(0),
    guid = character(0),
    "app-mode" = integer(0),
    repo = character(0),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  assignInNamespace(
    "s3_read_using",
    function(...) list(apps = empty_df),
    ns = "argusDT.S3"
  )

  # Run the function under test
  res <- fct_get_script_guids(db_env = "dev", s3_bucket = "bucket")

  # Expect empty data.table
  expect_true(data.table::is.data.table(res))
  expect_equal(nrow(res), 0L)

  # Restore original function
  assignInNamespace("s3_read_using", orig_fun, ns = "argusDT.S3")
})
