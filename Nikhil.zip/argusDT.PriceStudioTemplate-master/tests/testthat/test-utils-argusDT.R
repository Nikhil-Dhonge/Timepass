# log_info ----
test_that("raises a message", {
  session <- shiny::MockShinySession$new()
  session$userData <- list(username = "test.user", sid = 9999)

  expect_message(log_info())
  expect_message(log_info("test", level = 2))
  expect_message(log_info("test1", "test2", sep = "\t", level = 2))
  expect_message(log_info("test1", "test2", sep = "\t", collapse = ",", level = 2))
  expect_message(log_info(c("test1", "test2"), sep = "\t", collapse = ",", level = 2))

  expect_message(log_info(
    c("test1", "test2"),
    sep = "\t",
    collapse = ",",
    level = 2,
    session = session
  ))
})

test_that("returns NULL", {
  session <- shiny::MockShinySession$new()

  expect_type(log_info(), type = "NULL")
  expect_type(log_info("test", level = 2), type = "NULL")
  expect_type(log_info("test1", "test2", sep = "\t", level = 2), type = "NULL")

  expect_type(
    log_info("test1", "test2", sep = "\t", level = 2, session = session),
    type = "NULL"
  )
})

# log_warn ----
test_that("raises a warning", {
  session <- shiny::MockShinySession$new()
  session$userData <- list(username = "test.user", sid = 9999)

  expect_warning(log_warn())
  expect_warning(log_warn("test"))
  expect_warning(log_warn("test1", "test2", sep = "\t"))
  expect_warning(log_warn("test1", "test2", sep = "\t", session = session))
  expect_warning(log_warn("test1", "test2", sep = "\t", session = session, prompt = TRUE))

  expect_warning(log_warn(
    "test1",
    "test2",
    sep = "\t",
    session = session,
    prompt = TRUE,
    title = "test"
  ))

  expect_warning(log_warn(
    "test1",
    "test2",
    sep = "\t",
    session = session,
    prompt = TRUE,
    title = "test",
    type = "warning"
  ))
})

test_that("returns the message", {
  expect_warning(expect_type(log_warn(), type = "character"))
  expect_warning(log_warn("test"), regexp = "test")
})

# log_change ----
test_that("raises a message", {
  session <- shiny::MockShinySession$new()
  session$userData <- list(username = "test.user", sid = 9999)

  # test all arguments
  expect_message(log_change(id = "id", from = "test1", to = "test2"))
  expect_message(log_change(id = "id", from = "test1", to = "test2", level = 2))

  expect_message(log_change(
    id = "id",
    from = "test1",
    to = "test2",
    level = 2,
    session = session
  ))
})

test_that("returns NULL", {
  session <- shiny::MockShinySession$new()

  expect_type(
    log_change(id = "id", from = "test1", to = "test2", session = session),
    type = "NULL"
  )
})

test_that("fails with missing arguments", {
  expect_error(log_change(), regexp = "argument \".+\" is missing, with no default")

  expect_error(
    log_change(id = "id1"),
    regexp = "argument \".+\" is missing, with no default"
  )

  expect_error(
    log_change(id = "id1", from = "test1"),
    regexp = "argument \".+\" is missing, with no default"
  )

  expect_error(
    log_change(id = "id1", to = "test1"),
    regexp = "argument \".+\" is missing, with no default"
  )

  expect_error(
    log_change(from = "test1", to = "test2"),
    regexp = "argument \".+\" is missing, with no default"
  )
})

# argus_round ----
test_that("rounds to the specifed digits", {
  expect_identical(object = argus_round(1.49), expected = 1)
  expect_identical(object = argus_round(0.5), expected = 1)
  expect_identical(object = argus_round(1.5), expected = 2)
  expect_identical(object = argus_round(-0.5), expected = -1)
  expect_identical(object = argus_round(-1.5), expected = -2)
  expect_identical(object = argus_round(c(0.5, 1.1)), expected = c(1, 1))

  expect_identical(
    object = argus_round(data.table::data.table(A = c(0.5, 1.1), B = c(1.1, 0.5))),
    expected = data.table::data.table(A = c(1, 1), B = c(1, 1))
  )

  digits <- getOption("digits")
  options(digits = 15)

  expect_identical(object = argus_round(pi, digits = 14), expected = 3.14159265358979)
  expect_identical(object = argus_round(pi, digits = 7), expected = 3.1415927)
  expect_identical(object = argus_round(pi, digits = 3), expected = 3.142)
  expect_identical(object = argus_round(-pi, digits = 3), expected = -3.142)

  # reset options
  options(digits = digits)
})

test_that("rounds to multiples between 0 and 1", {
  expect_identical(object = argus_round(3.14, multiple = 0.5), expected = 3)
  expect_identical(object = argus_round(-3.14, multiple = 0.5), expected = -3)
  expect_identical(object = argus_round(7.25, multiple = 0.25), expected = 7.25)
  expect_identical(object = argus_round(0.123, multiple = 0.001), expected = 0.123)
  expect_identical(object = argus_round(-0.1249, multiple = 0.001), expected = -0.125)
  expect_identical(object = argus_round(-7.4, multiple = 0.25), expected = -7.5)
})

test_that("rounds to multiples greater than 1", {
  expect_identical(object = argus_round(13, multiple = 5), expected = 15)
  expect_identical(object = argus_round(8, multiple = 2), expected = 8)
  expect_identical(object = argus_round(-7, multiple = 3), expected = -6)
  expect_identical(object = argus_round(20, multiple = 3), expected = 21)
  expect_identical(object = argus_round(3.14, multiple = 10), expected = 0)
  expect_identical(object = argus_round(31.4, multiple = 10), expected = 30)
  expect_identical(object = argus_round(-3, multiple = 2), expected = -4)
  expect_identical(object = argus_round(-2.999, multiple = 2), expected = -2)
})

test_that("handles edge cases", {
  expect_identical(object = argus_round(0), expected = 0)
  expect_identical(object = argus_round(1000), expected = 1000)
  expect_identical(object = argus_round(-1000), expected = -1000)
})

test_that("warns with multiple of 0", {
  expect_warning(argus_round(10, multiple = 0), regexp = "`multiple` cannot be 0")
  expect_warning(argus_round(-10, multiple = 0), regexp = "`multiple` cannot be 0")
})

test_that("fails for characters", {
  expect_error(
    object = argus_round("1.1"),
    regexp = "non-numeric argument to mathematical function"
  )

  expect_error(
    object = argus_round(c("1.1", "0.5")),
    regexp = "non-numeric argument to mathematical function"
  )
})

test_that("warns if multiple digits is supplied", {
  expect_warning(
    result <- argus_round(3.14, digits = 2, multiple = 0.5),
    "argus_round must have `digits` = 0 if a multiple is supplied",
    info = "Failed: Warning not issued when both `digits` and `multiple` were supplied."
  )
  expect_identical(result, NA_real_)

  expect_warning(
    result <- argus_round(-3.14, digits = 3, multiple = 1),
    "argus_round must have `digits` = 0 if a multiple is supplied",
    info = "Failed: Warning not issued when both `digits` and `multiple` were supplied."
  )
  expect_identical(result, NA_real_)

  expect_warning(
    result <- argus_round(5.67, digits = 1, multiple = 2),
    "argus_round must have `digits` = 0 if a multiple is supplied",
    info = "Failed: Warning not issued when both `digits` and `multiple` were supplied."
  )
  expect_identical(result, NA_real_)
})

# is_truthy ----
test_that("returns logical", {
  expect_true(is_truthy(TRUE))
  expect_true(is_truthy("TRUE"))
  expect_true(is_truthy("FALSE"))
  expect_true(is_truthy(list()))
  expect_true(is_truthy(1))
  expect_true(is_truthy(0))

  expect_false(is_truthy(FALSE))
  expect_false(is_truthy(NULL))
  expect_false(is_truthy(NA))
  expect_false(is_truthy(""))
  expect_false(is_truthy(c()))
  expect_false(is_truthy(structure("a", class = "try-error")))
})

# get_ns ----
test_that("errors when ns is missing", {
  expect_error(get_ns())
})

test_that("errors when ns is not a function", {
  err_msg <- "not a function"
  expect_error(get_ns(ns = "test"), regexp = err_msg)
  expect_error(get_ns(ns = 8), regexp = err_msg)
  expect_error(get_ns(ns = NULL), regexp = err_msg)
})

test_that("returns correct namespace", {
  id <- "test"
  ns <- shiny::NS(id)
  expect_identical(get_ns(ns = ns), expected = id)
})

# ifnull ----
test_that("returns first argument when not NULL", {
  expect_identical(ifnull(1, 2), expected = 1)
  expect_identical(ifnull("a", "b"), expected = "a")
  expect_identical(ifnull(TRUE, FALSE), expected = TRUE)
  expect_identical(ifnull(list(1, 2), list(3, 4)), expected = list(1, 2))
})

test_that("returns second argument when first is NULL", {
  expect_identical(ifnull(NULL, 2), expected = 2)
  expect_identical(ifnull(NULL, "b"), expected = "b")
  expect_identical(ifnull(NULL, FALSE), expected = FALSE)
  expect_identical(ifnull(NULL, list(3, 4)), expected = list(3, 4))
})
