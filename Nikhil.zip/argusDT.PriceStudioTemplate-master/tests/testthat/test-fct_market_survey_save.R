test_that("errors on constraint violation", {
  # integrity constraint - quote_pricetype_id set to 0

  dt <- readRDS(test_path("data.tables", "dt_market_survey.rds"))

  expect_equal(
    fct_market_survey_save(
      dt_market_survey = dt,
      username = "test.test",
      report_date = lubridate::date("2024-02-27"),
      application_id = get_config("application_id"),
      market = "Timing",
      timezone = "Europe/London",
      process_id = 1,
      session_id = 2,
      db_env = "DEV",
      connection = NULL
    ),
    expected = -99
  )
})

test_that("works with empty dt", {
  # integrity constraint - quote_pricetype_id set to 0

  dt <- readRDS(test_path("data.tables", "dt_market_survey.rds"))

  expect_message(
    fct_market_survey_save(
      dt_market_survey = dt[0],
      username = "test.test",
      report_date = lubridate::date("2024-02-27"),
      application_id = get_config("application_id"),
      market = "Timing",
      timezone = "Europe/London",
      process_id = 1,
      session_id = 2,
      db_env = "DEV",
      connection = NULL
    ),
    regexp = "Market Survey: No changes to save."
  )
})
