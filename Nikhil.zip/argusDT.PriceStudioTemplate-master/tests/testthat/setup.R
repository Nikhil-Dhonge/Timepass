withr::local_envvar(list(GOLEM_CONFIG_ACTIVE = "dev"), .local_envir = testthat::teardown_env())
