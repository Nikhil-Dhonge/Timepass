argusDT.PriceStudioTemplate
================

<!-- README.md is generated from README.Rmd. Please edit that file -->

The Price Studio app for commodity assessments

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

<!-- Set code chunk options -->

<!-- Get code coverage -->

<!-- Show code coverage report -->

------------------------------------------------------------------------

**Test coverage:** 3.7% *(as of 02 December, 2025)*

```
#> argusDT.PriceStudioTemplate Coverage: 3.70%
#> R/app_server.R: 0.00%
#> R/app_ui.R: 0.00%
#> R/fct_calc_expected_dates.R: 0.00%
#> R/fct_check_staged_exrates.R: 0.00%
#> R/fct_clear_tables.R: 0.00%
#> R/fct_create_env_vars.R: 0.00%
#> R/fct_create_price_components_tbls.R: 0.00%
#> R/fct_create_prices_table.R: 0.00%
#> R/fct_js_deal_rowformat.R: 0.00%
#> R/fct_js_tblr_mktsvy_format.R: 0.00%
#> R/fct_js_tblr_mktsvy_rowformat.R: 0.00%
#> R/fct_market_survey_combine.R: 0.00%
#> R/fct_market_survey_create_table.R: 0.00%
#> R/fct_market_survey_get_default_company.R: 0.00%
#> R/fct_market_survey_get_input.R: 0.00%
#> R/fct_market_survey_pivot.R: 0.00%
#> R/fct_market_survey_render_tabulator.R: 0.00%
#> R/fct_market_survey_show_tab.R: 0.00%
#> R/fct_market_survey_show_tabulator.R: 0.00%
#> R/fct_show_ind_tables.R: 0.00%
#> R/fct_show_price_input.R: 0.00%
#> R/golem_utils_server.R: 0.00%
#> R/golem_utils_ui.R: 0.00%
#> R/mod_admin.R: 0.00%
#> R/mod_asmp_details.R: 0.00%
#> R/mod_asmp_tab.R: 0.00%
#> R/mod_deals_tab.R: 0.00%
#> R/mod_download_csv.R: 0.00%
#> R/mod_download_excel.R: 0.00%
#> R/mod_downloadbutton_s3.R: 0.00%
#> R/mod_feedback.R: 0.00%
#> R/mod_forex_tab.R: 0.00%
#> R/mod_getdata.R: 0.00%
#> R/mod_help.R: 0.00%
#> R/mod_indesign.R: 0.00%
#> R/mod_inputprices.R: 0.00%
#> R/mod_market_survey.R: 0.00%
#> R/mod_market_survey_status.R: 0.00%
#> R/mod_market_survey_tab.R: 0.00%
#> R/mod_market_survey_tabulator.R: 0.00%
#> R/mod_price_components.R: 0.00%
#> R/mod_price_components_dwnld_csv.R: 0.00%
#> R/mod_price_components_tabs.R: 0.00%
#> R/mod_prices_status.R: 0.00%
#> R/mod_prices_tab.R: 0.00%
#> R/mod_progressbar.R: 0.00%
#> R/mod_settings.R: 0.00%
#> R/mod_stage_prices.R: 0.00%
#> R/mod_summary.R: 0.00%
#> R/mod_tabulator_imported.R: 0.00%
#> R/mod_tabulator_indesign.R: 0.00%
#> R/mod_tabulator_inp.R: 0.00%
#> R/run_app.R: 0.00%
#> R/utils_footer.R: 0.00%
#> R/utils_theme.R: 0.00%
#> R/utils_waiter.R: 0.00%
#> R/utils-argusDT.R: 66.67%
#> R/fct_run_sched_script.R: 92.50%
#> R/fct_market_survey_get_status.R: 96.36%
#> R/fct_market_survey_save.R: 98.68%
#> R/app_config.R: 100.00%
#> R/fct_get_script_guids.R: 100.00%
#> R/fct_set_report_date_init.R: 100.00%
#> R/utils_title.R: 100.00%
```
