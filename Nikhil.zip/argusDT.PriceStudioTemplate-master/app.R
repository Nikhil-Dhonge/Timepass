# Launch the ShinyApp (Do not remove this comment)
# To deploy, run: rsconnect::deployApp()
# Or use the blue button on top of this file

pkgload::load_all(export_all = FALSE, helpers = FALSE, attach_testthat = FALSE)
options(golem.app.prod = FALSE)
options(gargoyle.talkative = TRUE)
options(scipen = 999)
options(digits = 15)
# To allow shiny::fileInput() uploads up to 20 MB
options(shiny.maxRequestSize = 20 * 1024^2)

run_app()
