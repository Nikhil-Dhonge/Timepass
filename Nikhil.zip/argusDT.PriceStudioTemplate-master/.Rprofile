## Activate renv
source("renv/activate.R")

## Set package repos
local({
  r <- getOption("repos")[1]
  r["CRAN"] <- "https://cloud.r-project.org/"
  r["RSPM"] <- "https://rspm.argusmedia.com/live/latest/"
  options(repos = r)
})

## Print library paths
message("Libraries:\t", paste(.libPaths(), collapse = "\n\t\t"))
