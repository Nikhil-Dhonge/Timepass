$(document).ready(function () {
  Tabulator.moduleBindings.selectRange.prototype.restoreFocus = function (element) {
    this.table.rowManager.element.focus({ preventScroll: true });
    return true;
  };
  Tabulator.extendModule("format", "formatters", {
    compare: compare,
  });
});

function tabulatorBindEditableOnlyClear(el) {
  var table = get_tabulator(el.id);
  if (!table) return;

  const deleteHandler = (e) => {
    if (!(e.key === "Backspace" || e.key === "Delete")) return;

    var ranges = table.getRanges ? table.getRanges() : [];
    if (!ranges.length) return;

    e.preventDefault();
    e.stopPropagation();

    ranges.forEach(function (range) {
      var rows2D = range.getStructuredCells();
      if (!rows2D || !rows2D.length) return;
      if (!Array.isArray(rows2D[0])) rows2D = [rows2D];

      rows2D.forEach(function (rowCells) {
        rowCells.forEach(function (cell) {
          try {
            var def = cell.getColumn().getDefinition();
            var editable =
              def.editable === true || (typeof def.editable === "function" && def.editable(cell));
            if (editable) {
              var clearValue = table.options.selectableRangeClearCellsValue;
              cell.setValue(clearValue);
              // Set FINAL column to FALSE if value is deleted
              if (cell.getRow().getData().FINAL === true) {
                cell.getRow().update({ FINAL: false });
              }
            }
          } catch (err) {
            console.log("Error caught while deleting prices:", err.message);
          }
        });
      });
    });
  };

  table.element.addEventListener("keydown", deleteHandler, true);

  // remove listener on table destroy
  table.on("tableDestroyed", function () {
    document.removeEventListener("keydown", deleteHandler, true);
  });
}

function tabulatorRangeOverlayEvents(el) {
  var table = get_tabulator(el.id);

  // define the click handler
  const clickHandler = (e) => {
    var obj = $("#" + el.id).find("div.tabulator-range-overlay");
    if (!el.contains(e.target) && !table.destroyed) {
      obj.hide();
    }
  };

  // hide on data processed
  table.on("dataProcessed", function (range) {
    if (!table.destroyed) {
      $("#" + el.id)
        .find("div.tabulator-range-overlay")
        .hide();
    }
  });

  // hide on click event
  document.addEventListener("click", clickHandler);

  // show on range change
  table.on("rangeChanged", function (range) {
    if (!table.destroyed) {
      $("#" + el.id)
        .find("div.tabulator-range-overlay")
        .show();
    }
  });

  // remove click listener on table destroy
  table.on("tableDestroyed", function () {
    document.removeEventListener("click", clickHandler);
  });
}

function valuesLookupCellEditor() {
  return function (cell, filterTerm) {
    let params = cell.getColumn().getDefinition().editorParams,
      col_value = typeof params.col_value === "undefined" ? null : params.col_value,
      col_label = typeof params.col_label === "undefined" ? col_value : params.col_label,
      values = [],
      labels = [],
      options = [];

    // check columns exist
    if (!col_label) {
      console.warn("option column not provided: editorParams.col_label can't be null");
    } else if (!cell.getData()[col_label]) {
      console.warn("unable to find matching column: editorParams.col_label = ", col_label);
    } else if (!cell.getData()[col_value]) {
      console.warn("unable to find matching column: editorParams.col_value = ", col_value);
    } else {
      labels = cell.getData()[col_label];
      values = cell.getData()[col_value];
    }

    // force to arrays
    if (!Array.isArray(values)) {
      values = Object.values(values);
    }
    if (!Array.isArray(labels)) {
      labels = Object.values(labels);
    }

    for (var i = 0; i < values.length; i++) {
      if (labels[i] !== null && labels[i].length > 0 && values[i].length > 0) {
        options[i] = { label: labels[i][0], value: values[i][0] };
      } else {
        console.log("valuesLookupCellEditor: labels and values not passed as array");
      }
    }

    return options;
  };
}

function valuesLookupCellValidator() {
  return function (cell, value, parameters) {
    let col_value = typeof parameters.col_value === "undefined" ? null : parameters.col_value,
      values = [];

    // check columns exist
    if (!col_value) {
      console.warn("option column not provided: parameters.col_value can't be null");
    } else if (!cell.getData()[col_value]) {
      console.warn("unable to find matching column: parameters.col_value = ", col_value);
    } else {
      values = cell.getData()[col_value];
    }

    // force to arrays
    if (!Array.isArray(values)) {
      values = Object.values(values);
    }

    for (var i = 0; i < values.length; i++) {
      if (values[i] !== null && values[i].length > 0) {
        if (value === values[i][0]) return true;
      } else {
        if (value === values[i]) return true;
      }
    }

    return false;
  };
}

function valuesLookupCellFormatter(cell) {
  let params = cell.getColumn().getDefinition().editorParams,
    col_value = typeof params.col_value === "undefined" ? null : params.col_value,
    col_label = typeof params.col_label === "undefined" ? col_value : params.col_label,
    col_prior = typeof params.col_prior === "undefined" ? null : params.col_prior,
    val_prior = col_prior !== null ? cell.getData()[col_prior] : null,
    col_publish = typeof params.col_publish === "undefined" ? null : params.col_publish,
    val_publish = col_publish !== null ? cell.getData()[col_publish] : null,
    values = [],
    labels = [],
    options = [];

  // default option
  options[null] = null;

  // check columns exist
  if (!col_label) {
    console.warn("option column not provided: editorParams.col_label can't be null");
  } else if (!cell.getData()[col_label]) {
    console.warn("unable to find matching column: editorParams.col_label = ", col_label);
  } else if (!cell.getData()[col_value]) {
    console.warn("unable to find matching column: editorParams.col_value = ", col_value);
  } else {
    labels = cell.getData()[col_label];
    values = cell.getData()[col_value];
  }

  // force to arrays
  if (!Array.isArray(values)) {
    values = Object.values(values);
  }
  if (!Array.isArray(labels)) {
    labels = Object.values(labels);
  }

  for (var i = 0; i < values.length; i++) {
    if (labels[i] !== null && labels[i].length > 0) {
      options[values[i]] = labels[i][0];
    } else {
      options[values[i]] = labels[i];
    }
  }

  // set custom classes
  cell.getElement().classList.remove("tabulator-cell-editable-empty");
  cell.getElement().classList.remove("tabulator-cell-editable-filled");
  cell.getElement().classList.remove("tabulator-cell-changed");

  if (
    cell.getColumn().getDefinition().editable === true ||
    (typeof cell.getColumn().getDefinition().editable === "function" &&
      cell.getColumn().getDefinition().editable(cell))
  ) {
    if (cell.getValue() === null || cell.getValue() === "") {
      cell.getElement().classList.add("tabulator-cell-editable-empty");
    } else {
      cell.getElement().classList.add("tabulator-cell-editable-filled");
    }
  }

  // set custom class when prior value not equal to current
  if (val_prior !== null && cell.getValue() !== val_prior && val_publish === true) {
    cell.getElement().classList.add("tabulator-cell-changed");
  }

  return options;
}

function rowFormatterPrices() {
  return function (row) {
    var dt = row.getData(),
      cellCode = row.getCell("CODE_ID");

    row.getElement().classList.remove("tabulator-row-exclude");
    cellCode
      .getElement()
      .classList.remove("tabulator-cell-error", "tabulator-cell-warning", "tabulator-cell-success");

    if (dt.PUBLISH !== true) {
      row.getElement().classList.add("tabulator-row-exclude");
      return;
    }

    if (dt.ERROR === true) {
      cellCode.getElement().classList.add("tabulator-cell-error");
      return;
    }

    if (dt.CORRECTION === true) {
      cellCode.getElement().classList.add("tabulator-cell-warning");
      return;
    }

    if (dt.FWD === dt.STG_FWD && dt.YEAR === dt.STG_YEAR && dt.DBR === dt.STG_DBR) {
      if (dt.EDIT_MID === true && dt.MID === dt.STG_MID) {
        cellCode.getElement().classList.add("tabulator-cell-success");
      } else if (dt.LOW === dt.STG_LOW && dt.HIGH === dt.STG_HIGH) {
        cellCode.getElement().classList.add("tabulator-cell-success");
      }
    }

    if (dt.FWD === dt.LIVE_FWD && dt.YEAR === dt.LIVE_YEAR && dt.DBR === dt.LIVE_DBR) {
      if (dt.EDIT_MID === true && dt.MID === dt.LIVE_MID) {
        cellCode.getElement().classList.add("tabulator-cell-complete");
      } else if (dt.LOW === dt.LIVE_LOW && dt.HIGH === dt.LIVE_HIGH) {
        cellCode.getElement().classList.add("tabulator-cell-complete");
      }
    }
  };
}

function rowFilterLookUp(headerValue, rowValue, rowData, filterParams) {
  /**
   * This function allows the filters to work on columns where formatting takes place. For example,
   * in the FORWARD column the tabulator might show the value as Jun-2025, but the actual value
   * stored is 2025-6. What this function does is to match the actual value in the cell with the
   * formatter and then correctly applies the filter chosen by the user.
   *
   * @param {string} headerValue  Current value of the filter.
   * @param {string} rowValue     Current value of the cell where the filter has been called on.
   * @param {Array}  rowData      Array containing all the data for the current row being evaluated.
   * @param {Object} filterParams Additional custom parameters for the filter.
   *
   * @return {boolean} Returns a boolean object, true if the current row matches the filter applied,
   * false if the current row does not match the filter applied by the user. The function is applied
   * on loop to each row of the tabulator table.
   */

  // Retrieve additional custom arguments from the filterParams argument
  const colLabel = filterParams.col_label;
  const colValue = filterParams.col_value;

  prompt_forwards = ["prompt", "spot", "dated"];

  // If the column being evaluated is for the FORWARD value and TIMING is prompt / spot / dated,
  // then match the first instance of the labels with the headerValue (as rowValue will always be
  // null in these cases)
  if ((colLabel === "FORWARD_DROPDOWN") & prompt_forwards.includes(rowData["TIMING"])) {
    return rowData[colLabel][0][0].toLowerCase().includes(headerValue.toLowerCase());
  }

  // Return false if rowValue is null
  if (rowValue === null) {
    return false;
  }

  // From the rowValue, extract the index within the array of values
  let lookupIndex = rowData[colValue].flat().indexOf(rowValue);

  // Return false if the index is -1 (item could not be found)
  if (lookupIndex === -1) {
    return false;
  }

  // Is the headerValue included in the looked up label? If yes return true otherwise false
  return rowData[colLabel][lookupIndex][0].toLowerCase().includes(headerValue.toLowerCase());
}

function fct_js_tabulator_click_copy_prior(e, cell) {
  if (cell.getRow().getData().EDIT_MID) {
    target_cell = cell.getRow().getCell("MID");
    source_cell = cell.getRow().getCell("PRIOR_MID");
    target_cell.setValue(source_cell.getValue());
  } else {
    target_cell = cell.getRow().getCell("LOW");
    source_cell = cell.getRow().getCell("PRIOR_LOW");
    target_cell.setValue(source_cell.getValue());
    target_cell = cell.getRow().getCell("HIGH");
    source_cell = cell.getRow().getCell("PRIOR_HIGH");
    target_cell.setValue(source_cell.getValue());
  }

  cell.getRow().update({ FINAL: false });
}

function custom_tooltip(target_col) {
  return function (e, cell) {
    const rowData = cell.getRow().getData();
    return rowData[target_col];
  };
}

function compare(cell, formatterParams) {
  let fp = formatterParams;
  const comparisonField = typeof fp.comparisonField === "undefined" ? null : fp.comparisonField;
  const matchClass = typeof fp.matchClass === "undefined" ? null : fp.matchClass;
  const mismatchClass = typeof fp.mismatchClass === "undefined" ? null : fp.mismatchClass;

  // remove existing classes
  cell.getElement().classList.remove(matchClass);
  cell.getElement().classList.remove(mismatchClass);

  if (!comparisonField) console.warn("valueChanged formatter requires 'comparisonField' parameter");

  let comparisonValue = cell.getRow().getData()[comparisonField];

  // return value if comparison field not found
  if (typeof comparisonValue === "undefined") {
    console.warn("compare formatter unable to find comparison field: ", comparisonField);
    return cell.getValue();
  }

  if (cell.getValue() == comparisonValue && matchClass) {
    // add class if values are the same
    cell.getElement().classList.add(matchClass);
  } else if (cell.getValue() != comparisonValue && mismatchClass) {
    // add class if values are different
    cell.getElement().classList.add(mismatchClass);
  }

  return cell.getValue();
}
