$(document).ready(function () {
  Shiny.addCustomMessageHandler("timezone", function (args) {
    var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (typeof timezone === "undefined") {
      timezone = "UTC";
    }
    Shiny.onInputChange("timezone", timezone);
  });

  Shiny.addCustomMessageHandler("dt_prices_all", function (args) {
    window.dt_prices_all = args;
  });

  Shiny.addCustomMessageHandler("reformat_all_tabulator_rows", function (args) {
    var tabulator_length = get_tabulator(args).getRows().length;

    for (var i = 1; i < tabulator_length; i++) {
      get_tabulator(args).getRow(i).reformat();
    }
  });

  // add correct class to right aligned dropdown menus
  $(".dropdown-menu-right").addClass("dropdown-menu-end");
});
