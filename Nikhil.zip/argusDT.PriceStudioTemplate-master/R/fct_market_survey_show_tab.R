#' fct_show_ms_tab
#' @description A function to add tabs to a selected nav set element
#' @param input,session,r Internal parameters for {shiny}
#' @param navset_tab_id character string used to identify the nav container
#' @param market character for selected market
#' @return A character list of nav panel ids added to the nav set
fct_market_survey_show_tab <- function(input, session, r, navset_tab_id, market) {
  ns <- session$ns

  log_info("fct_market_survey_show_tab ns:", get_ns(ns), level = 2)

  ## Remove prior tables ----
  if (length(r$market_survey$tab_ids) > 0) {
    purrr::walk(.x = r$market_survey$tab_ids, .f = function(x) {
      id <- paste0(ns(x), "-nav_panel")

      ## Remove UI
      bslib::nav_remove(target = id, id = navset_tab_id, session = session)
    })
  }

  ## Add new tables ----
  ### Get market sections for just the current MARKET

  if (is_truthy(market)) {
    r$market_survey$tabs <- unique(
      r$market_survey$dt_pivot[!is.na(MARKET) & MARKET == market][order(
        -SECTION_DISPLAY_ORDER
      )]$SECTION
    )

    r$market_survey$tab_ids <- gsub("\\W", "_", paste(market, r$market_survey$tabs))

    ### Insert UI, all input tables
    purrr::walk2(
      .x = ns(r$market_survey$tab_ids),
      .y = r$market_survey$tabs,
      .f = mod_market_survey_tab_ui,
      navset_tab_id = navset_tab_id,
      session = session
    )

    ### Add tabulator server
    purrr::walk2(
      .x = r$market_survey$tab_ids,
      .y = r$market_survey$tabs,
      .f = mod_market_survey_tab_server,
      r = r
    )
  }
}
