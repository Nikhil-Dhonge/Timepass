#' The application server-side
#' @param input,output,session Internal parameters for {shiny}.
#' @noRd
app_server <- function(input, output, session) {
  log_info("app_server", level = 0)

  # Set session ID ----
  session$userData$sid <- sample.int(1000, size = 1)
  session$userData$username <- get_config("username")
  session$userData$pid <- get_config("pid")
  session$userData$application_id <- get_config("application_id")
  session$userData$version_app <- golem::get_golem_version()
  session$userData$version_main <- utils::packageVersion("argusDT.PriceStudioMain")
  session$userData$version_formulas <- utils::packageVersion("argusDT.PriceStudioFormulas")
  session$userData$feedback_email <- get_config("feedback_email")

  log_info("session started:", session$userData$sid[1], level = 1)
  log_info("username:", session$userData$username[1], level = 1)

  # Create env variables ----
  r <- fct_create_env_vars(session)

  # Gargoyle events ----
  log_info("initiate gargoyle events", level = 1)

  gargoyle::init("show_waiter")
  gargoyle::init("hide_waiter")
  gargoyle::init("add_main_modules")
  ## Settings (in mod_settings_server)
  gargoyle::init("change_dates")
  gargoyle::init("reset_to_staged")
  gargoyle::init("delete_all_prices")
  gargoyle::init("delete_market_prices")
  ## Input prices (in mod_inputprices_server)
  gargoyle::init("change_market")
  gargoyle::init("get_codemaster")
  gargoyle::init("populate_custom_column")
  gargoyle::init("get_marketcontent")
  gargoyle::init("create_price_table")
  gargoyle::init("import_prices")
  gargoyle::init("tabulator_destroy")
  gargoyle::init("check_final_status")
  gargoyle::init("get_live_prices")
  gargoyle::init("get_stg_prices")
  gargoyle::init("get_exrates")
  gargoyle::init("get_fixed_conv")
  gargoyle::init("get_deals")
  gargoyle::init("combine_price_data")
  gargoyle::init("send_js_prices")
  gargoyle::init("update_final_flag")
  gargoyle::init("get_formulas")
  gargoyle::init("pivot_prices")
  gargoyle::init("calculate_prices")
  gargoyle::init("reset_dependencies")
  gargoyle::init("check_prices")
  gargoyle::init("get_prices_status")
  gargoyle::init("show_custom_tbl")
  gargoyle::init("show_price_input")
  gargoyle::init("update_price_input")
  gargoyle::init("update_statuses")
  gargoyle::init("update_price_input_copied")
  gargoyle::init("stage_prices_start")
  gargoyle::init("stage_check_errors")
  gargoyle::init("check_user_before_stg")
  gargoyle::init("check_staged_exrates")
  gargoyle::init("check_exrates_before_stg")
  gargoyle::init("reset_exrates_to_staged")
  gargoyle::init("reset_exrates_to_init")
  gargoyle::init("stage_prices_end")
  gargoyle::init("copy_prices")
  gargoyle::init("view_staged_prices")
  gargoyle::init("fill_empty_market")
  gargoyle::init("enable_market")
  gargoyle::init("disable_market")
  gargoyle::init("disable_buttons")
  gargoyle::init("change_region")
  gargoyle::init("close_modal")
  gargoyle::init("reformat_all_tabulator_rows")
  gargoyle::init("get_random_data")
  gargoyle::init("review_corrections")
  ## Prices summary (in mod_summary_server)
  gargoyle::init("create_summary")
  gargoyle::init("create_datawell")
  gargoyle::init("get_summary_status")
  gargoyle::init("upload_prices_start")
  gargoyle::init("save_csv_in_s3")
  gargoyle::init("upload_prices_pwd_modal")
  gargoyle::init("send_deadline_email")
  gargoyle::init("upload_prices_end")
  gargoyle::init("user_msg_modal")
  gargoyle::init("hide_summary_columns")
  gargoyle::init("show_summary_columns")
  gargoyle::init("reupload_final_warnings")
  gargoyle::init("show_scheduled_scripts")
  gargoyle::init("run_scheduled_script")
  ## Feedback form
  gargoyle::init("close_feedback_form")
  ## Assumption tab
  gargoyle::init("get_asmp")
  gargoyle::init("show_asmp_modal_dialog")
  gargoyle::init("update_asmp")
  ## Market Survey
  gargoyle::init("market_survey_import")
  gargoyle::init("market_survey_create")
  gargoyle::init("market_survey_combine")
  gargoyle::init("market_survey_pivot")
  gargoyle::init("market_survey_show")
  gargoyle::init("market_survey_replace")
  gargoyle::init("market_survey_get_data")
  gargoyle::init("market_survey_save")
  gargoyle::init("market_survey_enable_market")
  gargoyle::init("market_survey_disable_market")
  gargoyle::init("market_survey_enable_refresh")
  gargoyle::init("save_documents")
  gargoyle::init("market_survey_show_hide_notes")
  gargoyle::init("enable_show_files")
  gargoyle::init("disable_show_files")
  gargoyle::init("market_survey_check_files")
  gargoyle::init("market_survey_show_files")
  gargoyle::init("market_survey_enable_download")
  gargoyle::init("market_survey_disable_download")
  gargoyle::init("get_market_survey_status")

  ## InDesign
  gargoyle::init("get_indesign_status")
  gargoyle::init("get_ind_tables")
  gargoyle::init("create_ind_tables")
  gargoyle::init("populate_ind_tables")
  gargoyle::init("show_ind_tables")
  gargoyle::init("send_tables")
  gargoyle::init("clear_ind_tables")
  gargoyle::init("check_and_refresh_indtables")
  gargoyle::init("auto_show_ind_tables")
  gargoyle::init("send_tables_censhare")
  gargoyle::init("disable_send_tables_button")
  gargoyle::init("enable_send_tables_button")
  gargoyle::init("update_send_tables_button_status")

  ## Price Components ---
  gargoyle::init("refresh_price_components")
  gargoyle::init("show_price_components_tbls")
  gargoyle::init("price_components_enable_dwnld")
  gargoyle::init("price_components_disable_dwnld")
  gargoyle::init("price_components_enable_market")
  gargoyle::init("price_components_disable_market")
  gargoyle::init("destroy_price_components_tabulators")

  shiny::observeEvent(input$navbar, {
    r$rv$selected_nav_panel <- input$navbar
  })

  # Browser timezone ----
  session$sendCustomMessage("timezone", 1)

  # Timezone triggers main modules ----
  shiny::observeEvent(input$timezone, {
    log_info("observeEvent get user timezone:", input$timezone, level = 1)

    r$rv$user_timezone <- input$timezone

    # Initialize the report date using the timezone of the user and
    # then adjust the report date with the settings frequency and publish_day
    # from PRC_APPLICATION table
    r$rv$report_date <- fct_set_report_date_init(
      today = lubridate::today(tzone = r$rv$user_timezone),
      frequency = r$frequency,
      publish_day = r$publish_day,
      app_end_date = r$app_end_date
    )

    r$rv$prev$report_date <- r$rv$report_date

    gargoyle::trigger("get_marketcontent")
    gargoyle::trigger("add_main_modules")
  })

  # Market content ----
  shiny::observeEvent(
    gargoyle::watch("get_marketcontent"),
    {
      log_info("observeEvent:", "get_marketcontent", level = 1)

      r$rv$dt_market_content <- argusDT.PriceStudioMain::fct_get_marketcontent(
        application_id = get_config("application_id"),
        db_env = r$rv$db_env,
        report_date = r$rv$report_date,
        verbose = FALSE,
        connection = r$rv$ora_connection
      )

      ## Deadlines ----
      r$rv$dt_market_content$DUE_DATE_ORG <- purrr::map2_vec(
        .x = paste(r$rv$report_date, r$rv$dt_market_content$DEADLINE),
        .y = r$rv$dt_market_content$DEADLINE_TZ,
        .f = ~ lubridate::ymd_hms(.x, tz = .y)
      )

      r$rv$dt_market_content$DUE_DATE <- lubridate::with_tz(
        r$rv$dt_market_content$DUE_DATE_ORG,
        r$rv$user_timezone
      )

      ## Due period ----
      r$rv$dt_market_content[,
        DUE_TIME := data.table::fcase(
          format(DUE_DATE, "%Y-%m-%d") > r$rv$report_date  , paste(format(DUE_DATE, "%T"), "(+1)") ,
          format(DUE_DATE, "%Y-%m-%d") < r$rv$report_date  , paste(format(DUE_DATE, "%T"), "(-1)") ,
          format(DUE_DATE, "%Y-%m-%d") == r$rv$report_date , format(DUE_DATE, "%T")                ,
          default = "na"
        )
      ]

      ## Set color coding for DEADLINES ----
      deadline_palette <- colorRampPalette(c("blue", "red"))(length(unique(
        r$rv$dt_market_content$DUE_TIME
      )))

      dt_deadline_palette <- data.table::data.table(
        DUE_TIME = unique(r$rv$dt_market_content$DUE_TIME),
        DEADLINE_PALETTE = deadline_palette
      )

      r$rv$dt_market_content[
        dt_deadline_palette,
        `:=`(DEADLINE_PALETTE = i.DEADLINE_PALETTE),
        on = "DUE_TIME"
      ]

      r$rv$quote_id <- unique(r$rv$dt_market_content$QUOTE_ID)

      # Make sure to update region_quote_id when the report date is changed by the user
      if (!is.null(r$rv$region)) {
        r$rv$region_quote_id <- r$rv$dt_market_content[REGION == r$rv$region]$QUOTE_ID
      }

      r$rv$holiday_regions <- unique(c(
        r$rv$dt_market_content$HOLIDAY_REGION,
        r$rv$dt_market_content[HOLIDAY_REGION2 != "No Holidays"]$HOLIDAY_REGION2,
        r$rv$dt_market_content[HOLIDAY_REGION3 != "No Holidays"]$HOLIDAY_REGION3
      ))

      r$rv$holiday_combinations <- unique(r$rv$dt_market_content[, .(
        HOLIDAY_REGION,
        HOLIDAY_REGION2,
        HOLIDAY_REGION3
      )])
    },
    ignoreInit = TRUE
  )

  # Main server modules ----
  shiny::observeEvent(
    gargoyle::watch("add_main_modules"),
    {
      log_info("add server modules", level = 1)

      mod_settings_server(id = "settings", r)
      mod_getdata_server(id = "get_data", r)

      ## Add Price Input and Price Summary tab
      if (get_config("show_tab_price_input")) {
        mod_inputprices_server(id = "input_prices", r)
        mod_summary_server(id = "summary", r)
      }

      ## Add Market Survey module only when it exists
      if (get_config("show_tab_market_survey")) {
        mod_market_survey_server(id = "market_survey", r = r)
      }

      ## Add InDesign module only when it exists
      if (get_config("show_tab_indesign")) {
        mod_indesign_server(id = "indesign", r)
      }

      ## Add Admin module only when needed
      if (get_config("show_tab_admin")) {
        mod_admin_server(id = "admin", r)
      }

      ## Add Price Components module only when needed
      if (get_config("show_tab_price_components")) {
        mod_price_components_server(id = "price_components", r)
      }
    },
    ignoreInit = TRUE
  )

  # Header ----
  ## Region picker ----
  argusDT.PriceStudioMain::mod_selectizeinput_server(
    id = "region",
    rv = r$rv,
    choices_rv = "regions",
    enable_trigger = "add_main_modules"
  )

  ## Report date ----
  output$report_date <- shiny::renderText(glue::glue(
    "{format(r$rv$report_date, '%a, %e-%b-%Y')}"
  )) |>
    shiny::bindEvent(r$rv$report_date, ignoreInit = TRUE)

  ## Database environment text ----
  shiny::observeEvent(r$rv$db_env, {
    log_info("observeEvent:", "output$db_env", level = 1)

    db_env <- ifelse(r$rv$db_env == "LIVE", "", r$rv$db_env)

    output$db_env <- shiny::renderText(db_env)
  })

  # Open help box ----
  shinyjs::onclick("help_ui", {
    shiny::req(!r$rv$help_guide)

    log_info("onclick:", "help_ui", level = 2)

    winboxr::winbox(
      inputId = "help",
      ui = mod_help_ui(id = "mod_help"),
      title = "Help",
      x = "55%",
      y = "8%",
      height = "700px",
      width = "600px"
    )

    mod_help_server(id = "mod_help")

    ## Avoid opening the guide twice by using this variable to check the status
    ## of the guide
    r$rv$help_guide <- TRUE
  })

  # Reset help box ----
  shiny::observeEvent(
    input$help_closed,
    {
      log_info("observeEvent:", "input$help_closed", level = 2)
      r$rv$help_guide <- FALSE
    },
    ignoreInit = TRUE
  )

  mod_feedback_server(id = "mod_feedback", r = r)

  # Open feedback box ----
  shinyjs::onclick("feedback_ui", {
    shiny::req(!r$rv$feedback_form)

    log_info("onclick:", "feedback_ui", level = 2)

    shiny::showModal(shiny::modalDialog(
      inputId = "feedback",
      mod_feedback_ui(id = "mod_feedback"),
      title = "Price Studio Feedback Form",
      size = "xl",
      footer = NULL
    ))

    ## Avoid opening the feedback form twice by using this variable to check the
    ## status of the guide
    r$rv$feedback_form <- TRUE
  })

  # Reset feedback box----
  shiny::observeEvent(
    input$feedback_closed,
    {
      log_info("observeEvent:", "input$feedback_closed", level = 2)
      r$rv$feedback_form <- FALSE
    },
    ignoreInit = TRUE
  )

  # Send feedback ----
  ## Once the user has clicked on send email, automatically close the feedback
  ## form and reset the relative variable
  shiny::observeEvent(
    gargoyle::watch("close_feedback_form"),
    {
      log_info("observeEvent:", "close_feedback_form", level = 2)

      shiny::removeModal()
      r$rv$feedback_form <- FALSE
    },
    ignoreInit = TRUE
  )

  # Show waiter and disable dateinput widget ----
  shiny::observeEvent(
    gargoyle::watch("show_waiter"),
    {
      log_info("observeEvent:", "show_waiter", level = 2)

      r$rv$w$show()
      shinyjs::disable(id = "settings-report_date-dateinput", asis = TRUE)
    },
    ignoreInit = TRUE,
    priority = 1
  )

  # Hide waiter and enable dateinput widget ----
  shiny::observeEvent(
    gargoyle::watch("hide_waiter"),
    {
      log_info("observeEvent:", "hide_waiter", level = 2)

      r$rv$w$hide()
      shinyjs::enable(id = "settings-report_date-dateinput", asis = TRUE)
    },
    ignoreInit = TRUE,
    priority = -1
  )

  # Footer ----
  ## Session id ----
  shiny::observeEvent(session$userData$sid, {
    log_info("observeEvent:", "session$userData$sid", level = 2)
    shinyjs::html(id = "footer-session", paste0("Session: ", session$userData$sid), asis = TRUE)
  })

  ## Report date ----
  shiny::observeEvent(r$rv$report_date, {
    log_info("footer-report_date_tz", level = 2)

    shinyjs::html(
      id = "footer-report_date_tz",
      glue::glue("Report Date: {format(r$rv$report_date, '%a, %e-%b-%Y')} ({r$rv$user_timezone})"),
      asis = TRUE
    )
  })

  # Stop session ----
  shiny::onStop(function() {
    log_info("session ended: ", session$userData$sid[1], level = 1)
  })

  log_info("observe events")
}
