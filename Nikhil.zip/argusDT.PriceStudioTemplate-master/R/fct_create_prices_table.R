#' create_prices_table
#' @description Create the prices table
#' @param report_date (Required) The current report date
#' @param all_dates (Required) A sequence of business dates
#' @param dt_market_content (Required) Data.table object containing the app
#' metadata.
#' @param dt_codemaster (Required) Data.table object containing the PA code
#' metadata.
#' @param dt_prc_asmp (Required) Data.table object containing formula metadata
#' @param dt_holidays (Required) Data.table object containing holiday dates
#' for all holiday regions referenced `dt_market_content`.
#' @param fwd_list_start (Required) Integer object indicating the off-set of
#' the start of the forward list.
#' @param fwd_list_count (Required) Integer object indicating the number of
#' items in the forward list.
#' @param dbr_list_start (Required) Integer object indicating off-set of the
#' start of the basis list.
#' @param dbr_list_count (Required) Integer object indicating the number of
#' items in the basis list.
#' @param calendars (Required) A matrix / array object containing the calendars
#' for different regions.
#' @return A data.table object.
#' @noRd
fct_create_prices_table <- function(
  report_date,
  all_dates,
  dt_market_content,
  dt_codemaster,
  dt_prc_asmp,
  dt_holidays,
  fwd_list_start,
  fwd_list_count,
  dbr_list_start,
  dbr_list_count,
  calendars
) {
  log_info("fct_create_prices_table", level = 2)

  ## Create empty table of codes ----
  dt <- dt_codemaster[,
    .SD,
    .SDcols = c(
      "QUOTE_PRICETYPE_ID",
      "QUOTE_ID",
      "CODE_ID",
      "CODE_DESCRIPTION",
      "TS",
      "CF",
      "PT",
      "TIMING",
      "DIFF_BASE_ID",
      "DIFF_BASE",
      "DBR_TIMING_ID",
      "DBR_TIMING",
      "UNIT",
      "DECIMALPLACES",
      "PCT_LIMIT",
      "ALLOWUPLOAD_YN",
      "CHANGE_MODE",
      "FREQUENCY",
      "HOLIDAY1",
      "HOLIDAY2",
      "DISPLAY_TYPE_ID",
      "INTERNAL_ONLY",
      "WEEKENDISHOLIDAY_YN"
    )
  ]

  ## Create diff type ----
  pt_diffs <- argusDT.PriceStudioMain::dt_pricetype[OUT_DIFF_TYPE == "Differential", PRICE_TYPE_ID]

  dt[, OUT_DIFF_TYPE := data.table::fifelse(PT %in% pt_diffs, "Differential", "Outright")]

  ## Get other pricetypes ----
  dt[
    argusDT.PriceStudioMain::dt_pricetype,
    `:=`(PT_MID = i.PT_MID, PT_LOW = i.PT_LOW, PT_HIGH = i.PT_HIGH),
    on = .(PT == PRICE_TYPE_ID)
  ]

  dt[dt, QPT_MID := i.QUOTE_PRICETYPE_ID, on = .(QUOTE_ID, PT_MID == PT)]

  dt[dt, QPT_LOW := i.QUOTE_PRICETYPE_ID, on = .(QUOTE_ID, PT_LOW == PT)]

  dt[dt, QPT_HIGH := i.QUOTE_PRICETYPE_ID, on = .(QUOTE_ID, PT_HIGH == PT)]

  dt[, c("PT_MID", "PT_LOW", "PT_HIGH") := NULL]

  ## Add PRC_MARKET_CONTENT columns ----
  dt_market_content0 <- data.table::copy(dt_market_content)

  dt_market_content0[,
    OUT_DIFF_TYPE := data.table::fifelse(PT %in% pt_diffs, "Differential", "Outright")
  ]

  dt[
    dt_market_content0,
    `:=`(
      MARKET = i.MARKET,
      SECTION = i.SECTION,
      TYPE = i.TYPE,
      DISPLAY_ORDER = i.DISPLAY_ORDER,
      EDIT_MID = (i.EDIT_MID == "Y"),
      EDIT_FWD = (i.EDIT_FWD == "Y"),
      EDIT_DBR = (i.EDIT_DBR == "Y"),
      SPREAD = ifelse(i.EDIT_SPREAD == "Y", NA_real_, i.SPREAD),
      DESC_SHORT = i.DESC_SHORT,
      ALLOWZERO_YN = i.ALLOWZERO_YN,
      HOLIDAY_REGION = i.HOLIDAY_REGION,
      HOLIDAY_REGION2 = i.HOLIDAY_REGION2,
      HOLIDAY_REGION3 = i.HOLIDAY_REGION3,
      HOLIDAY_KEY = i.HOLIDAY_KEY,
      DTE_FORMULA = i.DTE_FORMULA,
      PACKAGE = i.PACKAGE,
      REGION = i.REGION,
      DUE_TIME = i.DUE_TIME,
      DEADLINE_PALETTE = i.DEADLINE_PALETTE,
      SUSPENDED_QUOTE_ID = i.SUSPENDED_QUOTE_ID,
      EDIT_SPREAD = (i.EDIT_SPREAD == "Y")
    ),
    on = .(QUOTE_ID, OUT_DIFF_TYPE)
  ]

  ## Create IN_MARKET_CONTENT ----
  ## to later remove duplicate midpoints
  dt[dt_market_content0, IN_MARKET_CONTENT := TRUE, on = "QUOTE_PRICETYPE_ID"]

  ## Merge dates ----
  dt <- merge(all_dates, dt) %>% data.table::data.table()

  data.table::setnames(dt, old = "x", new = "PUBLICATION_DATE")

  ## Edit CODE_DESCRIPTION ----
  ## when continuous forward > 0
  dt[CF != 0, CODE_DESCRIPTION := paste0(CODE_DESCRIPTION, " ", CF)]

  ## Get FORMULA_NOTES column from dt_prc_asmp
  if (!is.null(dt_prc_asmp)) {
    dt[
      dt_prc_asmp[ENTITY_TYPE_ID == 23],
      FORMULA_NOTES := i.FORMULA_NOTES,
      on = c("QUOTE_PRICETYPE_ID == ENTITY_ID")
    ]
  } else {
    dt[, FORMULA_NOTES := NA]
  }

  ## Create basis list ----
  ## for basis drop-down selection
  dt[,
    BASIS_DROPDOWN := data.table::fcase(
      is.na(DBR_TIMING)          , list(list(NA_character_, NA_character_))                                                                            ,
      DBR_TIMING == "day"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "day", dbr_list_start, dbr_list_count, "text")        ,
      DBR_TIMING == "week"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "week", dbr_list_start, dbr_list_count, "text")       ,
      DBR_TIMING == "half-month" , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-month", dbr_list_start, dbr_list_count, "text") ,
      DBR_TIMING == "month"      , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "month", dbr_list_start, dbr_list_count, "text")      ,
      DBR_TIMING == "quarter"    , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "quarter", dbr_list_start, dbr_list_count, "text")    ,
      DBR_TIMING == "season"     , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "season", dbr_list_start, dbr_list_count, "text")     ,
      DBR_TIMING == "half-year"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-year", dbr_list_start, dbr_list_count, "text")  ,
      DBR_TIMING == "year"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "year", dbr_list_start, dbr_list_count, "text")       ,
      DBR_TIMING == "gas year"   , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "gas year", dbr_list_start, dbr_list_count, "text")   ,
      default = as.list(NA_character_)
    )
  ]

  ## Create dbr list ----
  ## for basis drop-down index
  dt[,
    DBR_DROPDOWN := data.table::fcase(
      is.na(DBR_TIMING)          , list(list(0, NA_character_))                                                                                       ,
      DBR_TIMING == "day"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "day", dbr_list_start, dbr_list_count, "dbr")        ,
      DBR_TIMING == "week"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "week", dbr_list_start, dbr_list_count, "dbr")       ,
      DBR_TIMING == "half-month" , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-month", dbr_list_start, dbr_list_count, "dbr") ,
      DBR_TIMING == "month"      , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "month", dbr_list_start, dbr_list_count, "dbr")      ,
      DBR_TIMING == "quarter"    , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "quarter", dbr_list_start, dbr_list_count, "dbr")    ,
      DBR_TIMING == "season"     , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "season", dbr_list_start, dbr_list_count, "dbr")     ,
      DBR_TIMING == "half-year"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-year", dbr_list_start, dbr_list_count, "dbr")  ,
      DBR_TIMING == "year"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "year", dbr_list_start, dbr_list_count, "dbr")       ,
      DBR_TIMING == "gas year"   , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "gas year", dbr_list_start, dbr_list_count, "dbr")   ,
      default = as.list(NA_character_)
    )
  ]

  ## Create forward list ----
  ## for forward drop-down selection
  dt[,
    FORWARD_DROPDOWN := data.table::fcase(
      TIMING == "prompt"      , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "prompt")                              ,
      TIMING == "spot"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "spot")                                ,
      TIMING == "dated"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "dated")                               ,
      TIMING == "day-ahead"   , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "day-ahead")                           ,
      TIMING == "weekend"     , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "weekend")                             ,
      TIMING == "week-ahead"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "week-ahead")                          ,
      TIMING == "day"         , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "day", fwd_list_start, fwd_list_count, "text")         ,
      TIMING == "week"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "week", fwd_list_start, fwd_list_count, "text")        ,
      TIMING == "week number" , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "week number", fwd_list_start, fwd_list_count, "text") ,
      TIMING == "half-month"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-month", fwd_list_start, fwd_list_count, "text")  ,
      TIMING == "month"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "month", fwd_list_start, fwd_list_count, "text")       ,
      TIMING == "quarter"     , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "quarter", fwd_list_start, fwd_list_count, "text")     ,
      TIMING == "rsoquarter"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "rsoquarter", fwd_list_start, fwd_list_count, "text")  ,
      TIMING == "season"      , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "season", fwd_list_start, fwd_list_count, "text")      ,
      TIMING == "half-year"   , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-year", fwd_list_start, fwd_list_count, "text")   ,
      TIMING == "year"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "year", fwd_list_start, fwd_list_count, "text")        ,
      TIMING == "gas year"    , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "gas year", fwd_list_start, fwd_list_count, "text")    ,
      default = as.list(NA_character_)
    )
  ]

  ## Create fwd list ----
  ## for forward drop-down key
  dt[,
    FWD_DROPDOWN := data.table::fcase(
      TIMING == "prompt"      , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "prompt", return_type = "fwd")         ,
      TIMING == "spot"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "spot", return_type = "fwd")           ,
      TIMING == "dated"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "dated", return_type = "fwd")          ,
      TIMING == "day-ahead"   , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "day-ahead", return_type = "fwd")      ,
      TIMING == "weekend"     , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "weekend", return_type = "fwd")        ,
      TIMING == "week-ahead"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(date = report_date, timing = "week-ahead", return_type = "fwd")     ,
      TIMING == "day"         , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "day", fwd_list_start, fwd_list_count, "fwd")          ,
      TIMING == "week"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "week", fwd_list_start, fwd_list_count, "fwd")         ,
      TIMING == "week number" , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "week number", fwd_list_start, fwd_list_count, "text") ,
      TIMING == "half-month"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-month", fwd_list_start, fwd_list_count, "fwd")   ,
      TIMING == "month"       , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "month", fwd_list_start, fwd_list_count, "fwd")        ,
      TIMING == "quarter"     , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "quarter", fwd_list_start, fwd_list_count, "fwd")      ,
      TIMING == "rsoquarter"  , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "rsoquarter", fwd_list_start, fwd_list_count, "fwd")   ,
      TIMING == "season"      , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "season", fwd_list_start, fwd_list_count, "fwd")       ,
      TIMING == "half-year"   , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "half-year", fwd_list_start, fwd_list_count, "fwd")    ,
      TIMING == "year"        , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "year", fwd_list_start, fwd_list_count, "fwd")         ,
      TIMING == "gas year"    , argusDT.PriceStudioMain::fct_timing_dropdownlist(report_date, "gas year", fwd_list_start, fwd_list_count, "fwd")     ,
      default = as.list(NA_character_)
    )
  ]

  ## Add EXPECTED_DATE ----
  fct_calc_expected_dates(dt, calendars)

  ## Create PUBLISH column ----
  dt[,
    PUBLISH := data.table::fcase(
      QUOTE_ID == SUSPENDED_QUOTE_ID    , FALSE ,
      PUBLICATION_DATE == EXPECTED_DATE , TRUE  ,
      default = FALSE
    )
  ]

  ## Create FINAL column ----
  dt[, FINAL := FALSE]

  ## Create OVERRIDE_PUBLISH column ----
  dt[, OVERRIDE_PUBLISH := FALSE]

  ## Create PUBLISH_EXPECTED as a static column ----
  dt[,
    PUBLISH_EXPECTED := data.table::fcase(
      QUOTE_ID == SUSPENDED_QUOTE_ID    , FALSE ,
      PUBLICATION_DATE == EXPECTED_DATE , TRUE  ,
      default = FALSE
    )
  ]

  ## Check holidays ----

  ## Set PUBLISH to FALSE if report date is a holiday in an assessment's
  ## holiday region
  holiday_regions <- NULL

  if (!is.null(dt_holidays)) {
    holiday_regions <- unique(dt_holidays[HOLIDAY_DATE == report_date]$HOLIDAY_REGION)
  }

  if (length(holiday_regions) > 0) {
    dt[HOLIDAY_REGION %in% holiday_regions, PUBLISH := FALSE]
    dt[HOLIDAY_REGION2 %in% holiday_regions, PUBLISH := FALSE]
    dt[HOLIDAY_REGION3 %in% holiday_regions, PUBLISH := FALSE]
  }

  ## Check DESC_SHORT & create DESC_LONG----
  ## Check if there is a short description and, if so, substitute for
  ## the code_description and store long description separately
  dt[, CODE_DESC_LONG := CODE_DESCRIPTION]
  dt[!is.na(DESC_SHORT), CODE_DESCRIPTION := DESC_SHORT]

  ## Create FORWARD & BASIS & NOTES ----
  dt[, `:=`(FORWARD = NA_character_, BASIS = NA_integer_, NOTES = NA_character_)]

  ## Create OVERRIDE columns----
  dt[,
    OVERRIDE := data.table::fcase(
      TYPE == "Calculated" , FALSE ,
      default = NA
    )
  ]

  editable_timings <- c(
    "week",
    "week number",
    "half-month",
    "month",
    "quarter",
    "rsoquarter",
    "season",
    "half-year",
    "year",
    "gas year",
    "cycle"
  )

  dt[,
    OVERRIDE_DBR := data.table::fcase(
      EDIT_DBR == TRUE                 , NA    ,
      DBR_TIMING %in% editable_timings , FALSE ,
      default = NA
    )
  ]

  dt[,
    OVERRIDE_FWD := data.table::fcase(
      EDIT_FWD == TRUE             , NA    ,
      TIMING %in% editable_timings , FALSE ,
      default = NA
    )
  ]

  ## Create ORG_TYPE column----
  dt[, ORG_TYPE := TYPE]

  ## Create custom column----
  dt[, CUSTOM := NA]

  ## Create copy_prior_prices column----
  dt[, COPY_PRIOR_PRICES := ifelse(TYPE == "Input", TRUE, NA)]

  ## Create notes_popup column----
  dt[, NOTES_POPUP := "\u270E"]

  return(dt)
}
