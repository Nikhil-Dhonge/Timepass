#' fct_create_price_components_tbls
#' @description Create pivoted price components table based on formula/qpts
#' @param price_components_dt (Required) Data.table object containing price components
#' @param transpose (Optional) transpose the output table
#' @param group_by_qpt (Optional) Data.table object containing the app
#' @param dt_prc_asmp  A data.table containing the formula settings
#' @return list of price components tables
#' @noRd
fct_create_price_components_tbls <- function(price_components_dt, dt_prc_asmp) {
  log_info("fct_create_price_components_tbls", level = 2)

  dt <- data.table::as.data.table(price_components_dt)

  if (nrow(dt) < 1) {
    log_warn(
      "Failed to create price components tables due to missing prices in csv",
      prompt = TRUE,
      title = "Price components missing",
      type = "error"
    )
    return(NULL)
  }

  # Format VALUE (round till 2 decimals)
  dt[, VALUE := as.character(VALUE)]
  dt[grepl("^-?\\d*\\.?\\d+$", VALUE), VALUE := as.character(argus_round(as.numeric(VALUE), 2))]
  dt[, DESCRIPTION := factor(DESCRIPTION, levels = unique(DESCRIPTION))]

  # Merge with formula notes for table header
  dt_notes <- unique(data.table::as.data.table(dt_prc_asmp[, .(FORMULA_ID, FORMULA_NOTES)]))
  dt <- merge(dt, dt_notes, by.x = "PRC_FORMULA_ID", by.y = "FORMULA_ID", all.x = TRUE)
  dt[, TABLE_KEY := gsub("^_|_$", "", gsub("[^A-Za-z0-9]+", "_", tolower(FORMULA_NOTES)))]

  # Group by Formula ID
  dt_split <- split(dt, by = "TABLE_KEY")
  result <- lapply(dt_split, function(subdt) {
    data.table::dcast(subdt, QUOTE_PRICETYPE_ID ~ DESCRIPTION, value.var = "VALUE")
  })

  table_names <- unique(dt[, .(TABLE_KEY, FORMULA_NOTES)])
  result_names <- table_names[match(names(result), TABLE_KEY), FORMULA_NOTES]
  names(result) <- result_names # Keep original FORMULA_NOTES

  # Post-process: Trim QPT to PA code and rename column
  result <- lapply(result, function(tbl) {
    if ("QUOTE_PRICETYPE_ID" %in% names(tbl)) {
      tbl$QUOTE_PRICETYPE_ID <- paste0(
        "PA00",
        substr(
          as.character(tbl$QUOTE_PRICETYPE_ID),
          1,
          nchar(as.character(tbl$QUOTE_PRICETYPE_ID)) - 6
        )
      )
      data.table::setnames(tbl, "QUOTE_PRICETYPE_ID", "Code ID")
    }
    tbl
  })

  return(result)
}
