#' fct_market_survey_create_table
#' @description Function to create the data.table needed for the market survey.
#' @param report_date date for the current report date.
#' @param dt_market_content data.table object containing the app metadata.
#' @param dt_codemaster data.table object containing the PA code metadata.
#' @param dt_market_survey data.table containing the market survey data.
#' @param dt_pivot data.table containing the pivoted data.
#' @param prefill_company_switch logical indicating whether to prefill the
#'   company based on most-used TRADER_ID for the given QUOTE_ID.
#' @return data.table
#' @export
fct_market_survey_create_table <- function(
  report_date,
  dt_market_content,
  dt_codemaster,
  dt_market_survey,
  dt_pivot = NULL,
  prefill_company_switch = FALSE
) {
  log_info("fct_market_survey_create_table", level = 2)

  # Company prefill deafault
  default_trader_id <- NA_integer_

  if (isTRUE(prefill_company_switch) && !is.null(dt_pivot)) {
    # Get QUOTE_ID from dt_codemaster
    quote_ids <- unique(dt_codemaster$QUOTE_ID)

    if (length(quote_ids) > 0) {
      # Get most-used TRADER_ID for this quote
      default_trader_id <- fct_market_survey_get_default_company(
        dt_pivot = dt_pivot,
        quote_id = quote_ids[1]
      )

      # Convert NULL to NA
      if (is.null(default_trader_id)) {
        default_trader_id <- NA_integer_
      }

      # Log if we're prefilling
      if (!is.na(default_trader_id)) {
        log_info(
          glue::glue("Prefilling TRADER_ID: {default_trader_id}"),
          level = 3
        )
      }
    }
  }

  dt <- dt_codemaster[,
    .SD,
    .SDcols = c(
      "QUOTE_PRICETYPE_ID",
      "QUOTE_ID",
      "CODE_ID",
      "CODE_DESCRIPTION",
      "TS",
      "CF",
      "PT",
      "TIMING",
      "UNIT_ID1",
      "UNIT_ID2",
      "DIFF_BASE_ID",
      "DIFF_BASE",
      "DBR_TIMING_ID",
      "DBR_TIMING",
      "DECIMALPLACES",
      "PCT_LIMIT",
      "ALLOWUPLOAD_YN",
      "CHANGE_MODE",
      "FREQUENCY",
      "HOLIDAY1",
      "HOLIDAY2",
      "DISPLAY_TYPE_ID",
      "INTERNAL_ONLY"
    )
  ]

  ## Create PA_CODE ----
  dt[, PA_CODE := paste0("PA", sprintf("%07d", dt$CODE_ID))]

  ## Create OUT_DIFF_TYPE ----
  pt_diffs <- argusDT.PriceStudioMain::dt_pricetype[OUT_DIFF_TYPE == "Differential"]$PRICE_TYPE_ID

  dt[, OUT_DIFF_TYPE := data.table::fifelse(PT %in% pt_diffs, "Differential", "Outright")]

  ## Create QPT_MID ----
  dt[
    argusDT.PriceStudioMain::dt_pricetype,
    QPT_MID := paste0(QUOTE_ID, stringr::str_pad(i.PT_MID, width = 2, pad = "0")),
    on = "PT == PRICE_TYPE_ID"
  ]

  dt_market_content0 <- data.table::copy(dt_market_content)

  dt_market_content0[,
    OUT_DIFF_TYPE := data.table::fifelse(PT %in% pt_diffs, "Differential", "Outright")
  ]

  ## Keep ony QPTs with market survey
  dt_market_content0 <- dt_market_content0[MARKET_SURVEY_YN == "Y"]

  ## Add PRC_MARKET_CONTENT columns ----
  dt[
    dt_market_content0,
    `:=`(
      MARKET = i.MARKET,
      SECTION = i.SECTION,
      TYPE = i.TYPE,
      DISPLAY_ORDER = i.DISPLAY_ORDER,
      EDIT_MID = (i.EDIT_MID == "Y"),
      EDIT_FWD = (i.EDIT_FWD == "Y"),
      EDIT_DBR = (i.EDIT_DBR == "Y"),
      SPREAD = ifelse(i.EDIT_SPREAD == "Y", NA_real_, i.SPREAD),
      DESC_SHORT = i.DESC_SHORT,
      ALLOWZERO_YN = i.ALLOWZERO_YN,
      HOLIDAY_REGION = i.HOLIDAY_REGION,
      HOLIDAY_REGION2 = i.HOLIDAY_REGION2,
      HOLIDAY_REGION3 = i.HOLIDAY_REGION3,
      HOLIDAY_KEY = i.HOLIDAY_KEY,
      DTE_FORMULA = i.DTE_FORMULA,
      PACKAGE = i.PACKAGE,
      REGION = i.REGION,
      EDIT_SPREAD = (i.EDIT_SPREAD == "Y")
    ),
    on = c("QUOTE_ID", "OUT_DIFF_TYPE")
  ]

  ## Create IN_MARKET_CONTENT ----
  ## to later remove duplicate midpoints
  dt[dt_market_content0, IN_MARKET_CONTENT := TRUE, on = "QUOTE_PRICETYPE_ID"]

  ## Check DESC_SHORT ----
  ## Check if there is a short description and, if so, substitute for
  ## the code_description
  dt[!is.na(DESC_SHORT), CODE_DESCRIPTION := DESC_SHORT]

  ## Add PUBLICATION_DATE from report date
  dt[, PUBLICATION_DATE := as.Date(report_date)]

  ## Filter for input types
  dt <- dt[TYPE != "Imported"]

  ## Add additional market survey columns ----
  dt[, `:=`(
    TRADER_ID = default_trader_id,
    COMM_CONTACT_NAME = NA_character_,
    PRICE_CATEGORY_ID = NA_integer_,
    COMM_METHOD_ID = NA_integer_,
    COMM_REPORTER = NA_character_,
    COMM_TIMESTAMP = NA_character_,
    COMM_TIMESTAMP_UTC = NA_character_,
    PORT_ID = NA_integer_,
    DELIVERY_PERIOD_ID = NA_integer_,
    DELIVERY_YEAR = NA_integer_,
    INCLUDE = TRUE,
    DELETED = FALSE,
    NOTES = NA_character_,
    VALUE = NA_real_,
    PUBLISH = TRUE,
    NEW = TRUE,
    EDITED = FALSE,
    MARKET_SURVEY_ITEM_ID = 1,
    ADD = NA
  )]

  return(dt)
}
