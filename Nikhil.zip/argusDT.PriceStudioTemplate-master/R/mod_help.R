#' help UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @noRd
mod_help_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_help_ui ns:", get_ns(ns), level = 3)

  shiny::tagList(
    bslib::navset_tab(
      id = ns("help_tabs"),
      bslib::nav_panel(
        id = ns("user_ref"),
        title = "User Guide",
        shiny::htmlOutput(ns("html_user_g"))
      )
    )
  )
}

#' help Server Functions
#' @param id A shiny id.
#' @noRd
mod_help_server <- function(id) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_help_server ns:", get_ns(ns), level = 3)

    output$html_user_g <- shiny::renderUI({
      htmltools::tags$iframe(
        seamless = "seamless",
        src = "www\\user_guide.html",
        style = "width:100%; height:680px; border:none;"
      )
    })
  })
}
