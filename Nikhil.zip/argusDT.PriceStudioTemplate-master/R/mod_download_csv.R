#' download_csv UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @param width The width of the widget.
#' @param disabled_msg Tooltip when widget is disabled. Widget isn't disabled
#' if NULL.
#' @param tooltip_placement Position of the tooltip relative to the widget.
#' One of "auto", "top", "right", "bottom", "left".
#' @param tooltip_dark logical TRUE to show a dark background tooltip.
#' @inheritParams shiny::downloadButton
#' @inheritParams bslib::tooltip
mod_download_csv_ui <- function(
  id,
  label = "Download",
  width = "100%",
  icon = shiny::icon("download"),
  disabled_msg = NULL,
  tooltip_placement = c("auto", "top", "right", "bottom", "left"),
  tooltip_dark = TRUE,
  ...
) {
  ns <- shiny::NS(id)

  tooltip_placement <- match.arg(tooltip_placement)

  log_info("mod_download_csv_ui ns:", get_ns(ns), level = 3)

  outputId <- ns("download_csv")
  tooltipId <- ns("download_csv-tooltip")

  log_info("download_csv ID:", outputId, level = 4)

  widget <- shiny::downloadButton(
    outputId = outputId,
    label = label,
    icon = icon
  )

  shiny::tagList(
    bslib::tooltip(
      disabled_msg,
      placement = tooltip_placement,
      options = list(
        customClass = ifelse(tooltip_dark, "tooltip-dark", ""),
        trigger = ifelse(is.null(disabled_msg), "manual", "hover focus")
      ),
      trigger = shiny::tags$div(
        id = tooltipId,
        style = htmltools::css(width = shiny::validateCssUnit(width)),
        class = "btn-default-container",

        if (is.null(disabled_msg)) {
          widget
        } else {
          shinyjs::disabled(widget)
        }
      )
    )
  )
}


#' download_csv Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @param full Logical indicating whether to download full datawell (TRUE) or
#' filtered datawell (FALSE).
#' @param enable_trigger Character name of trigger used to enable
#' the widget. Ignored if NULL.
#' @param disable_trigger Character name of trigger used to disable
#' the widget. Ignored if NULL.
mod_download_csv_server <- function(id, r, full, enable_trigger = NULL, disable_trigger = NULL) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_download_csv_server ns:", get_ns(ns), level = 3)

    outputId <- ns("download_csv")
    tooltipId <- ns("download_csv-tooltip")

    log_info("download_csv ID:", outputId, level = 4)

    ## Save file to S3 and download file locally
    output$download_csv <- shiny::downloadHandler(
      filename = function() {
        r$rv$csv_filename <- argusDT.PriceStudioMain::fct_get_csv_filename(
          report_date = r$rv$report_date,
          basename = golem::get_golem_options("csv_filename"),
          timezone = r$rv$user_timezone,
          region = r$rv$region,
          with_timestamp = TRUE
        )
      },
      content = function(file) {
        if (full == FALSE) {
          datawell <- r$rv$dt_datawell_filtered
        } else {
          datawell <- r$rv$dt_datawell_full
        }

        ## Do not download file if `datawell` is NULL
        if (is.null(datawell)) {
          log_warn(
            "Datawell is empty",
            prompt = TRUE,
            title = "No price data available",
            type = "info"
          )
        }

        shiny::req(datawell)

        if (nrow(datawell) == 0) {
          log_warn(
            "Nothing to download",
            prompt = TRUE,
            title = "No price data available",
            type = "info"
          )
        } else {
          shiny::req(nrow(datawell) > 0)

          ### Check if summary needs to be refreshed
          max_staged_time <- argusDT.PriceStudioMain::fct_get_max_time_staged(
            app_id = get_config("application_id"),
            markets = r$rv$summary_market,
            region = r$rv$region,
            db_env = r$rv$db_env,
            connection = r$rv$ora_connection
          )

          max_loaded_time <- max(
            r$rv$dt_summary_report_day[MARKET %in% r$rv$summary_market]$TIME_STAGED
          )

          if (is_truthy(max_staged_time$TIME_STAGED != max_loaded_time)) {
            shiny::showModal(shiny::modalDialog(
              title = "New prices were saved",
              "New prices were recently saved
                Before uploading, consider refreshing the Summary to obtain the latest changes.",
              easyClose = FALSE,
              bslib::layout_columns(
                col_widths = 6,
                max_height = "100%",

                shiny::modalButton("OK") %>% shiny::tagAppendAttributes(class = "btn-default")
              )
            ))
          }

          ## Save file to S3 bucket
          argusDT.PriceStudioMain::fct_save_csv_to_s3(
            dt_csv = datawell,
            file_path = file.path(r$rv$s3_csv_dir, r$rv$csv_filename),
            s3_bucket = get_config("s3_bucket")
          )

          ## Download file locally
          data.table::fwrite(
            x = datawell,
            file = file,
            eol = "\r\n",
            quote = FALSE,
            dateTimeAs = c("ISO", "squash", "epoch", "write.csv")[4]
          )
        }
      }
    )

    # Enable button ----
    ## If `enable_trigger` provided then use observe event to enable else
    ## enable on loading
    if (!is.null(enable_trigger)) {
      shiny::observeEvent(
        gargoyle::watch(enable_trigger),
        {
          log_info("observeEvent:", outputId, "enable", level = 1)

          shinyjs::enable(id = outputId, asis = TRUE)
          shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
            id = tooltipId,
            action = "disable"
          ))
        },
        ignoreInit = TRUE
      )
    } else {
      shinyjs::enable(id = outputId, asis = TRUE)
      shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
        id = tooltipId,
        action = "disable"
      ))
    }

    # Disable button ----
    if (!is.null(disable_trigger)) {
      shiny::observeEvent(
        gargoyle::watch(disable_trigger),
        {
          log_info("observeEvent:", outputId, "disable", level = 1)

          shinyjs::disable(id = outputId, asis = TRUE)
          shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
            id = tooltipId,
            action = "enable"
          ))
        },
        ignoreInit = TRUE
      )
    }
  })
}
