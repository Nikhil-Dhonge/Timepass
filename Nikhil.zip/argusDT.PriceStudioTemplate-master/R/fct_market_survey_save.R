#' Stage Market Survey
#' @description A function to stage the market survey prices.
#' @param dt_market_survey Required. (data.table) Contains all of today's
#' market_survey data.
#' @param report_date date for the current report date.
#' @param application_id numeric application id
#' @param market Selected market
#' @param username Required. (character) Username of the user.
#' @param timezone users timezone
#' @param session_id Required. (numeric) ID for the session.
#' @param process_id Required. (numeric) ID for the process.
#' @param app_version Application version.
#' @inheritParams argusDT.PriceStudioMain::fct_get_credentials
#' @inheritParams argusDT.PriceStudioMain::fct_oracle_get_data
#' @inherit argusDT.PriceStudioMain::fct_oracle_get_data return
#' @export
fct_market_survey_save <- function(
  dt_market_survey,
  report_date,
  application_id,
  market,
  username,
  timezone,
  session_id,
  db_env = c("DEV", "UAT", "LIVE"),
  process_id = golem::get_golem_options("p_id"),
  connection = NULL,
  app_version = NA_character_
) {
  log_info("fct_market_survey_save", level = 2)

  db_env <- match.arg(db_env)

  dt <- data.table::copy(dt_market_survey)

  # Save only rows for the selected market
  dt <- dt[MARKET == market]

  if (dt[, .N] == 0) {
    log_info("Market Survey: No changes to save.")
    return(0)
  }

  # Force INCLUDE to FALSE if DELETED is TRUE
  dt[DELETED == TRUE, INCLUDE := FALSE]

  # Add arg columns ----
  dt[, USERNAME := paste0("'", username, "'")]
  dt[, USER_TIMEZONE := paste0("'", timezone, "'")]
  dt[, PROCESS_ID := process_id]
  dt[, SESSION_ID := session_id]

  dt[, PUBLICATION_DATE := report_date]
  dt[, APP_ID := application_id]
  dt[, APP_VERSION := app_version]

  # Columns from dt ----
  ## Select dt columns in same order as in REPOSITORY_MARKET_SURVEY table
  cols <- c(
    "MARKET_SURVEY_ITEM_ID",
    "QUOTE_PRICETYPE_ID",
    "QUOTE_ID",
    "CODE_ID",
    "TS",
    "CF",
    "PT",
    "APP_ID",
    "PUBLICATION_DATE",
    "VALUE",
    "UNIT_ID1",
    "UNIT_ID2",
    "PORT_ID",
    "TRADER_ID",
    "DELIVERY_PERIOD_ID",
    "DELIVERY_YEAR",
    "COMM_METHOD_ID",
    "COMM_TIMESTAMP",
    "COMM_TIMESTAMP_UTC",
    "COMM_CONTACT_NAME",
    "COMM_REPORTER",
    "NOTES",
    "INCLUDE",
    "DELETED",
    "PROCESS_ID",
    "SESSION_ID",
    "USERNAME",
    "USER_TIMEZONE",
    "PRICE_CATEGORY_ID",
    "APP_VERSION"
  )

  dt <- dt[, .SD, .SDcols = cols]

  # Fields in REPOSITORY_MARKET_SURVEY ----
  fields <- c(
    "market_survey_item_id",
    "quote_pricetype_id",
    "quote_id",
    "code_id",
    "timestamp_id",
    "continuous_forward",
    "pricetype_id",
    "prc_application_id",
    "publication_date",
    "value",
    "unit_id1",
    "unit_id2",
    "port_id",
    "trader_id",
    "delivery_period_id",
    "delivery_year",
    "comm_method_id",
    "comm_timestamp",
    "comm_timestamp_utc",
    "comm_contact_name",
    "comm_reporter",
    "notes",
    "omitted_yn",
    "deleted_yn",
    "process_id",
    "session_id",
    "username",
    "user_timezone",
    "price_category_id",
    "app_version"
  )

  # Reformat columns ----
  ## Date columns ----
  dt[, PUBLICATION_DATE := paste0("DATE'", format(PUBLICATION_DATE, "%Y-%m-%d"), "'")]

  ## Timestamp with tz columns ----
  ### Apply users timezone to the timestamp
  dt[,
    COMM_TIMESTAMP := data.table::fifelse(
      is.na(COMM_TIMESTAMP),
      NA_character_,
      paste0("TO_TIMESTAMP_TZ('", COMM_TIMESTAMP, "','YYYY-MM-DD HH24:MI:SS TZR')")
    )
  ]

  dt[,
    COMM_TIMESTAMP_UTC := data.table::fifelse(
      is.na(COMM_TIMESTAMP_UTC),
      NA_character_,
      paste0("TO_TIMESTAMP_TZ('", COMM_TIMESTAMP_UTC, "','YYYY-MM-DD HH24:MI:SS TZR')")
    )
  ]

  ## Logical columns ----
  dt[, INCLUDE := data.table::fifelse(INCLUDE == TRUE, "'Y'", "'N'")]
  dt[, DELETED := data.table::fifelse(DELETED == TRUE, "'Y'", "'N'")]

  ## Character columns ----
  dt[
    !is.na(COMM_CONTACT_NAME),
    COMM_CONTACT_NAME := data.table::fifelse(
      COMM_CONTACT_NAME == "",
      NA_character_,
      paste0("'", COMM_CONTACT_NAME, "'")
    )
  ]

  dt[
    !is.na(COMM_REPORTER),
    COMM_REPORTER := data.table::fifelse(
      COMM_REPORTER == "",
      NA_character_,
      paste0("'", COMM_REPORTER, "'")
    )
  ]

  dt[!is.na(NOTES), NOTES := stringr::str_replace_all(NOTES, "'", "''")]
  dt[
    !is.na(NOTES),
    NOTES := data.table::fifelse(NOTES == "", NA_character_, paste0("'", NOTES, "'"))
  ]

  dt[!is.na(APP_VERSION), APP_VERSION := paste0("'", APP_VERSION, "'")]

  # Create query ----
  ## Query pieces ----
  query_start <- glue::glue(
    "INSERT INTO staff.repository_market_survey ({glue::glue_collapse(fields, ',')}) SELECT * FROM ("
  )

  query_first_row <- glue::glue(
    "SELECT {glue::glue_collapse(glue::glue('NULL {fields}'), ', ')} FROM dual UNION ALL"
  )

  query_end <- glue::glue(") WHERE MARKET_SURVEY_ITEM_ID IS NOT NULL")

  ## Build rows ----
  dt[, QUERY := do.call(paste, c(.SD, sep = ",")), .SDcols = cols]
  dt[, QUERY := paste0("SELECT ", QUERY, " FROM dual")]
  dt[, QUERY := gsub("NA", "NULL", QUERY)]

  ## Combine parts ----
  query <- paste(
    query_start,
    query_first_row,
    paste(dt$QUERY, collapse = " UNION ALL \n"),
    query_end,
    sep = "\n"
  )

  # Execute query ----
  cred <- argusDT.PriceStudioMain::fct_get_credentials(
    db_env = db_env,
    db_type = "oracle",
    db_user = "staff"
  )

  modified_rows <- argusDT.PriceStudioMain::fct_oracle_modify_data(
    uid = cred$user,
    pwd = cred$password,
    dsn = cred$dsn,
    query = query,
    connection = connection
  )

  ## Exit if error
  if (inherits(modified_rows, c("try-error", "error"))) {
    return(-99)
  }

  ## Notify user of how many prices were staged
  log_info("number of rows modified: ", modified_rows, level = 3)

  return(modified_rows)
}
