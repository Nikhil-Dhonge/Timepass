#' Infix operators
#'
#' See the following for details:
#' \itemize{
#'   \item \code{magrittr::\link[magrittr:pipe]{\%>\%}}
#'   \item \code{lubridate::\link[lubridate:mplus]{\%m+\%}}
#'   \item \code{lubridate::\link[lubridate:mplus]{\%m-\%}}
#'   \item \code{data.table::\link[data.table]{data.table}}
#' }
#'
#' @name %>%
#' @rdname infix
#' @keywords internal
#' @export
#' @importFrom magrittr %>%
#' @importFrom lubridate %m+%
#' @importFrom lubridate %m-%
#' @importFrom data.table data.table
NULL
