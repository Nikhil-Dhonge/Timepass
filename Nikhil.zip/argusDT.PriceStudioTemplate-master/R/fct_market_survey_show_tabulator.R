#' fct_market_survey_show_tabulator
#' @description A function to add tabulator elements to a selected element id
#' @param input,session,r Internal parameters for {shiny}.
#' @param market character for the selected market
#' @param section character for the selected section
#' @param box_id character string used to identify the nav panel box
#' @return A character list of market survey tabulator ids (invisibly)
#' @export
fct_market_survey_show_tabulator <- function(input, session, r, market, section, box_id) {
  ns <- session$ns

  log_info("fct_market_survey_show_tabulator ns:", get_ns(ns), level = 2)

  ## Remove prior tables ----
  if (length(r$market_survey$tabulator_ids[[market]][[section]]) > 0) {
    purrr::walk(
      .x = r$market_survey$tabulator_ids[[market]][[section]],
      .f = function(x, r) {
        id <- ns(x)
        x_click <- paste0(x, "_cell_click")
        x_update <- paste0(x, "_update")
        x_update_market <- paste0(x, "_market")
        x_add <- paste0(x, "_add")
        x_notes <- paste0(x, "_notes")
        x_aggregation <- paste0(x, "_aggregation")

        ## Remove UI
        log_info("removeUI:", id, level = 3)

        shiny::removeUI(selector = paste0("#", id, "-text_output"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-aggregations"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-tabulator"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-div"), immediate = TRUE)

        ## Remove inputs
        argusDT.PriceStudioMain::fct_remove_shiny_inputs(id = x, input, ns)

        ## Remove reactive variables
        r$market_survey[[x_aggregation]] <- NULL

        ## Remove observeEvents
        if (!is.null(r$market_survey$observeEvent[[x]])) {
          r$market_survey$observeEvent[[x]]$destroy()
          r$market_survey$observeEvent[[x]] <- NULL
        }
        if (!is.null(r$market_survey$observeEvent[[x_click]])) {
          r$market_survey$observeEvent[[x_click]]$destroy()
          r$market_survey$observeEvent[[x_click]] <- NULL
        }
        if (!is.null(r$market_survey$observeEvent[[x_add]])) {
          r$market_survey$observeEvent[[x_add]]$destroy()
          r$market_survey$observeEvent[[x_add]] <- NULL
        }
        if (!is.null(r$market_survey$observeEvent[[x_update]])) {
          r$market_survey$observeEvent[[x_update]]$destroy()
          r$market_survey$observeEvent[[x_update]] <- NULL
        }
        if (!is.null(r$market_survey$observeEvent[[x_update_market]])) {
          r$market_survey$observeEvent[[x_update_market]]$destroy()
          r$market_survey$observeEvent[[x_update_market]] <- NULL
        }
        if (!is.null(r$market_survey$observeEvent[[x_notes]])) {
          r$market_survey$observeEvent[[x_notes]]$destroy()
          r$market_survey$observeEvent[[x_notes]] <- NULL
        }
        if (!is.null(r$market_survey$observeEvent[[x_aggregation]])) {
          r$market_survey$observeEvent[[x_aggregation]]$destroy()
          r$market_survey$observeEvent[[x_aggregation]] <- NULL
        }
      },
      r = r
    )
  }

  ## Add new tables ----
  ### Filter for the market survey market and section
  dt <- r$market_survey$dt_pivot[MARKET == market & SECTION == section]
  dt_key <- dt[, .SD[which.min(MARKET_SURVEY_ITEM_ID)], by = QPT_MID]

  r$market_survey$tabulators[[market]][[section]] <- paste0(
    dt_key$CODE_DESCRIPTION,
    " (",
    paste(dt_key$PA_CODE, dt_key$TS, dt_key$CF, dt_key$PT_MID, sep = "-"),
    ")"
  )

  r$market_survey$tabulator_ids[[market]][[section]] <- as.character(dt_key$QPT_MID)

  ### Insert UI, all input tables
  purrr::walk(
    .x = ns(r$market_survey$tabulator_ids[[market]][[section]]),
    .f = mod_market_survey_tabulator_ui,
    box_id = ns(box_id)
  )

  ### Add tabulator server
  purrr::walk2(
    .x = r$market_survey$tabulator_ids[[market]][[section]],
    .y = r$market_survey$tabulators[[market]][[section]],
    .f = mod_market_survey_tabulator_server,
    dt = dt,
    r = r
  )
}
