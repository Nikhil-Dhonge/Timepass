#' tabulator_indesign UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @param input_box_id The input box id where to insert the tabulator table.
#' @noRd
mod_tabulator_indesign_ui <- function(id, input_box_id) {
  ns <- shiny::NS(id)

  log_info("mod_tabulator_indesign_ui ns:", get_ns(ns), level = 3)

  id_div <- ns("div")
  id_textoutput <- ns("text_output")
  id_tabulator <- ns("tabulator")

  log_info("div ID: ", id_div, level = 4)
  log_info("textOutput ID: ", id_textoutput, level = 4)
  log_info("tabulatorOutput ID: ", id_tabulator, level = 4)

  shiny::insertUI(
    selector = paste0("#", input_box_id),
    where = "beforeEnd",
    ui = htmltools::tags$div(
      class = "tabulator-table-ui",
      id = id_div,
      shiny::strong(
        shiny::textOutput(
          outputId = id_textoutput
        )
      ),
      argusDS.tabulator::tabulatorOutput(
        outputId = id_tabulator,
        height = "100%",
        width = "auto"
      )
    ),
    immediate = TRUE
  )
}


#' tabulator_indesign Server Functions
#' @param id A shiny id.
#' @param dt Data table to display in the tabulator table.
#' @noRd
mod_tabulator_indesign_server <- function(id, dt) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_tabulator_indesign_server ns:", get_ns(ns), level = 3)

    ## Add range name
    output$text_output <- shiny::renderText(id)

    ## Add tabulator table
    output$tabulator <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator"), level = 4)

      argusDS.tabulator::tabulator(
        data = dt,
        autoColumns = TRUE,
        layout = "fitDataTable",
        autoColumnsDefinitions = htmlwidgets::JS(
          " function(definitions) {

              definitions.forEach((column) => {

                var regex = /[X|V][0-9]+/;

                if(regex.test(column.title)) {
                  column.title = '';
                }

                column.headerSort = false;
                column.headerHozAlign = 'center'

              });

              return definitions;

            }"
        )
      )
    })
  })
}
