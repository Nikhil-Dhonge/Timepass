#' settings UI Function
#' @description A shiny Module.
#' @param id,input,output,session Internal parameters for {shiny}.
#' @noRd
mod_settings_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_settings_ui ns:", get_ns(ns), level = 2)

  bslib::layout_column_wrap(
    width = 1 / 3,
    class = "settings-box",

    bslib::card(
      bslib::layout_columns(
        col_widths = 12,

        # Report date picker ----
        shinyjs::disabled(
          argusDT.PriceStudioMain::mod_dateinput_ui(
            id = ns("report_date"),
            label = "Report date",
            width = "100%",
            disabled_msg = "Select a region first...",
            tooltip_placement = "bottom",
            tooltip_dark = "FALSE"
          )
        ),

        # Delete app prices button ----
        if (get_config("show_delete_buttons") && golem::get_golem_options("db_env") != "LIVE") {
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("delete_all_prices"),
            label = "Delete all prices",
            disabled_msg = "Select a region / market first...",
            tooltip_dark = FALSE,
            tooltip_placement = "right",
            icon = shiny::icon("trash", lib = "glyphicon")
          )
        },

        # Delete market prices button ----
        if (get_config("show_delete_buttons") && golem::get_golem_options("db_env") != "LIVE") {
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("delete_market_prices"),
            label = "Delete market prices",
            disabled_msg = "Select a region / market first...",
            tooltip_dark = FALSE,
            tooltip_placement = "right",
            icon = shiny::icon("trash", lib = "glyphicon")
          )
        }
      )
    ),

    if (get_config("show_tab_price_input")) {
      bslib::card(
        bslib::layout_columns(
          col_widths = 12,

          # Ex rate day picker ----
          argusDT.PriceStudioMain::mod_selectizeinput_ui(
            id = ns("exrate_day_offset"),
            label = "Forex day offset",
            choices = get_config("forex_day_offsets"),
            selected = golem::get_golem_options("exrate_day_offset"),
            options = list(dropdownParent = "body")
          ),

          # Ex rate time picker ----
          argusDT.PriceStudioMain::mod_selectizeinput_ui(
            id = ns("exrate_time"),
            label = "Forex timestamp",
            choices = get_config("forex_timestamps"),
            selected = golem::get_golem_options("exrate_time"),
            options = list(dropdownParent = "body")
          )
        )
      )
    },

    if (get_config("show_tab_price_input")) {
      bslib::card(
        bslib::layout_columns(
          col_widths = 12,

          # Get metadata button ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("get_metadata"),
            label = "Get metadata",
            disabled_msg = "Select a region / market first...",
            tooltip_dark = FALSE,
            icon = shiny::icon("cloud-download", lib = "glyphicon")
          ),

          # Reset inputs button ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("reset_to_staged"),
            label = "Reset inputs",
            disabled_msg = "Select a region / market first...",
            tooltip_dark = FALSE,
            icon = shiny::icon("refresh", lib = "glyphicon")
          ),

          # Show/hide columns button ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("visible_columns"),
            label = "Show/Hide Columns",
            disabled_msg = "Select a region first...",
            tooltip_dark = FALSE,
            icon = shiny::icon("table-columns")
          )
        )
      )
    }
  )
}

#
#' settings Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_settings_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_settings_server ns:", get_ns(ns), level = 2)

    # Initialise triggers ----
    gargoyle::init(ns("visible_columns"))

    # Update report date picker ----
    shiny::updateDateInput(
      session = session,
      inputId = "report_date-dateinput",
      value = r$rv$report_date,
      min = r$app_start_date,
      max = if (shiny::isTruthy(r$app_end_date)) r$app_end_date
    )

    # Add widget modules ----
    ## Date pickers ----
    ### Report date ----
    argusDT.PriceStudioMain::mod_dateinput_server(
      id = "report_date",
      rv = r$rv,
      enable_trigger = "hide_waiter",
      disable_trigger = "show_waiter",
      triggers = c("show_waiter", "change_dates")
    )

    ## Pickers ----
    ### Ex rate day ----
    argusDT.PriceStudioMain::mod_selectizeinput_server(
      id = "exrate_day_offset",
      rv = r$rv,
      choices_rv = "forex_day_offsets"
    )

    ### Ex rate time ----
    argusDT.PriceStudioMain::mod_selectizeinput_server(
      id = "exrate_time",
      rv = r$rv,
      choices_rv = "forex_timestamps"
    )

    ## Buttons ----
    ### Reset ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "reset_to_staged",
      triggers = "reset_to_staged",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Delete ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "delete_all_prices",
      triggers = "delete_all_prices",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "delete_market_prices",
      triggers = "delete_market_prices",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Metadata ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "get_metadata",
      triggers = c(
        "show_waiter",
        "get_marketcontent",
        "get_codemaster",
        "get_formulas",
        "import_prices"
      ),
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Show/hide columns ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "visible_columns",
      triggers = ns("visible_columns"),
      enable_trigger = "change_region",
      disable_trigger = "disable_buttons"
    )

    # Add observe events ----
    ## Change region ----
    shiny::observeEvent(
      gargoyle::watch("change_region"),
      {
        log_info("observeEvent:", "change_region", level = 1)

        ### Set Assumption table as null
        r$rv$dt_asmp <- NULL

        ### Check if `r$rv$report_date` is a working day and update r$rv$ date variables
        r <- argusDT.PriceStudioMain::fct_change_dates(
          new_date = r$rv$report_date,
          old_date = r$rv$prev$report_date,
          hist_days = r$hist_days,
          all_holiday_regions = r$rv$holiday_regions,
          holiday_combinations = r$rv$holiday_combinations,
          exrate_day_offset = as.numeric(r$rv$exrate_day_offset),
          db_env = r$rv$db_env,
          r = r
        )

        ### Update live & staged data if region has been refreshed
        if (!is.null(r$rv$prev$region)) {
          gargoyle::trigger("create_price_table")
          gargoyle::trigger("get_live_prices")
          gargoyle::trigger("get_stg_prices")
        }

        gargoyle::trigger("clear_ind_tables")
      },
      ignoreInit = TRUE
    )

    ## Change dates ----
    shiny::observeEvent(gargoyle::watch("change_dates"), {
      log_info("observeEvent:", "change_dates", level = 1)

      r$rv$w$show()

      ### Reset report date it's after the app has ended.
      if (shiny::isTruthy(r$app_end_date < r$rv$report_date)) {
        r$rv$report_date <- r$app_end_date
        shiny::req(FALSE)
      }

      ### Check if `r$rv$report_date` is a working day and update r$rv$ date variables
      r <- argusDT.PriceStudioMain::fct_change_dates(
        new_date = r$rv$report_date,
        old_date = r$rv$prev$report_date,
        hist_days = r$hist_days,
        all_holiday_regions = r$rv$holiday_regions,
        holiday_combinations = r$rv$holiday_combinations,
        exrate_day_offset = as.numeric(r$rv$exrate_day_offset),
        db_env = r$rv$db_env,
        r = r
      )

      ### Set export folder for CSV
      r$rv$s3_csv_dir <- file.path(
        r$s3_dir,
        tolower(r$rv$db_env),
        "csv",
        lubridate::year(r$rv$report_date),
        format(r$rv$report_date, "%Y%m%d")
      )

      ### Set export folder for price components csv
      r$rv$s3_price_components_base_dir <- file.path(
        r$s3_dir,
        tolower(r$rv$db_env),
        "price_components",
        lubridate::year(r$rv$report_date),
        format(r$rv$report_date, "%Y%m%d")
      )

      ### Set import/export folder for any sourced files
      r$rv$s3_source_dir <- file.path(
        r$s3_dir,
        tolower(r$rv$db_env),
        "source",
        lubridate::year(r$rv$report_date),
        format(r$rv$report_date, "%Y%m%d")
      )

      ### Set export folder for any other documents
      r$rv$s3_documents_dir <- file.path(
        r$s3_dir,
        tolower(r$rv$db_env),
        "documents",
        lubridate::year(r$rv$report_date),
        format(r$rv$report_date, "%Y%m%d")
      )

      ### Set import/export folder for censhare linkfiles
      r$rv$s3_linkfile_dir <- file.path(
        r$s3_dir,
        tolower(r$rv$db_env),
        "censhare",
        lubridate::year(r$rv$report_date),
        format(r$rv$report_date, "%Y%m%d")
      )

      ### Reset inputs and import prices if report date changed
      if (r$rv$report_date != r$rv$prev$report_date) {
        # Update region list with new report date
        regions_dt <- argusDT.PriceStudioMain::fct_get_regions(
          application_id = get_config("application_id"),
          report_date = r$rv$report_date,
          db_env = r$rv$db_env,
          connection = r$rv$ora_connection
        )

        r$rv$regions <- sort(regions_dt$REGION)

        # Reset selected market if selected region is not within the new region's list
        # Assign NULL if data have not been fetched at all from the database
        if (!is.null(r$rv$region)) {
          if (!r$rv$region %in% r$rv$regions & !is.null(r$rv$market)) {
            r$rv$prev$market <- r$rv$market
            r$rv$market <- ""
          }
        }

        # Refresh metadata
        gargoyle::trigger("show_waiter")
        gargoyle::trigger("get_marketcontent")
        gargoyle::trigger("get_codemaster")
        gargoyle::trigger("get_formulas")
        gargoyle::trigger("reset_exrates_to_init")
        gargoyle::trigger("market_survey_get_data")
        gargoyle::trigger("market_survey_check_files")

        # Re-import prices if a market is selected in the Price Input tab
        if (is_truthy(r$rv$market)) {
          r$rv$dt_prices_input <- NULL
          r$rv$dt_datawell_api <- data.table::as.data.table(NULL)
          r$rv$dt_datawell_filtered <- data.table::as.data.table(NULL)
          r$rv$dt_datawell_full <- data.table::as.data.table(NULL)

          gargoyle::trigger("import_prices")
          gargoyle::trigger("check_and_refresh_indtables")
        }

        # Re-import if a market is selected in Market survey tab
        if (is_truthy(r$market_survey$market)) {
          gargoyle::trigger("market_survey_import")
        }

        if (is_truthy(r$rv$price_components_market)) {
          gargoyle::trigger("destroy_price_components_tabulators")
          gargoyle::trigger("refresh_price_components")
        }
      }

      gargoyle::trigger("hide_waiter")
    })

    ## Refresh Indesign tables ----
    shiny::observeEvent(gargoyle::watch("check_and_refresh_indtables"), {
      log_info("observeEvent:", "check_and_refresh_indtables", level = 1, session = session)

      ## If InDesign exists, re-import InDesign data and update progress bars,
      ## if any tables displayed, delete them and display them again
      if (get_config("show_tab_indesign")) {
        gargoyle::trigger("create_ind_tables")
        gargoyle::trigger("get_indesign_status")

        if (!is.null(r$rv$displayed_tables)) {
          gargoyle::trigger("clear_ind_tables")
          gargoyle::trigger("populate_ind_tables")
          gargoyle::trigger("show_ind_tables")
        }
      }
    })

    ## Reset to staged prices ----
    shiny::observeEvent(
      gargoyle::watch("reset_to_staged"),
      {
        log_info("observeEvent:", "input$reset_to_staged", level = 1)
        shiny::removeModal()

        ## Reset input for the current market only
        if (!is.null(r$rv$dt_prices_input)) {
          r$rv$dt_prices_input <- r$rv$dt_prices_input[MARKET != r$rv$market]
        }

        ## Refresh data
        if (!is.null(r$rv$market)) {
          gargoyle::trigger("get_formulas")
          gargoyle::trigger("get_marketcontent")
          gargoyle::trigger("import_prices")
        }
      },
      ignoreInit = TRUE
    )

    shiny::observeEvent(
      gargoyle::watch("delete_market_prices"),
      {
        log_info("observeEvent:", "input$delete_market_prices", level = 1)

        if (!is.null(r$rv$market)) {
          r$rv$w$show()

          ## Create Quote_Pricetype_ID's
          qpt_ids <- r$rv$dt_prices_all[
            TYPE != "Imported" & RANK == 1 & MARKET == r$rv$market
          ]$QUOTE_PRICETYPE_ID %>%
            unique()

          msg <- argusDT.PriceStudioMain::fct_delete_prices(
            qpt_id = qpt_ids,
            date = r$rv$report_date,
            app_id = get_config("application_id"),
            db_env = r$rv$db_env
          )

          ## Refresh data
          gargoyle::trigger("get_formulas")
          gargoyle::trigger("import_prices")
        } else {
          ## Alert user of outcome
          log_warn(
            "Please select the market to delete data",
            title = "Nothing to delete",
            type = "info",
            prompt = TRUE
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Deletes test prices ----
    shiny::observeEvent(
      gargoyle::watch("delete_all_prices"),
      {
        log_info("observeEvent:", "input$delete_all_prices", level = 1)

        if (!is.null(r$rv$market)) {
          r$rv$w$show()

          ## Create Quote_Pricetype_ID's
          qpt_ids <- r$rv$dt_prices_all[TYPE != "Imported" & RANK == 1]$QUOTE_PRICETYPE_ID %>%
            unique()

          ## Delete prices
          msg <- argusDT.PriceStudioMain::fct_delete_prices(
            qpt_id = qpt_ids,
            date = r$rv$report_date,
            app_id = get_config("application_id"),
            db_env = r$rv$db_env
          )

          ## Refresh data
          gargoyle::trigger("get_formulas")
          gargoyle::trigger("import_prices")
        } else {
          ## Alert user of outcome
          log_warn(
            "Please select the market to delete all data",
            title = "Nothing to delete",
            type = "info",
            prompt = TRUE
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Change forex day / time ----
    shiny::observe({
      log_info("observe:", "r$rv$exrate_time / r$rv$exrate_day_offset", level = 1)

      ### Update r$rv$exrate_date based on the settings picker input selected choice
      r$rv$exrate_date <- bizdays::offset(
        dates = r$rv$report_date,
        n = as.numeric(r$rv$exrate_day_offset),
        cal = r$rv$all_calendars$exrates$name
      )

      log_info("New exrate date:", r$rv$exrate_date, level = 1)

      ### Re-run calculations if r$rv$market is not null or equal to empty string
      if (!is.null(r$rv$market)) {
        if (r$rv$market != "") {
          gargoyle::trigger("show_waiter")
          gargoyle::trigger("get_exrates")
          gargoyle::trigger("calculate_prices")
          gargoyle::trigger("check_prices")
          gargoyle::trigger("get_prices_status")
          gargoyle::trigger("pivot_prices")
          gargoyle::trigger("update_price_input")
        }
      }
    }) |>
      shiny::bindEvent(c(r$rv$exrate_time, r$rv$exrate_day_offset), ignoreInit = TRUE)

    ## Reset forex date and time ----
    ### Reset to the state of the first application load
    shiny::observeEvent(
      gargoyle::watch("reset_exrates_to_init"),
      {
        log_info("observeEvent:", "reset_exrates_to_init", level = 1)

        ### Avoid triggering calculations again if forex date / time are already equal
        ### Reset values to selected market defaults
        if (r$rv$exrate_day_offset != r$rv$exrate_day_offset_region) {
          r$rv$exrate_day_offset <- r$rv$exrate_day_offset_region
        }

        if (r$rv$exrate_time != r$rv$exrate_time_region) {
          r$rv$exrate_time <- r$rv$exrate_time_region
        }
      },
      ignoreInit = TRUE
    )

    ## Visible columns ----
    shiny::observeEvent(
      gargoyle::watch(ns("visible_columns")),
      {
        log_info("observeEvent:", ns("visible_columns"), level = 1)

        tab <- r$rv$selected_nav_panel

        if (tab == "Price Input") {
          gargoyle::trigger("input_prices-visible_columns")
        } else if (tab == "Price Summary") {
          gargoyle::trigger("summary-visible_columns")
        } else if (tab == "Market Survey") {
          gargoyle::trigger("market_survey-visible_columns")
        } else {
          log_warn("No column settings are available for the", tab, "tab")
        }
      },
      ignoreInit = TRUE
    )
  })
}
