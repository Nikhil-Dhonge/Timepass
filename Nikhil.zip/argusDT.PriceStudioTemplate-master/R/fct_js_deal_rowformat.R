#' Generate `argusDS.tabulator` row formatter JavaScript
#'
#' @description `fct_js_deal_rowformat()` Generates
#' JavaScript formatter for `argusDS.tabulator` tables, by
#' coloring today's deals in green in the deals table
#'
#' @param report_date Current report date, contained in r$rv$report_date
#'
#' @returns JavaScript code for `argusDS.tabulator` row formatter.
#'
#' @export
#'
#' @keywords internal
#'
#' @family JavaScript argusDS.tabulator
#'
fct_js_deal_rowformat <- function(report_date) {
  htmlwidgets::JS(glue::glue(
    " function(row) {
        var data = row.getData();
        if (data.PUBLICATION_DATE == '<<report_date>>') {
          if (row.getPosition() & 1) {
            row.getElement().style.backgroundColor = '#DCF4C8'; //odd rows
          } else {
            row.getElement().style.backgroundColor = '#C6E0B4'; //even rows
          }
        }
      }",
    .open = "<<",
    .close = ">>"
  ))
}
