#' Price Input Market Section Tabulator UI
#'
#' @description A shiny Module for the market section Tabulator.
#'
#' @param id A shiny id.
#' @param section Character description for the market section.
#' @param input_box_id id for the element to insert the table into.
#' @param dt data.table containing the Prices data.
#'
#' @keywords internal
#'
mod_tabulator_inp_ui <- function(id, section, input_box_id, dt) {
  ns <- shiny::NS(id)

  log_info("mod_tabulator_inp_ui ns:", get_ns(ns), level = 3)

  id_div <- ns("div")
  id_textoutput <- ns("text_output")
  id_tabulator <- ns("tabulator")

  log_info("div ID: ", id_div, level = 4)
  log_info("textOutput ID: ", id_textoutput, level = 4)
  log_info("tabulatorOutput ID: ", id_tabulator, level = 4)

  # Get the maximum row height dynamically
  rows = nrow(argusDT.PriceStudioMain::fct_get_pivot_section(dt, section))

  if (is.numeric(get_config("tabulator_max_rows"))) {
    # 31px for each row + 18 for scroll bar + 29 (no filters) or 64 (with filters) for header row.
    height <- min(rows, abs(get_config("tabulator_max_rows"))) * 31 + 18
    height <- height + if (get_config("tabulator_show_filters")) 64 else 29
  } else {
    height <- NULL
  }

  shiny::insertUI(
    selector = paste0("#", input_box_id),
    where = "beforeEnd",
    ui = htmltools::tags$div(
      class = "tabulator-table-ui",
      id = id_div,
      shiny::strong(shiny::textOutput(outputId = id_textoutput)),
      argusDS.tabulator::tabulatorOutput(
        outputId = id_tabulator,
        height = if (is.numeric(height)) paste0(height, "px") else "100%"
      )
    ),
    immediate = TRUE
  )
}

#' Price Input Market Section Tabulator Server
#'
#' @description A shiny Module for the market section Tabulator.
#'
#' @param id A shiny id.
#' @param section Character description for the market section.
#' @param input_box_id id for the element to insert the table into.
#' @param dt data.table containing the Prices data.
#' @param r The global environment variable 'r'.
#'
#' @keywords internal
#'
mod_tabulator_inp_server <- function(id, section, dt, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_tabulator_inp_server ns:", get_ns(ns), level = 3)

    # Create ids ----
    id_textoutput <- ns("text_output")
    id_tabulator <- ns("tabulator")
    id_destroy <- paste0(id, "_destroy")
    id_reformat <- paste0(id, "_reformat")

    # Add section title ----
    output$text_output <- shiny::renderText(section)

    # Add tabulator table ----
    dt_section <- argusDT.PriceStudioMain::fct_get_pivot_section(dt, section)

    output$tabulator <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator"), level = 4)

      argusDT.PriceStudioMain::fct_render_tabulator_input(
        dt = dt_section,
        visible_cols = r$rv$columns_visible_input,
        copy_paste = get_config("tabulator_range_selection"),
        show_filters = get_config("tabulator_show_filters")
      )
    }) |>
      shiny::bindEvent(dt_section)

    ## Get user input ----
    r$rv$observeEvent[[id]] <- shiny::observeEvent(input$tabulator$edited, {
      log_info("observeEvent:", glue::glue("r$rv$observeEvent${id}"), level = 1)

      ## Get Edited data table row
      dt_data <- data.table::as.data.table(input$tabulator$data)
      dt_edited <- data.table::as.data.table(input$tabulator$edited)
      dt_data_edited <- dt_data[ID %in% dt_edited$index]

      log_change(
        id = paste(id, dt_edited$col, dt_data[ID %in% dt_edited$index]$QPT_MID, sep = ": "),
        from = dt_edited$old_value,
        to = dt_edited$new_value
      )

      shiny::req(dt_edited[new_value != old_value | is.na(old_value), .N] > 0)

      ### Set DBR across the QUOTE ----
      if ("BASIS" %in% dt_edited$col) {
        dt_data_edited_add <- dt_data[
          QUOTE_ID %in% dt_data_edited$QUOTE_ID & !(QPT_MID %in% dt_data_edited$QPT_MID)
        ]

        dt_data_edited_add <- dt_data_edited_add[dt_data_edited, BASIS := i.BASIS, on = .(QUOTE_ID)]

        dt_data_edited <- rbind(dt_data_edited, dt_data_edited_add)
      }

      ### Set FORWARD across the QUOTE ----
      if ("FORWARD" %in% dt_edited$col) {
        dt_data_edited_add <- dt_data[
          QUOTE_ID %in% dt_data_edited$QUOTE_ID & !(QPT_MID %in% dt_data_edited$QPT_MID)
        ]

        dt_data_edited_add <- dt_data_edited_add[
          dt_data_edited,
          FORWARD := i.FORWARD,
          on = .(QUOTE_ID)
        ]

        dt_data_edited <- rbind(dt_data_edited, dt_data_edited_add)
      }

      ### Get new inputs ----
      dt_input <- argusDT.PriceStudioMain::fct_get_price_input(
        dt_data = dt_data_edited,
        dt_prices = r$rv$dt_prices_all,
        dt_pricetype = argusDT.PriceStudioMain::dt_pricetype
      )

      ## Calculate mid
      dt_input <- argusDT.PriceStudioMain::fct_calculate_mid(dt_input)

      ### Combine new inputs to rest of previous inputs
      if (!is.null(r$rv$dt_prices_input)) {
        r$rv$dt_prices_input <- rbind(
          r$rv$dt_prices_input[!QPT_MID %in% dt_input$QPT_MID],
          dt_input
        )
      } else {
        r$rv$dt_prices_input <- dt_input
      }

      ### Format row (if needed) ----
      cols_format <- c("PUBLISH", "OVERRIDE", "OVERRIDE_FWD", "OVERRIDE_DBR")
      if (any(cols_format %in% dt_edited$col)) {
        shinyjs::runjs(glue::glue_collapse(glue::glue(
          "get_tabulator('<<ns('tabulator')>>').getRow(
            <<dt_data[ID %in% dt_edited$row]$ID>>
          ).reformat();",
          .open = "<<",
          .close = ">>"
        )))
      }

      if (dt_edited[col != "FINAL" | (col == "FINAL" & new_value == FALSE), .N] > 0) {
        r$rv$dt_edit_latest <- dt_input[, .(CODE_ID, QUOTE_ID, QUOTE_PRICETYPE_ID)]
      }

      ### Set to draft ----
      ### if anything apart from FINAL is changed
      rows <- dt_edited[col != "FINAL", row]

      if (length(rows) > 0) {
        changed_qpt_mid <- r$rv$dt_prices_input[
          QPT_MID %in%
            dt_data_edited[ID %in% rows, QPT_MID] &
            any(
              ifelse(is.na(INPUT_VALUE), "", INPUT_VALUE) != ifelse(is.na(VALUE), "", VALUE) |
                ifelse(is.na(INPUT_FWD), FWD, INPUT_FWD) != ifelse(is.na(FWD), "", FWD) |
                ifelse(is.na(INPUT_DBR), DBR, INPUT_DBR) != ifelse(is.na(DBR), "", DBR)
            ),
          QPT_MID
        ]

        r$rv$dt_prices_input[QPT_MID %in% changed_qpt_mid, FINAL := FALSE]

        if (length(changed_qpt_mid) > 0) {
          shinyjs::runjs(glue::glue_collapse(glue::glue(
            "get_tabulator('<<ns('tabulator')>>').updateData(
              [{ID:<<dt_data[ID %in% dt_edited$row]$ID>>, FINAL:false}]
            );",
            .open = "<<",
            .close = ">>"
          )))
        }
      }

      ### Trigger updates ----
      ### Only if calculations are turned on
      shiny::req(r$rv$auto_calc)

      gargoyle::trigger("combine_price_data")
      gargoyle::trigger("calculate_prices")
      gargoyle::trigger("check_prices")
      gargoyle::trigger("get_prices_status")
      gargoyle::trigger("pivot_prices")
      gargoyle::trigger("update_price_input")
      gargoyle::trigger("reset_dependencies")
    })

    ## Destroy ----
    r$rv$observeEvent[[id_destroy]] <- shiny::observeEvent(
      gargoyle::watch("tabulator_destroy"),
      {
        log_info("tabulator_destroy:", ns("tabulator"), level = 4)

        argusDS.tabulator::tabulatorProxy("tabulator") |> argusDS.tabulator::destroy_tabulator()
      },
      ignoreInit = TRUE
    )

    ## Reformat all rows ----
    ### - after prices have been staged
    r$rv$observeEvent[[id_reformat]] <- shiny::observeEvent(
      gargoyle::watch("reformat_all_tabulator_rows"),
      {
        log_info("reformat_all_tabulator_rows:", ns("tabulator"), level = 4)

        tabulator_id <- ns("tabulator")

        session$sendCustomMessage(type = "reformat_all_tabulator_rows", message = tabulator_id)
      },
      ignoreInit = TRUE
    )
  }) # End of ModuleServer function
}
