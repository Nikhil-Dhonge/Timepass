#' download_excel UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @param width The width of the widget.
#' @param disabled_msg Tooltip when widget is disabled. Widget isn't disabled
#' if NULL.
#' @param tooltip_placement Position of the tooltip relative to the widget.
#' One of "auto", "top", "right", "bottom", "left".
#' @param tooltip_dark logical TRUE to show a dark background tooltip.
#' @inheritParams shiny::downloadButton
#' @inheritParams bslib::tooltip
mod_download_excel_ui <- function(
  id,
  label = "Download",
  width = "100%",
  icon = shiny::icon("download"),
  disabled_msg = NULL,
  tooltip_placement = c("auto", "top", "right", "bottom", "left"),
  tooltip_dark = TRUE,
  ...
) {
  ns <- shiny::NS(id)

  tooltip_placement <- match.arg(tooltip_placement)

  log_info("mod_download_excel_ui ns:", get_ns(ns), level = 3)

  outputId <- ns("download_excel")
  tooltipId <- ns("download_excel-tooltip")

  log_info("download_excel ID:", outputId, level = 4)

  widget <- shiny::downloadButton(outputId = outputId, label = label, icon = icon)

  shiny::tagList(
    bslib::tooltip(
      disabled_msg,
      placement = tooltip_placement,
      options = list(
        customClass = ifelse(tooltip_dark, "tooltip-dark", ""),
        trigger = ifelse(is.null(disabled_msg), "manual", "hover focus")
      ),
      trigger = shiny::tags$div(
        id = tooltipId,
        style = htmltools::css(width = shiny::validateCssUnit(width)),
        class = "btn-default-container",

        if (is.null(disabled_msg)) {
          widget
        } else {
          shinyjs::disabled(widget)
        }
      )
    )
  )
}


#' download_excel Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @param enabled logical indicating whether the download is enabled.
mod_download_excel_server <- function(id, r, enabled = TRUE) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_download_excel_server ns:", get_ns(ns), level = 3)

    outputId <- ns("download_excel")
    tooltipId <- ns("download_excel-tooltip")

    if (enabled) {
      ## Remove the tooltip
      shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
        id = tooltipId,
        action = "disable"
      ))

      ## Download file locally
      output$download_excel <- shiny::downloadHandler(
        filename = function() {
          output_name <- gsub(pattern = "_raw", replacement = "", x = r$linkfile_filename)

          output_name <- paste0(
            format(r$rv$report_date, "%Y%m%d"),
            r$censhare_tag,
            "_",
            output_name
          )
        },
        content = function(file) {
          r$rv$w$show()

          ### Create IndTables
          r$rv$dt_indesign <- fct_create_prices_table(
            report_date = r$rv$report_date,
            all_dates = r$rv$all_dates,
            dt_market_content = r$rv$dt_market_content,
            dt_codemaster = unique(
              r$rv$dt_codemaster[QUOTE_ID %in% r$rv$quote_id],
              by = "QUOTE_PRICETYPE_ID"
            ),
            dt_prc_asmp = r$rv$dt_prc_asmp,
            dt_holidays = r$rv$dt_holidays,
            fwd_list_start = r$rv$fwd_list_start,
            fwd_list_count = r$rv$fwd_list_count,
            dbr_list_start = r$rv$dbr_list_start,
            dbr_list_count = r$rv$dbr_list_count,
            calendars = r$rv$all_calendars
          )

          r$rv$dt_prices_live_all_regions <- argusDT.PriceStudioMain::fct_get_prices_repository(
            quote_id = r$rv$quote_id,
            date_from = r$rv$from_date,
            date_to = r$rv$report_date,
            live_count = r$data_points,
            db_env = r$rv$db_env,
            connection = r$rv$ora_connection
          )

          r$rv$dt_indesign <- argusDT.PriceStudioMain::fct_combine_price_data(
            report_date = r$rv$report_date,
            dt_prices_all = r$rv$dt_indesign,
            dt_prices_live = r$rv$dt_prices_live_all_regions,
            dt_prices_stg = r$rv$dt_prices_stg_all_regions,
            dt_latest_notes = NULL,
            dt_prices_input = NULL,
            dt_pricetype = argusDT.PriceStudioMain::dt_pricetype,
            tab = "InDesign",
            include_imported = TRUE,
            from_live = if (r$rv$indesign_source == "Live") TRUE else FALSE
          )

          r$rv$ind_tables_calc <- argusDT.PriceStudioMain::fct_calc_ind_tables(
            ind_tables = r$rv$ind_tables_raw,
            dt_prices = r$rv$dt_indesign,
            dt_exrates = r$rv$dt_exrates,
            dt_deals = r$rv$dt_deals,
            dt_bbs_deals = r$rv$dt_bbs_deals,
            data_source = "Live",
            report_date = r$rv$report_date,
            pa_code_mode = r$rv$pacode_mode_selection,
            replace_errors = TRUE,
            calendars = r$rv$all_calendars,
            dt_market_content = r$rv$dt_market_content,
            r = r
          )

          ### Create excel file and save it in S3 ----
          output_name <- argusDT.PriceStudioMain::fct_create_ind_tables_file(
            tbl_list = r$rv$ind_tables_calc$final_tbls,
            save_dir = r$rv$s3_linkfile_dir,
            s3_bucket = get_config("s3_bucket"),
            censharetag = r$censhare_tag,
            raw_name = r$linkfile_filename,
            ind_ranges = r$rv$dt_ind_ranges,
            report_date = r$rv$report_date
          )

          file.remove(output_name)

          con <- file(glue::glue(file), "wb") # Open a connection

          writeBin(
            con = con,
            object = argusDT.S3::s3_get_object(
              paste0(r$rv$s3_linkfile_dir, "/", output_name),
              bucket = get_config("s3_bucket")
            )$Body
          ) # Write using the connection

          close(con)

          r$rv$w$hide()
        }
      )
    }
  })
}
