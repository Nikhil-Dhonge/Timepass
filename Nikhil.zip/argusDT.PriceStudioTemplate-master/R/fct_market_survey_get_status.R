#' Get Market Survey Status
#'
#' @description
#' Calculate status metrics for Market Survey progress bars based on database data:
#' - Saved Tables: tables with at least one row saved in database for the report date
#' - Saved Rows: rows saved in database for the report date
#' - Updated Values: rows with data entered (saved or currently being edited)
#' - Saved Files: files uploaded to S3
#'
#' @param dt_pivot data.table containing the pivoted market survey data
#' @param dt_available_files data.table containing S3 files information (can be NULL)
#' @param region character Selected region
#' @param market character Selected market
#' @param report_date Date object with the current report date
#'
#' @return
#' A named list with the following elements:
#' \describe{
#'   \item{tables_saved}{Number of tables (QUOTE_IDs) with at least one saved row in database}
#'   \item{tables_total}{Total number of unique tables (QUOTE_IDs) for the selected region/market}
#'   \item{rows_saved}{Number of rows saved in database for the report date}
#'   \item{rows_total}{Total number of rows in the region/market}
#'   \item{updated_count}{Number of rows with data entered (saved or being edited)}
#'   \item{updated_total}{Total number of rows in the region/market}
#'   \item{files_count}{Number of files uploaded to S3}
#' }
#'
#' @export
#'
#' @family market survey
#'
fct_market_survey_get_status <- function(
  dt_pivot,
  dt_available_files = NULL,
  region,
  market,
  report_date
) {
  log_info("fct_market_survey_get_status", level = 2)

  # Initialize return values
  status <- list(
    tables_saved = 0,
    tables_total = 0,
    rows_saved = 0,
    rows_total = 0,
    updated_count = 0,
    updated_total = 0,
    files_count = 0
  )

  # Return early if no data
  if (is.null(dt_pivot) || nrow(dt_pivot) == 0) {
    return(status)
  }

  # Filter by region and market
  dt <- data.table::copy(dt_pivot)
  dt <- dt[REGION == region & MARKET == market]

  if (nrow(dt) == 0) {
    return(status)
  }

  # Determine which column contains the source information
  source_col <- NULL
  if ("VALUE_SOURCE" %in% names(dt)) {
    source_col <- "VALUE_SOURCE"
  } else if ("SOURCE" %in% names(dt)) {
    source_col <- "SOURCE"
  }

  # Calculate TABLES status ----
  # Total tables = unique QUOTE_IDs for this market
  status$tables_total <- dt[, data.table::uniqueN(QUOTE_ID)]

  # Saved tables = tables with at least one row from database (SOURCE == "MS")
  if (!is.null(source_col)) {
    status$tables_saved <- dt[get(source_col) == "MS", data.table::uniqueN(QUOTE_ID)]
  }

  # Calculate ROWS status ----
  # Total rows = ALL rows in the market
  status$rows_total <- nrow(dt)

  # Saved rows = rows from database (SOURCE == "MS")
  if (!is.null(source_col)) {
    status$rows_saved <- dt[get(source_col) == "MS", .N]
  }

  # Calculate UPDATED VALUES status ----
  # Total that can be updated = all rows in the market
  status$updated_total <- nrow(dt)

  # Updated count = rows that have actual data entered in any editable field
  # Check price values and key metadata fields
  status$updated_count <- dt[
    !is.na(LOW) |
      !is.na(HIGH) |
      !is.na(MID) |
      !is.na(TRADER_ID) |
      !is.na(PRICE_CATEGORY_ID) |
      !is.na(COMM_METHOD_ID) |
      !is.na(COMM_CONTACT_NAME) |
      !is.na(PORT_ID) |
      !is.na(DELIVERY_PERIOD_ID) |
      !is.na(DELIVERY_YEAR) |
      (!is.na(NOTES) & NOTES != ""),
    .N
  ]
  # Calculate FILES status ----
  if (!is.null(dt_available_files) && nrow(dt_available_files) > 0) {
    status$files_count <- nrow(dt_available_files)
  }

  log_info(
    glue::glue(
      "Market Survey Status - ",
      "Tables: {status$tables_saved}/{status$tables_total}, ",
      "Rows: {status$rows_saved}/{status$rows_total}, ",
      "Updated: {status$updated_count}/{status$updated_total}, ",
      "Files: {status$files_count}"
    ),
    level = 3
  )

  return(status)
}
