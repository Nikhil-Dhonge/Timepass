#' run_sched_script
#'
#' @description This function runs a scheduled script in the background using the Connect API.
#'
#' @noRd
fct_run_sched_script <- function(
  db_env,
  selected_script_name,
  selected_script_guid,
  user_id = NULL
) {
  # Load packages into the external R process
  library(argusDT.PriceStudioMain)
  library(connectapi)

  # Get the shared locks environment
  script_locks <- getOption("script.locks")

  # Check if script is already locked
  if (!is.null(script_locks[[selected_script_name]])) {
    lock_info <- script_locks[[selected_script_name]]
    # Check if lock is still fresh (less than 10 minutes old)
    if (difftime(Sys.time(), lock_info$time, units = "mins") < 10) {
      return(list(
        script_name = selected_script_name,
        status = "locked",
        message = paste(selected_script_name, "is already running by another user"),
        locked_by = lock_info$user_id,
        locked_at = lock_info$time
      ))
    }
    # Lock is stale, will be overwritten
  }

  # Create lock for this user in the shared environment
  script_locks[[selected_script_name]] <- list(user_id = user_id, time = Sys.time())

  result <- list(script_name = selected_script_name, status = "triggered", user_id = user_id)

  tryCatch(
    {
      # Get server api creds
      db_env <- tolower(db_env)
      secret_path <- paste0("ds/connect/", db_env, "/internal/api")
      api <- argusDT.PriceStudioMain::fct_get_secret(secret_path)
      api_key <- api[[3]]
      env <- ifelse(db_env == "live", "", paste0("-", db_env))
      server <- paste0("https://dss", env, ".argusmedia.tech")

      # Run the scheduled script
      client <- connectapi::connect(server = server, api_key = api_key)
      content <- connectapi::content_item(client, selected_script_guid)
      task <- connectapi::content_render(content)

      result$status <- "triggered"
      result$message <- paste(selected_script_name, "triggered successfully")
      result$task_id <- task$task_id
    },
    error = function(e) {
      result$status <- "error"
      result$message <- paste("Failed to trigger:", e$message)
      # Remove lock on error
      script_locks[[selected_script_name]] <- NULL
    }
  )

  return(result)
}

# Function to clean up locks after script completion
fct_cleanup_script_lock <- function(script_name) {
  script_locks <- getOption("script.locks")
  if (!is.null(script_locks)) {
    script_locks[[script_name]] <- NULL
  }
}
