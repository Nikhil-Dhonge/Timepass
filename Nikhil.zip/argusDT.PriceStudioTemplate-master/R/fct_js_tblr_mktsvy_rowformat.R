#' Generate `argusDS.tabulator` row formatter JavaScript
#'
#' @description `fct_js_tblr_mktsvy_rowformat()` Generates
#' JavaScript formatter for `argusDS.tabulator` tables, applying formatting
#' where selected columns contain specified values.
#'
#' @param colors list of colors to apply where value matches.
#' @param columns list of columns to check value of.
#' @param values list of columns values to check for.
#'
#' @returns JavaScript code for `argusDS.tabulator` row formatter.
#'
#' @export
#'
#'@keywords internal
#'
#' @family JavaScript argusDS.tabulator
#'
fct_js_tblr_mktsvy_rowformat <- function(colors, columns, values) {
  if (length(colors) != length(columns) & length(columns) != length(values)) {
    log_warn(
      " Lengths of arguments in fct_market_survey_js_tabulator_formatter_row
        don't match. Make sure each list has the same number of items"
    )
    return(NULL)
  }

  # Copy first color to second item in list if only 1 color is provided
  colors <- lapply(colors, function(x) {
    x[[2]] <- if (length(x) < 2) x[[1]] else x[[2]]
    x
  })

  # Parse lists
  colors <- jsonlite::toJSON(colors, auto_unbox = TRUE)
  columns <- jsonlite::toJSON(columns, auto_unbox = TRUE)
  values <- jsonlite::toJSON(values, auto_unbox = TRUE)

  htmlwidgets::JS(glue::glue(
    " function(row) {
        var data = row.getData(),
            el = row.getElement(),
            colors = <<colors>>,
            columns = <<columns>>,
            values = <<values>>;

        for (var i = 0; i < columns.length; i++) {
          if (row.getCell(columns[i]).getValue() == values[i]) {
            if (row.getPosition() & 1) {
              el.style.backgroundColor = colors[i][1]; //even rows
            } else {
              el.style.backgroundColor = colors[i][0]; //odd rows
            }
            break;
          }
        }

      }",
    .open = "<<",
    .close = ">>"
  ))
}
