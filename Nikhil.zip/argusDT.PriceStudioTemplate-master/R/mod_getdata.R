#' getdata UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_getdata_ui <- function(id) {
  ns <- NS(id)
  tagList(
    # This is a module with server part only
  )
}

#' getdata Server Functions
#'
#' @noRd
mod_getdata_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_getdata_server:", get_ns(ns), level = 2)

    ## Get codemaster ----
    shiny::observeEvent(gargoyle::watch("get_codemaster"), {
      log_info("observeEvent:", "get_codemaster", level = 2)

      # Retrieve code master from Oracle database
      r$rv$dt_codemaster <- argusDT.PriceStudioMain::fct_get_codemaster(
        quote_id = r$rv$quote_id,
        report_date = r$rv$report_date,
        db_env = r$rv$db_env,
        verbose = FALSE,
        connection = r$rv$ora_connection
      )
    })

    ## Get formulas ----
    shiny::observeEvent(gargoyle::watch("get_formulas"), {
      log_info("observeEvent:", "get_formulas", level = 2)

      # Retrieve pricing settings from STAFF database
      if (r$rv$dt_market_content[TYPE != "Imported", .N] > 0) {
        r$rv$dt_prc_asmp <- argusDT.PriceStudioMain::fct_get_prc_asmp(
          report_date = r$rv$report_date,
          quote_id = unique(r$rv$dt_market_content[TYPE != "Imported"]$QUOTE_ID),
          db_env = r$rv$db_env,
          verbose = FALSE,
          connection = r$rv$ora_connection
        )
      }

      if (is.null(r$rv$region_quote_id)) {
        r$rv$region_dt_prc_asmp <- NULL
      } else if (is.null(r$rv$dt_prc_asmp)) {
        r$rv$region_dt_prc_asmp <- NULL
      } else {
        r$rv$region_dt_prc_asmp <- r$rv$dt_prc_asmp[QUOTE_ID %in% r$rv$region_quote_id]
      }
    })

    ## Import prices ----
    shiny::observeEvent(
      gargoyle::watch("import_prices"),
      {
        log_info("observeEvent:", "import_prices", level = 1)

        gargoyle::trigger("show_waiter")
        gargoyle::trigger("tabulator_destroy")
        gargoyle::trigger("create_price_table")
        gargoyle::trigger("get_live_prices")
        gargoyle::trigger("get_stg_prices")
        gargoyle::trigger("get_asmp")
        gargoyle::trigger("check_staged_exrates")
        gargoyle::trigger("get_exrates")
        gargoyle::trigger("get_fixed_conv")
        gargoyle::trigger("get_deals")
        gargoyle::trigger("get_random_data")
        gargoyle::trigger("combine_price_data")
        gargoyle::trigger("send_js_prices")
        gargoyle::trigger("check_final_status")
        gargoyle::trigger("calculate_prices")
        gargoyle::trigger("populate_custom_column")
        gargoyle::trigger("check_prices")
        gargoyle::trigger("pivot_prices")
        gargoyle::trigger("show_custom_tbl")
        gargoyle::trigger("show_price_input")
        gargoyle::trigger("create_summary")
        gargoyle::trigger("get_prices_status")

        r$rv$summary_ui_switch <- !r$rv$summary_ui_switch
      },
      ignoreInit = TRUE
    )

    ## Create price table ----
    shiny::observeEvent(
      gargoyle::watch("create_price_table"),
      {
        log_info("observeEvent:", "create_price_table", level = 1)

        r$rv$dt_prices_all <- fct_create_prices_table(
          report_date = r$rv$report_date,
          all_dates = r$rv$all_dates,
          dt_market_content = r$rv$dt_market_content[REGION == r$rv$region],
          dt_codemaster = unique(
            r$rv$dt_codemaster[QUOTE_ID %in% r$rv$region_quote_id],
            by = "QUOTE_PRICETYPE_ID"
          ),
          dt_prc_asmp = r$rv$region_dt_prc_asmp,
          dt_holidays = r$rv$dt_holidays,
          fwd_list_start = r$rv$fwd_list_start,
          fwd_list_count = r$rv$fwd_list_count,
          dbr_list_start = r$rv$dbr_list_start,
          dbr_list_count = r$rv$dbr_list_count,
          calendars = r$rv$all_calendars
        )
      },
      ignoreInit = TRUE
    )

    ## Get LIVE prices ----
    shiny::observeEvent(
      gargoyle::watch("get_live_prices"),
      {
        log_info("observeEvent:", "get_live_prices", level = 1)

        r$rv$dt_prices_live <- argusDT.PriceStudioMain::fct_get_prices_repository(
          quote_id = r$rv$region_quote_id,
          date_from = r$rv$from_date,
          date_to = r$rv$report_date,
          live_count = r$data_points,
          db_env = r$rv$db_env,
          connection = r$rv$ora_connection
        )
      },
      ignoreInit = TRUE
    )

    ## Get STAGED prices ----
    shiny::observeEvent(
      gargoyle::watch("get_stg_prices"),
      {
        log_info("observeEvent:", "get_stg_prices", level = 1)

        gargoyle::trigger("show_waiter")

        r$rv$dt_prices_stg_all_regions <- argusDT.PriceStudioMain::fct_get_prices_staging(
          quote_id = r$rv$quote_id,
          app_id = get_config("application_id"),
          date_from = r$rv$report_date,
          date_to = r$rv$report_date,
          db_env = r$rv$db_env,
          verbose = FALSE,
          connection = r$rv$ora_connection
        )

        if (is.null(r$rv$dt_prices_stg_all_regions)) {
          r$rv$dt_prices_stg <- NULL
        } else if (r$rv$use_draft_switch == FALSE) {
          market_quote_id <- r$rv$dt_market_content[
            MARKET == r$rv$market & REGION == r$rv$region
          ]$QUOTE_ID

          r$rv$dt_prices_stg <- r$rv$dt_prices_stg_all_regions[QUOTE_ID %in% r$rv$region_quote_id][
            QUOTE_ID %in% market_quote_id | (!QUOTE_ID %in% market_quote_id & FINAL == TRUE)
          ]
        } else {
          r$rv$dt_prices_stg <- r$rv$dt_prices_stg_all_regions[QUOTE_ID %in% r$rv$region_quote_id]
        }

        ### Perform a data check on forex date and time previously staged (if any) and
        ### store those values in variables for later use
        fct_check_staged_exrates(r = r)

        ## Get latest notes ----
        r$rv$dt_latest_notes <- argusDT.PriceStudioMain::fct_get_latest_notes(
          quote_id = r$rv$quote_id,
          app_id = get_config("application_id"),
          date_from = r$app_start_date,
          date_to = r$rv$report_date - 1,
          db_env = r$rv$db_env,
          verbose = FALSE,
          connection = r$rv$ora_connection
        )
      },
      ignoreInit = TRUE
    )

    ## Check staged forex date / time settings on data retrival ----
    shiny::observeEvent(
      gargoyle::watch("check_staged_exrates"),
      {
        log_info("observeEvent:", "check_staged_exrates", level = 1)

        if (!is.null(r$rv$dt_prices_stg)) {
          exrate_date <- bizdays::offset(
            dates = r$rv$report_date,
            n = as.numeric(r$rv$exrate_day_offset_region),
            cal = r$rv$all_calendars$exrates$name
          )

          ### Check forex date and forex time used to stage prices and inform the user
          ### if a non standard value has been used
          if (!is.na(r$rv$xr_dte_stg_curr_m)) {
            exrate_date_check <- exrate_date != r$rv$xr_dte_stg_curr_m
          } else {
            exrate_date_check <- FALSE
          }

          if (!is.na(r$rv$xr_time_stg_curr_m)) {
            exrate_time_check <- r$rv$exrate_time_region != r$rv$xr_time_stg_curr_m
          } else {
            exrate_time_check <- FALSE
          }

          ### If any of the two values are different to the standard ones,
          ### let the user know with an info message
          if (exrate_date_check | exrate_time_check) {
            title_to_display <- stringr::str_flatten(
              c(if (exrate_date_check) "forex date", if (exrate_time_check) "forex time"),
              collapse = " / "
            )

            text_to_display <- stringr::str_flatten(
              c(
                if (exrate_date_check) {
                  glue::glue("-> forex date: {format(r$rv$xr_dte_stg_curr_m, '%d-%b')}.")
                },
                if (exrate_time_check) {
                  glue::glue("-> forex time: {r$rv$xr_time_stg_curr_m}.")
                }
              ),
              collapse = "\n"
            )

            log_warn(
              paste(
                "The following settings were previously used to save prices. \n\n",
                "You will need to select it manually in order to match saved values. \n\n",
                text_to_display,
                collapse = "\n"
              ),
              prompt = TRUE,
              type = "info",
              title = paste("Non standard ", title_to_display)
            )
          }
        }
      },
      ignoreInit = TRUE
    )

    ## Get assumptions ----
    shiny::observeEvent(
      gargoyle::watch("get_asmp"),
      {
        log_info("observeEvent:", "get_asmp", level = 2)

        r$rv$dt_asmp <- argusDT.PriceStudioMain::fct_get_asmp(
          db_env = r$rv$db_env,
          report_date = r$rv$report_date,
          quote_id = r$rv$region_quote_id,
          verbose = FALSE,
          connection = r$rv$ora_connection
        )
      },
      ignoreInit = TRUE
    )

    ## Get ex-rates ----
    shiny::observeEvent(
      gargoyle::watch("get_exrates"),
      {
        log_info("observeEvent:", "get_exrates", level = 1)

        r$rv$dt_exrates <- argusDT.PriceStudioMain::fct_get_exrates(
          unit_ids = r$rv$exrate_unit_ids,
          rate_date = r$rv$exrate_date,
          db_env = r$rv$db_env,
          timing_ids = r$rv$exrate_timing_id,
          connection = r$rv$ora_connection
        )
      },
      ignoreInit = TRUE
    )

    ## Get unit fixed conversions ----
    shiny::observeEvent(
      gargoyle::watch("get_fixed_conv"),
      {
        log_info("observeEvent:", "get_fixed_conv", level = 1)

        r$rv$dt_fixed_conv <- argusDT.PriceStudioMain::fct_get_fixed_conv(
          db_env = r$rv$db_env,
          connection = r$rv$ora_connection
        )
      },
      ignoreInit = TRUE
    )

    ## Get deals ----
    shiny::observeEvent(
      gargoyle::watch("get_deals"),
      {
        log_info("observeEvent:", "get_deals", level = 1)

        if (!is.null(r$rv$deal_module_ids)) {
          r$rv$dt_deals <- argusDT.PriceStudioMain::fct_get_deals(
            date_from = r$rv$report_date - r$deals_days,
            date_to = r$rv$report_date,
            module_ids = r$rv$deal_module_ids,
            db_env = "LIVE",
            connection = if (r$rv$db_env == "LIVE") r$rv$ora_connection else NULL
          )
        }

        r$rv$dt_bbs_deals <- argusDT.PriceStudioMain::fct_get_bbs_deals(
          board_ids = r$rv$bbs_id,
          report_date = r$rv$report_date,
          db_env = "LIVE",
          verbose = FALSE,
          connection = if (r$rv$db_env == "LIVE") r$rv$ora_connection else NULL
        )
      },
      ignoreInit = TRUE
    )

    ## Get External data ----
    shiny::observeEvent(
      gargoyle::watch("get_random_data"),
      {
        log_info("observeEvent:", "get_random_data", level = 1)

        if (get_config("use_vortexa_data")) {
          r$rv$random_data$dt_vortexa <- argusDT.PriceStudioMain::fct_get_vortexa_data(
            report_date = r$rv$report_date,
            db_env = r$rv$db_env,
            verbose = FALSE,
            connection = r$rv$ora_connection
          )
        }

        if (get_config("use_euronext_futures_data")) {
          r$rv$random_data$dt_euronext_futures <- argusDT.PriceStudioMain::fct_get_euronext_futures_data(
            date_from = r$rv$from_date,
            date_to = r$rv$report_date,
            db_env = r$rv$db_env,
            verbose = FALSE,
            connection = r$rv$mysql_connection
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Populate custom column if needed----
    shiny::observeEvent(
      gargoyle::watch("populate_custom_column"),
      {
        log_info("observeEvent:", "populate_custom_column", level = 1)

        # Add custom R code to populate custom column
      },
      ignoreInit = TRUE
    )

    ## Combine price data ----
    shiny::observeEvent(
      gargoyle::watch("combine_price_data"),
      {
        log_info("observeEvent:", "combine_price_data", level = 1)

        shiny::req(r$rv$dt_prices_all)

        dt_prices_input <- if (!is.null(r$rv$dt_prices_input)) {
          r$rv$dt_prices_input[MARKET == r$rv$market]
        } else {
          r$rv$dt_prices_input
        }

        r$rv$dt_prices_all <- argusDT.PriceStudioMain::fct_combine_price_data(
          report_date = r$rv$report_date,
          dt_prices_all = r$rv$dt_prices_all,
          dt_prices_live = r$rv$dt_prices_live,
          dt_prices_stg = r$rv$dt_prices_stg,
          dt_latest_notes = r$rv$dt_latest_notes,
          dt_prices_input = dt_prices_input,
          dt_pricetype = argusDT.PriceStudioMain::dt_pricetype,
          market = r$rv$market
        )

        r$rv$dt_imported <- r$rv$dt_prices_all[
          TYPE == "Imported" & LATEST == TRUE,
          .SD,
          .SDcols = c(
            "CODE_ID",
            "TS",
            "CF",
            "CODE_DESCRIPTION",
            "DIFF_BASE",
            "OUT_DIFF_TYPE",
            "PT",
            "PUBLICATION_DATE",
            "VALUE",
            "FWD",
            "YEAR",
            "DBR"
          )
        ]
      },
      ignoreInit = TRUE
    )

    ## Send prices to JS ----
    shiny::observeEvent(
      gargoyle::watch("send_js_prices"),
      {
        cols <- c(
          "QUOTE_PRICETYPE_ID",
          "CHANGE_MODE",
          "CODE_ID",
          "PT",
          "TS",
          "FWD",
          "YEAR",
          "RANK",
          "VALUE"
        )

        session$sendCustomMessage(
          type = "dt_prices_all",
          message = jsonlite::toJSON(r$rv$dt_prices_all[RANK != 1, ..cols])
        )
      },
      ignoreInit = TRUE
    )
  })
}
