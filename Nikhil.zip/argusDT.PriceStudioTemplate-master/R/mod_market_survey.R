#' input_market UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @noRd

mod_market_survey_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_market_survey_ui ns:", get_ns(ns), level = 2)

  htmltools::tagList(
    bslib::layout_columns(
      class = "main-nav",
      col_widths = 12,
      row_heights = list("auto", 1),

      # Control Box ----
      bslib::layout_columns(
        col_widths = c(9, 3),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 6,

          bslib::layout_columns(
            col_widths = c(12, 4, 4),

            ## Market picker ----
            argusDT.PriceStudioMain::mod_pickerinput_ui(
              id = ns("market"),
              choices = "",
              disabled_msg = if (length(golem::get_golem_options("regions")) > 1) {
                "Select a region first..."
              } else {
                NULL
              },
              options = list(title = "Select market...")
            ),

            ## Notes switch ----
            argusDT.PriceStudioMain::mod_switchinput_ui(
              id = ns("notes_switch"),
              label = "Show notes",
              disabled_msg = "Select a region / market first...",
              value = FALSE
            ),

            ## Prefill company switch ----
            argusDT.PriceStudioMain::mod_switchinput_ui(
              id = ns("prefill_company_switch"),
              label = "Prefill company",
              value = TRUE
            )
          ),

          bslib::layout_columns(
            col_widths = 6,

            ## Refresh button ----
            argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("refresh"),
              label = "Refresh Data",
              disabled_msg = "Select a region / market first...",
              icon = shiny::icon("refresh", lib = "glyphicon")
            ),

            ## Save button ----
            argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("save"),
              label = "Save",
              disabled_msg = "Select a region / market first...",
              icon = shiny::icon("floppy-save", lib = "glyphicon")
            ),

            ## Save document files to S3 button ----
            argusDT.PriceStudioMain::mod_fileinput_ui(
              id = ns("fileinput"),
              button_label = "Upload...",
              placeholder = "or drop files here",
              msg = "Save any documents..."
            ),

            ## Show uploaded files
            argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("show_files"),
              label = "Show files",
              disabled_msg = "No files uploaded",
              icon = shiny::icon("floppy-saved", lib = "glyphicon")
            ),
          )
        ),

        # Status Box ----
        bslib::layout_columns(
          col_widths = 12,
          class = "main-box",
          gap = 0,
          mod_market_survey_status_ui(id = ns("market_survey_status"))
        )
      ),

      # Tabs ----
      ## tabs are added to this element dynamically
      bslib::navset_tab(id = ns("navset_tab"))
    )
  )
}


#' input_market Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_market_survey_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_market_survey_server:", get_ns(ns), level = 2)

    # Initialise variables ----
    r$market_survey <- shiny::reactiveValues()
    r$market_survey$markets <- NULL
    r$market_survey$market <- NULL
    r$market_survey$tabulator_ids <- list()
    r$market_survey$tabulators <- list()
    r$market_survey$observeEvent <- list()
    r$market_survey$fileinput <- NULL
    r$market_survey$visible_columns <- list()
    r$market_survey$dt_available_files <- NULL
    r$market_survey$download_filename <- paste0(format(r$rv$report_date, "%Y%m%d"), "_", r$s3_dir)
    r$market_survey$selected_files <- NULL
    r$market_survey$notes_switch <- TRUE
    r$market_survey$prefill_company_switch <- TRUE

    # Initialise triggers ----
    gargoyle::init(ns("visible_columns"))

    # Add widgets ----
    ## Pickers ----
    ### Market ----
    argusDT.PriceStudioMain::mod_pickerinput_server(
      id = "market",
      rv = r$market_survey,
      choices_rv = "markets",
      enable_trigger = "market_survey_enable_market",
      disable_trigger = "market_survey_disable_market"
    )

    ### Notes switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "notes_switch",
      rv = r$market_survey,
      enable_trigger = "market_survey_import",
      disable_trigger = "disable_buttons"
    )

    ### Prefill company switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "prefill_company_switch",
      rv = r$market_survey,
      enable_trigger = "market_survey_import",
      disable_trigger = "disable_buttons"
    )

    ## Buttons ----
    ### Refresh ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "refresh",
      triggers = "market_survey_import",
      enable_trigger = "market_survey_enable_refresh",
      disable_trigger = "disable_buttons"
    )

    ### Save ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "save",
      triggers = "market_survey_save",
      enable_trigger = "market_survey_import",
      disable_trigger = "disable_buttons"
    )

    ### Save documents ----
    argusDT.PriceStudioMain::mod_fileinput_server(
      id = "fileinput",
      rv = r$market_survey
    )

    ### Show documents
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "show_files",
      triggers = "market_survey_show_files",
      enable_trigger = "enable_show_files",
      disable_trigger = "disable_show_files"
    )

    ### Market Survey Status ----
    mod_market_survey_status_server(
      id = "market_survey_status",
      r = r
    )

    # Observe events ----

    ## Change market ----
    shiny::observeEvent(r$market_survey$market, {
      shiny::req(r$market_survey$market)

      log_info("observeEvent-mktsvy:", "r$market_survey$market", level = 2, session = session)

      gargoyle::trigger("market_survey_enable_refresh")
      gargoyle::trigger("market_survey_import")
    })

    ## Change region ----
    ### When region picker input is updated, update market list and reset some
    ### global variables
    shiny::observeEvent(r$rv$region, {
      log_info("observeEvent-mktsvy:", "r$rv$region", level = 2)

      ### Update Market Survey market lists to entire list of markets
      gargoyle::trigger("market_survey_disable_market")
      gargoyle::trigger("market_survey_show")

      r$market_survey$market <- NULL

      r$market_survey$markets <- sort(unique(
        r$rv$dt_market_content[MARKET_SURVEY_YN == "Y" & REGION == r$rv$region]$MARKET
      ))

      if (is_truthy(r$market_survey$markets)) {
        gargoyle::trigger("market_survey_enable_market")
      }
    })

    ## Show notes ----
    ### When Show notes is on - NOTES column is visible
    shiny::observeEvent(
      r$market_survey$notes_switch,
      {
        log_info("observeEvent-mktsvy:", "r$market_survey$notes_switch", level = 2)

        shiny::req(r$market_survey$tabulator_ids)

        gargoyle::trigger("market_survey_show_hide_notes")
      },
      ignoreInit = TRUE
    )

    ## Import ----
    shiny::observeEvent(
      gargoyle::watch("market_survey_import"),
      {
        log_info("observeEvent-mktsvy:", "market_survey_import", level = 1)

        if (is_truthy(r$market_survey$market)) {
          gargoyle::trigger("show_waiter")
          gargoyle::trigger("market_survey_create")
          gargoyle::trigger("market_survey_get_data")
          gargoyle::trigger("market_survey_combine")
          gargoyle::trigger("market_survey_pivot")
          gargoyle::trigger("market_survey_show")
        } else {
          gargoyle::trigger("market_survey_show")
        }
      },
      ignoreInit = TRUE
    )

    ## Create ----
    shiny::observeEvent(
      gargoyle::watch("market_survey_create"),
      {
        log_info("observeEvent-mktsvy:", "market_survey_create", level = 1)

        r$market_survey$dt_create <- fct_market_survey_create_table(
          report_date = r$rv$report_date,
          dt_market_content = r$rv$dt_market_content[REGION == r$rv$region],
          dt_codemaster = unique(
            r$rv$dt_codemaster[QUOTE_ID %in% r$rv$region_quote_id],
            by = "QUOTE_PRICETYPE_ID"
          ),
          dt_market_survey = r$market_survey$dt_market_survey,
          dt_pivot = r$market_survey$dt_pivot,
          prefill_company_switch = r$market_survey$prefill_company_switch
        )
      },
      ignoreInit = TRUE
    )

    ## Get data ----
    shiny::observeEvent(gargoyle::watch("market_survey_get_data"), {
      log_info("observeEvent-mktsvy:", "market_survey_get_data", level = 1)

      r$market_survey$dt_repo <- argusDT.PriceStudioMain::fct_get_market_survey_repo(
        app_id = get_config("application_id"),
        report_date = r$rv$report_date,
        db_env = r$rv$db_env,
        verbose = FALSE,
        connection = r$rv$ora_connection
      )
    })

    ## Combine ----
    shiny::observeEvent(
      gargoyle::watch("market_survey_combine"),
      {
        log_info("observeEvent-mktsvy:", "market_survey_combine", level = 1)

        r$market_survey$dt_market_survey <- fct_market_survey_combine(
          report_date = r$rv$report_date,
          comm_reporter = get_config("username"),
          dt_create = r$market_survey$dt_create,
          dt_repo = r$market_survey$dt_repo,
          dt_input = r$market_survey$dt_input,
          dt_pricetype = argusDT.PriceStudioMain::dt_pricetype
        )
      },
      ignoreInit = TRUE
    )

    ## Pivot ----
    shiny::observeEvent(
      gargoyle::watch("market_survey_pivot"),
      {
        log_info("observeEvent-mktsvy:", "market_survey_pivot", level = 1)

        r$market_survey$dt_pivot <- fct_market_survey_pivot(
          dt_market_survey = r$market_survey$dt_market_survey,
          dt_market_content = r$rv$dt_market_content[REGION == r$rv$region]
        )
      },
      ignoreInit = TRUE
    )

    ## Show ----
    shiny::observeEvent(
      gargoyle::watch("market_survey_show"),
      {
        log_info("observeEvent-mktsvy:", "market_survey_show", level = 1)

        fct_market_survey_show_tab(
          input,
          session,
          r,
          navset_tab_id = "navset_tab",
          market = r$market_survey$market
        )

        gargoyle::trigger("get_market_survey_status")
        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## Save ----
    shiny::observeEvent(
      gargoyle::watch("market_survey_save"),
      {
        log_info("observeEvent-mktsvy:", "market_survey_save", level = 1)

        saved <- fct_market_survey_save(
          dt_market_survey = r$market_survey$dt_market_survey[EDITED == TRUE],
          report_date = r$rv$report_date,
          application_id = get_config("application_id"),
          market = r$market_survey$market,
          username = get_config("username"),
          timezone = r$rv$user_timezone,
          session_id = session$userData$sid,
          db_env = r$rv$db_env,
          process_id = get_config("pid"),
          connection = r$rv$ora_connection,
          app_version = as.character(utils::packageVersion(pkg = pkgload::pkg_name()))
        )

        # Check if prices were saved
        if (saved == 0) {
          log_warn(
            "There are no new market survey items to save.",
            prompt = TRUE,
            session = session,
            type = "info",
            title = "Nothing to save"
          )

          gargoyle::trigger("hide_waiter")
        } else if (saved > 0) {
          log_warn(
            paste(saved, "market survey item has been saved."),
            prompt = TRUE,
            session = session,
            type = "success",
            title = "Market survey saved"
          )

          # Remove input values for market saved
          if (!is.null(r$market_survey$dt_input)) {
            r$market_survey$dt_input <- r$market_survey$dt_input[MARKET != r$market_survey$market]
          }

          ## Refresh data
          gargoyle::trigger("market_survey_get_data")
          gargoyle::trigger("market_survey_combine")
          gargoyle::trigger("market_survey_pivot")
          gargoyle::trigger("market_survey_replace")
          gargoyle::trigger("get_market_survey_status")

          ## Recalculate prices after saving market survey data
          if (is_truthy(r$rv$market)) {
            gargoyle::trigger("calculate_prices")
            gargoyle::trigger("check_prices")
            gargoyle::trigger("get_prices_status")
            gargoyle::trigger("pivot_prices")
            gargoyle::trigger("update_price_input")
          }
        } else if (saved < 0) {
          log_warn(
            "Market survey failed to save.",
            prompt = TRUE,
            session = session,
            title = "Market survey save failed"
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Save documents to S3 ----
    shiny::observeEvent(
      r$market_survey$fileinput,
      {
        log_info("observeEvent-mktsvy:", "save_documents", level = 1)

        file <- r$market_survey$fileinput
        source_filepath <- file$datapath
        filename <- file$name

        shiny::req(source_filepath)

        argusDT.PriceStudioMain::fct_save_files_to_s3(
          filename = filename,
          source_filepath = source_filepath,
          directory_filepath = r$rv$s3_documents_dir,
          s3_bucket = get_config("s3_bucket"),
          timezone = r$rv$user_timezone,
          region = r$rv$region
        )

        gargoyle::trigger("market_survey_check_files")
      },
      ignoreInit = TRUE
    )

    ## Column visibility (once)----
    shiny::observeEvent(
      r$market_survey$dt_pivot,
      {
        log_info("observeEvent-mktsvy:", "r$market_survey$dt_pivot", level = 1)

        r$market_survey$visible_columns <- argusDT.PriceStudioMain::fct_s3_visiblecols_read(
          col_names = c(colnames(r$market_survey$dt_pivot), "ID"),
          filename = id,
          db_env = r$rv$db_env,
          folder = r$s3_dir,
          s3_bucket = get_config("s3_bucket")
        )

        r$market_survey$notes_switch <- any(r$market_survey$visible_columns[["NOTES"]])
        gargoyle::trigger("get_market_survey_status")
      },
      ignoreInit = TRUE,
      once = TRUE,
      priority = 1
    )

    ## Visible columns modal ----
    shiny::observeEvent(
      gargoyle::watch(ns("visible_columns")),
      {
        log_info("observeEvent-mktsvy:", ns("visible_columns"), level = 2)

        shiny::req(r$market_survey$visible_columns, r$market_survey$dt_pivot)

        cols_vis <- r$market_survey$visible_columns
        cols_dt <- c(colnames(r$market_survey$dt_pivot), "ID")
        selected <- names(cols_vis[which(cols_vis == TRUE)])

        shiny::showModal(shiny::modalDialog(
          inputId = ns("visible_columns_modal"),
          title = "Show / Hide Market Survey Columns",
          size = "xl",
          easyClose = TRUE,

          bslib::card(
            max_height = "60vh",
            shinyWidgets::checkboxGroupButtons(
              inputId = ns("columns_checkbox_group"),
              choices = cols_dt,
              selected = selected,
              status = "primary",
              size = "sm",
              direction = "vertical",
              justified = TRUE,
              individual = TRUE,
              checkIcon = list(
                yes = fontawesome::fa("check", fill = "#44AB05"),
                no = fontawesome::fa("xmark", fill = "#DD2303")
              )
            )
          ),

          footer = bslib::layout_columns(
            col_widths = 6,
            max_height = "100%",

            argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("update_columns"),
              label = "Update"
            ),

            shiny::modalButton("Cancel") |> shiny::tagAppendAttributes(class = "btn-default")
          )
        ))
      },
      ignoreInit = TRUE
    )

    ## Update visible columns (S3) ----
    shiny::observeEvent(
      input$`update_columns-actionbutton`,
      {
        log_info("observeEvent-mktsvy:", "input$update_columns-actionbutton", level = 2)

        shiny::removeModal()

        shiny::req(input$columns_checkbox_group, r$market_survey$dt_pivot)

        r$market_survey$visible_columns <- argusDT.PriceStudioMain::fct_s3_visiblecols_write(
          col_names = c(colnames(r$market_survey$dt_pivot), "ID"),
          col_selected = input$columns_checkbox_group,
          filename = id,
          db_env = r$rv$db_env,
          folder = r$s3_dir,
          s3_bucket = get_config("s3_bucket")
        )

        r$market_survey$notes_switch <- any(r$market_survey$visible_columns[["NOTES"]])

        gargoyle::trigger("market_survey_import")
      },
      ignoreInit = TRUE
    )

    ## Check Market Survey files availability
    shiny::observeEvent(gargoyle::watch("market_survey_check_files"), {
      log_info("observeEvent-mktsvy:", "market_survey_check_files", level = 1)

      ### Get list of files
      r$market_survey$dt_available_files <- argusDT.S3::s3_get_bucket_dt(
        bucket = get_config("s3_bucket"),
        prefix = r$rv$s3_documents_dir
      )

      if (
        is_truthy(r$market_survey$dt_available_files) & nrow(r$market_survey$dt_available_files) > 0
      ) {
        gargoyle::trigger("enable_show_files")
      } else {
        gargoyle::trigger("disable_show_files")
      }

      gargoyle::trigger("get_market_survey_status")
    })

    ## Show saved files
    shiny::observeEvent(
      gargoyle::watch("market_survey_show_files"),
      {
        log_info("observeEvent-mktsvy:", "market_survey_show_files", level = 1)

        ### Get the files names and details
        dt <- r$market_survey$dt_available_files

        ### Get the file names from Key by removing path and keep only the name of the file uploaded
        dt[, filename := data.table::tstrsplit(Key, "/", keep = 6)]

        dt[, filename := data.table::transpose(stringr::str_split(filename, "_", n = 5))[5]]

        ### Create a modal
        shiny::showModal(shiny::modalDialog(
          inputId = ns("show_files_modal"),
          title = "Select File(s)",
          size = "xl",
          easyClose = TRUE,

          bslib::card(
            max_height = "60vh",
            shinyWidgets::checkboxGroupButtons(
              inputId = ns("files_checkbox_group"),
              choiceNames = dt$filename,
              choiceValues = dt$Key,
              selected = NULL,
              status = "primary",
              size = "sm",
              direction = "vertical",
              justified = TRUE,
              individual = TRUE,
              checkIcon = list(
                yes = fontawesome::fa("square-check"),
                no = fontawesome::fa("square")
              )
            )
          ),

          footer = bslib::layout_columns(
            col_widths = 6,
            max_height = "100%",
            mod_downloadbutton_s3_ui(
              id = ns("files"),
              label = "Download",
              icon = shiny::icon("download", lib = "glyphicon")
            ),

            shiny::modalButton("Cancel") |> shiny::tagAppendAttributes(class = "btn-default")
          )
        ))
      },
      ignoreInit = TRUE
    )

    ## Check the files selected for download
    shiny::observeEvent(
      input$`files_checkbox_group`,
      {
        log_info("observeEvent-mktsvy:", "input$files_checkbox_group", level = 2)

        shiny::req(r$market_survey$dt_available_files)

        if (is_truthy(input$`files_checkbox_group`)) {
          gargoyle::trigger("market_survey_enable_download")

          ### Download the files
          mod_downloadbutton_s3_server(
            id = "files",
            out_filename = r$market_survey$download_filename,
            files = input$`files_checkbox_group`,
            enable_trigger = "market_survey_enable_download",
            disable_trigger = "market_survey_disable_download"
          )
        } else {
          gargoyle::trigger("market_survey_disable_download")
        }
      },
      ignoreNULL = FALSE
    )
  })
}
