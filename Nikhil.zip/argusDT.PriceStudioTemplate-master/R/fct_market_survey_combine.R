#' Combine Market Survey Data
#'
#' @description `fct_market_survey_combine()` combines the various market survey
#' data sources.

#' @param report_date Date object with the current report date.
#' @param comm_reporter Character object specifying the username of the reporter.
#' @param dt_create A data.table with all market survey metadata.
#' @param dt_repo A data.table with the staged prices (STAFF.REPOSITORY_MARKET_SURVEY).
#' @param dt_input A data.table with the entered market survey.
#' @param dt_pricetype A data.table with the pricetype combinations.

#' @return
#' A data.table with the combined prices.
#'
#' @export
#'
#' @family market survey
#'
fct_market_survey_combine <- function(
  report_date,
  comm_reporter,
  dt_create,
  dt_repo,
  dt_input,
  dt_pricetype
) {
  log_info("fct_market_survey_combine", level = 2)

  dt <- data.table::copy(dt_create)
  cols_join <- c("CODE_ID", "TS", "CF", "PT", "MARKET_SURVEY_ITEM_ID")
  cols_inputs <- c(
    "TRADER_ID",
    "PRICE_CATEGORY_ID",
    "COMM_CONTACT_NAME",
    "COMM_METHOD_ID",
    "COMM_REPORTER",
    "COMM_TIMESTAMP",
    "COMM_TIMESTAMP_UTC",
    "PORT_ID",
    "UNIT_ID1",
    "UNIT_ID2",
    "DELIVERY_PERIOD_ID",
    "DELIVERY_YEAR",
    "NOTES",
    "VALUE",
    "INCLUDE",
    "DELETED",
    "EDITED"
  )

  ## Add rows for MS repo ----
  if (!is.null(dt_repo)) {
    if (dt_repo[, .N] > 0) {
      dt_rows <- dt_repo[, .(QUOTE_PRICETYPE_ID, MARKET_SURVEY_ITEM_ID)]
      dt_rows[, NEW := FALSE]
      dt <- dt_rows[dt, on = .(QUOTE_PRICETYPE_ID)]

      dt[
        is.na(MARKET_SURVEY_ITEM_ID),
        `:=`(MARKET_SURVEY_ITEM_ID = i.MARKET_SURVEY_ITEM_ID, NEW = i.NEW)
      ]

      cols_to_keep <- names(dt)[!grepl("i.", names(dt))]
      dt <- dt[, .SD, .SDcols = cols_to_keep]
    }
  }

  ## Add rows for new inputs ----
  if (!is.null(dt_input)) {
    if (dt_input[NEW == TRUE, .N] > 0) {
      cols_merge <- intersect(names(dt), names(dt_input))
      cols_merge <- cols_merge[!cols_merge %in% cols_inputs]

      dt <- data.table::merge.data.table(
        x = dt,
        y = dt_input[NEW == TRUE],
        by = cols_merge,
        all = TRUE,
        no.dups = FALSE,
        suffixes = c("", ".y")
      )

      cols_to_keep <- names(dt)[!grepl(".y", names(dt))]
      dt <- dt[, .SD, .SDcols = cols_to_keep]
    }
  }

  ## Add PRICETYPE_ADJ column ----
  pt_lows <- dt_pricetype[TABULATOR_COL == "LOW"]$PRICE_TYPE_ID
  pt_highs <- dt_pricetype[TABULATOR_COL == "HIGH"]$PRICE_TYPE_ID
  pt_mids <- dt_pricetype[TABULATOR_COL == "MID"]$PRICE_TYPE_ID

  dt[,
    PRICETYPE_ADJ := data.table::fcase(
      PT %in% (pt_lows)  , "LOW"  ,
      PT %in% (pt_highs) , "HIGH" ,
      PT %in% (pt_mids)  , "MID"
    )
  ]

  ### Remove MID's that are not listed in PRC_MARKET_CONTENT
  dt <- dt[!(is.na(IN_MARKET_CONTENT) & grepl("MID", PRICETYPE_ADJ))]

  ## Add columns ----
  ### NEW ----
  #### Add columns from user input (VALUE_SOURCE = "NEW")
  dt[, `:=`(
    NEW_TRADER_ID = NA_integer_,
    NEW_PRICE_CATEGORY_ID = NA_integer_,
    NEW_COMM_CONTACT_NAME = NA_character_,
    NEW_COMM_METHOD_ID = NA_integer_,
    NEW_COMM_REPORTER = comm_reporter,
    NEW_COMM_TIMESTAMP = NA_character_,
    NEW_COMM_TIMESTAMP_UTC = NA_character_,
    NEW_PORT_ID = NA_integer_,
    NEW_DELIVERY_PERIOD_ID = NA_integer_,
    NEW_DELIVERY_YEAR = NA_integer_,
    NEW_NOTES = NA_character_,
    NEW_VALUE = NA_real_,
    NEW_UNIT_ID1 = UNIT_ID1,
    NEW_UNIT_ID2 = UNIT_ID2,
    NEW_INCLUDE = TRUE,
    NEW_DELETED = FALSE,
    EDITED = FALSE
  )]

  if (!is.null(dt_input)) {
    dt[
      dt_input[NEW == TRUE],
      `:=`(
        NEW_TRADER_ID = i.TRADER_ID,
        NEW_PRICE_CATEGORY_ID = i.PRICE_CATEGORY_ID,
        NEW_COMM_CONTACT_NAME = i.COMM_CONTACT_NAME,
        NEW_COMM_METHOD_ID = i.COMM_METHOD_ID,
        NEW_COMM_REPORTER = i.COMM_REPORTER,
        NEW_COMM_TIMESTAMP = i.COMM_TIMESTAMP,
        NEW_COMM_TIMESTAMP_UTC = i.COMM_TIMESTAMP_UTC,
        NEW_PORT_ID = i.PORT_ID,
        NEW_DELIVERY_PERIOD_ID = i.DELIVERY_PERIOD_ID,
        NEW_DELIVERY_YEAR = i.DELIVERY_YEAR,
        NEW_NOTES = i.NOTES,
        NEW_VALUE = i.VALUE,
        NEW_UNIT_ID1 = i.UNIT_ID1,
        NEW_UNIT_ID2 = i.UNIT_ID2,
        NEW_INCLUDE = i.INCLUDE,
        NEW_DELETED = i.DELETED,
        NEW = i.NEW,
        EDITED = i.EDITED
      ),
      on = cols_join
    ]
  }

  ### MS ----
  #### Add columns from STAFF.REPOSITORY_MARKET_SURVEY (VALUE_SOURCE = "MS")
  dt[, `:=`(
    MS_TRADER_ID = NA_integer_,
    MS_PRICE_CATEGORY_ID = NA_integer_,
    MS_COMM_CONTACT_NAME = NA_character_,
    MS_COMM_REPORTER = NA_character_,
    MS_COMM_METHOD_ID = NA_integer_,
    MS_COMM_TIMESTAMP = NA_character_,
    MS_COMM_TIMESTAMP_UTC = NA_character_,
    MS_PORT_ID = NA_integer_,
    MS_DELIVERY_PERIOD_ID = NA_integer_,
    MS_DELIVERY_YEAR = NA_integer_,
    MS_VALUE = NA_real_,
    MS_UNIT_ID1 = NA_integer_,
    MS_UNIT_ID2 = NA_integer_,
    MS_NOTES = NA_character_,
    MS_INCLUDE = NA,
    MS_DELETED = NA
  )]

  if (!is.null(dt_repo)) {
    dt[
      dt_repo,
      `:=`(
        MS_TRADER_ID = i.TRADER_ID,
        MS_PRICE_CATEGORY_ID = i.PRICE_CATEGORY_ID,
        MS_COMM_CONTACT_NAME = i.COMM_CONTACT_NAME,
        MS_COMM_METHOD_ID = i.COMM_METHOD_ID,
        MS_COMM_REPORTER = i.COMM_REPORTER,
        MS_COMM_TIMESTAMP = i.COMM_TIMESTAMP,
        MS_COMM_TIMESTAMP_UTC = i.COMM_TIMESTAMP_UTC,
        MS_PORT_ID = i.PORT_ID,
        MS_DELIVERY_PERIOD_ID = i.DELIVERY_PERIOD_ID,
        MS_DELIVERY_YEAR = i.DELIVERY_YEAR,
        MS_NOTES = i.NOTES,
        MS_VALUE = i.VALUE,
        MS_UNIT_ID1 = i.UNIT_ID1,
        MS_UNIT_ID2 = i.UNIT_ID2,
        MS_INCLUDE = i.INCLUDE,
        MS_DELETED = i.DELETED
      ),
      on = cols_join
    ]
  }

  ### INPUT ----
  #### Add columns from user input (VALUE_SOURCE = "INPUT")
  dt[, `:=`(
    INPUT_TRADER_ID = NA_integer_,
    INPUT_PRICE_CATEGORY_ID = NA_integer_,
    INPUT_COMM_CONTACT_NAME = NA_character_,
    INPUT_COMM_METHOD_ID = NA_integer_,
    INPUT_COMM_REPORTER = NA_character_,
    INPUT_COMM_TIMESTAMP = NA_character_,
    INPUT_COMM_TIMESTAMP_UTC = NA_character_,
    INPUT_PORT_ID = NA_integer_,
    INPUT_DELIVERY_PERIOD_ID = NA_integer_,
    INPUT_DELIVERY_YEAR = NA_integer_,
    INPUT_NOTES = NA_character_,
    INPUT_VALUE = NA_real_,
    INPUT_UNIT_ID1 = NA_integer_,
    INPUT_UNIT_ID2 = NA_integer_,
    INPUT_INCLUDE = NA,
    INPUT_DELETED = NA
  )]

  if (!is.null(dt_input)) {
    dt[
      dt_input[NEW == FALSE],
      `:=`(
        INPUT_TRADER_ID = i.TRADER_ID,
        INPUT_PRICE_CATEGORY_ID = i.PRICE_CATEGORY_ID,
        INPUT_COMM_CONTACT_NAME = i.COMM_CONTACT_NAME,
        INPUT_COMM_METHOD_ID = i.COMM_METHOD_ID,
        INPUT_COMM_REPORTER = i.COMM_REPORTER,
        INPUT_COMM_TIMESTAMP = i.COMM_TIMESTAMP,
        INPUT_COMM_TIMESTAMP_UTC = i.COMM_TIMESTAMP_UTC,
        INPUT_PORT_ID = i.PORT_ID,
        INPUT_DELIVERY_PERIOD_ID = i.DELIVERY_PERIOD_ID,
        INPUT_DELIVERY_YEAR = i.DELIVERY_YEAR,
        INPUT_NOTES = i.NOTES,
        INPUT_VALUE = i.VALUE,
        INPUT_UNIT_ID1 = i.UNIT_ID1,
        INPUT_UNIT_ID2 = i.UNIT_ID2,
        INPUT_INCLUDE = i.INCLUDE,
        INPUT_DELETED = i.DELETED,
        EDITED = i.EDITED
      ),
      on = cols_join
    ]
  }

  ## Combine values ----
  ## Set current value based on the following order of precedence:
  ## 1. INPUT
  ## 2. MS
  ## 3. NEW

  ### NEW ----
  dt[
    NEW == TRUE,
    `:=`(
      VALUE_SOURCE = "NEW",
      TRADER_ID = NEW_TRADER_ID,
      PRICE_CATEGORY_ID = NEW_PRICE_CATEGORY_ID,
      COMM_CONTACT_NAME = NEW_COMM_CONTACT_NAME,
      COMM_METHOD_ID = NEW_COMM_METHOD_ID,
      COMM_REPORTER = NEW_COMM_REPORTER,
      COMM_TIMESTAMP = NEW_COMM_TIMESTAMP,
      COMM_TIMESTAMP_UTC = NEW_COMM_TIMESTAMP_UTC,
      PORT_ID = NEW_PORT_ID,
      DELIVERY_PERIOD_ID = NEW_DELIVERY_PERIOD_ID,
      DELIVERY_YEAR = NEW_DELIVERY_YEAR,
      NOTES = NEW_NOTES,
      VALUE = NEW_VALUE,
      UNIT_ID1 = NEW_UNIT_ID1,
      UNIT_ID2 = NEW_UNIT_ID2,
      INCLUDE = NEW_INCLUDE,
      DELETED = NEW_DELETED
    )
  ]

  ### MS ----
  dt[
    NEW == FALSE & EDITED == FALSE,
    `:=`(
      VALUE_SOURCE = "MS",
      TRADER_ID = MS_TRADER_ID,
      PRICE_CATEGORY_ID = MS_PRICE_CATEGORY_ID,
      COMM_CONTACT_NAME = MS_COMM_CONTACT_NAME,
      COMM_METHOD_ID = MS_COMM_METHOD_ID,
      COMM_REPORTER = MS_COMM_REPORTER,
      COMM_TIMESTAMP = MS_COMM_TIMESTAMP,
      COMM_TIMESTAMP_UTC = MS_COMM_TIMESTAMP_UTC,
      PORT_ID = MS_PORT_ID,
      DELIVERY_PERIOD_ID = MS_DELIVERY_PERIOD_ID,
      DELIVERY_YEAR = MS_DELIVERY_YEAR,
      NOTES = MS_NOTES,
      VALUE = MS_VALUE,
      UNIT_ID1 = MS_UNIT_ID1,
      UNIT_ID2 = MS_UNIT_ID2,
      INCLUDE = MS_INCLUDE,
      DELETED = MS_DELETED
    )
  ]

  ### INPUT ----
  if (!is.null(dt_input)) {
    dt[
      EDITED == TRUE & NEW == FALSE,
      `:=`(
        VALUE_SOURCE = "INPUT",
        TRADER_ID = data.table::fifelse(is.na(INPUT_TRADER_ID), TRADER_ID, INPUT_TRADER_ID),
        PRICE_CATEGORY_ID = data.table::fifelse(
          is.na(INPUT_PRICE_CATEGORY_ID),
          PRICE_CATEGORY_ID,
          INPUT_PRICE_CATEGORY_ID
        ),
        COMM_CONTACT_NAME = data.table::fifelse(
          is.na(INPUT_COMM_CONTACT_NAME),
          COMM_CONTACT_NAME,
          INPUT_COMM_CONTACT_NAME
        ),
        COMM_REPORTER = data.table::fifelse(
          is.na(INPUT_COMM_REPORTER),
          COMM_REPORTER,
          INPUT_COMM_REPORTER
        ),
        COMM_METHOD_ID = data.table::fifelse(
          is.na(INPUT_COMM_METHOD_ID),
          COMM_METHOD_ID,
          INPUT_COMM_METHOD_ID
        ),
        COMM_TIMESTAMP = data.table::fifelse(
          is.na(INPUT_COMM_TIMESTAMP),
          COMM_TIMESTAMP,
          INPUT_COMM_TIMESTAMP
        ),
        COMM_TIMESTAMP_UTC = data.table::fifelse(
          is.na(INPUT_COMM_TIMESTAMP_UTC),
          COMM_TIMESTAMP_UTC,
          INPUT_COMM_TIMESTAMP_UTC
        ),
        PORT_ID = data.table::fifelse(is.na(INPUT_PORT_ID), PORT_ID, INPUT_PORT_ID),
        DELIVERY_PERIOD_ID = data.table::fifelse(
          is.na(INPUT_DELIVERY_PERIOD_ID),
          DELIVERY_PERIOD_ID,
          INPUT_DELIVERY_PERIOD_ID
        ),
        DELIVERY_YEAR = data.table::fifelse(
          is.na(INPUT_DELIVERY_YEAR),
          DELIVERY_YEAR,
          INPUT_DELIVERY_YEAR
        ),
        NOTES = data.table::fifelse(is.na(INPUT_NOTES), NOTES, INPUT_NOTES, ),
        VALUE = data.table::fifelse(is.na(INPUT_VALUE), VALUE, INPUT_VALUE),
        UNIT_ID1 = data.table::fifelse(is.na(INPUT_UNIT_ID1), UNIT_ID1, INPUT_UNIT_ID1),
        UNIT_ID2 = data.table::fifelse(is.na(INPUT_UNIT_ID2), UNIT_ID2, INPUT_UNIT_ID2),
        INCLUDE = data.table::fifelse(is.na(INPUT_INCLUDE), INCLUDE, INPUT_INCLUDE),
        DELETED = data.table::fifelse(is.na(INPUT_DELETED), DELETED, INPUT_DELETED)
      )
    ]
  }

  return(dt)
}
