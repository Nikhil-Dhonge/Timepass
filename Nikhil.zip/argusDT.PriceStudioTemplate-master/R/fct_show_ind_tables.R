#' show_ind_tables
#' @description Show the tables in the UI.
#' @param input The input object.
#' @param session The session object.
#' @param r The global environment variable 'r'.
#' @param box_id The id of the box where the tables will be displayed.
#'
#' @return Invisible NULL.
#' @noRd
fct_show_ind_tables <- function(input, session, r, box_id) {
  ns <- session$ns

  log_info("fct_show_ind_tables ns:", get_ns(ns), level = 2)

  ### Removed tables displayed
  if (!is.null(r$rv$displayed_tables)) {
    purrr::walk(
      .x = r$rv$displayed_tables,
      .f = function(x, r) {
        id <- ns(x)

        ## Remove UI ----
        log_info("removeUI:", id, level = 3)

        shiny::removeUI(selector = paste0("#", id, "-text_output"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-tabulator"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-div"), immediate = TRUE)

        ## Remove inputs ----
        argusDT.PriceStudioMain::fct_remove_shiny_inputs(id = x, input, ns)
      },
      r = r
    )
  }

  ### Add tables (if nothing selected - show all)
  tbls <- r$rv$ind_tables_calc$final_tbls[
    names(r$rv$ind_tables_calc$final_tbls) %in% r$rv$selected_tables
  ]

  ### Remove duplicate tables if present
  if (length(r$rv$ind_tables_calc) > length(unique(names(r$rv$ind_tables_calc)))) {
    tbls <- tbls[1]
  }

  r$rv$displayed_tables <- names(tbls)

  #### Add tabulator UI
  purrr::walk(
    .x = ns(r$rv$displayed_tables),
    .f = mod_tabulator_indesign_ui,
    input_box_id = ns(box_id)
  )

  #### Add tabulator server
  purrr::walk2(
    .x = r$rv$displayed_tables,
    .y = tbls,
    .f = mod_tabulator_indesign_server
  )

  return(invisible(NULL))
}
