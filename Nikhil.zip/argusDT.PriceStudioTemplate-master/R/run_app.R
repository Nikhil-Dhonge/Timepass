#' Run the Shiny Application
#'
#' @inheritParams shiny::shinyApp
#' @param title Character title for the application.
#' @param db_env Character string to override the database environment locally.
#' Otherwise locally DEV will be used. On the servers the database environment
#' is provided by environment variables.
#' @param ...
#'
#' See `?golem::get_golem_options` for more details.
#' @export
run_app <- function(
  onStart = NULL,
  options = list(),
  enableBookmarking = NULL,
  uiPattern = "/",
  title = "Price Assessments",

  ## General arguments
  db_env = c("DEV", "UAT", "LIVE"),

  ## Optional arguments
  ...
) {
  # Log process ID ----
  log_info("process started: ", get_config("pid"))

  # Get database environment ----
  ## `match.arg` picks the first argument choice if choices are not specified
  db_env <- match.arg(db_env)
  ## Create variable to indicate if app is running locally or in RStudio Connect
  local <- Sys.getenv("SHINY_PORT") == ""
  ## Change database environment if app is running in RStudio Connect
  if (!local) {
    db_env <- argusDT.PriceStudioMain::fct_get_env_var(
      var_name = "DB_ENV",
      stop_app = TRUE,
      silent = FALSE
    )
  }

  # Get database credentials ----
  db_credentials <- argusDT.PriceStudioMain::fct_get_credentials(
    db_env = db_env,
    db_type = "oracle",
    db_user = "staff"
  )

  db_credentials_mysql <- argusDT.PriceStudioMain::fct_get_credentials(
    db_env = db_env,
    db_type = "aurora",
    db_user = "editorialro",
    db_name = "editorial"
  )

  # Create Oracle connection ----
  ora_connection <- argusDT.PriceStudioMain::fct_oracle_open_connection(
    uid = db_credentials$user,
    pwd = db_credentials$password,
    dsn = db_credentials$dsn
  )

  # Create MySQL connection ----
  mysql_connection <- argusDT.PriceStudioMain::fct_mysql_open_connection(
    uid = db_credentials_mysql$user,
    pwd = db_credentials_mysql$password,
    dbname = db_credentials_mysql$dbname,
    host = db_credentials_mysql$host
  )

  # Fetching Application properties
  app_properties <- argusDT.PriceStudioMain::fct_get_app_properties(
    app_id = get_config("application_id"),
    db_env = db_env,
    connection = ora_connection
  )

  # Fetching Scheduled Scripts mapping from PRC_SCHED_SCRIPTS_MAPPING table in database
  dt_script_map <- argusDT.PriceStudioMain::fct_get_sched_scripts_map(
    app_id = get_config("application_id"),
    db_env = db_env,
    connection = ora_connection
  )

  # Fetching Scheduled Scripts GUIDs json from .ds-connect-internal-group-mapping in S3
  dt_script_guids <- fct_get_script_guids(db_env = db_env, s3_bucket = get_config("s3_bucket"))

  # Fetching Regions
  regions_dt <- argusDT.PriceStudioMain::fct_get_regions(
    application_id = get_config("application_id"),
    report_date = lubridate::today(),
    db_env = db_env,
    connection = ora_connection
  )

  regions <- sort(regions_dt$REGION)
  region <- if (length(regions) > 1) NULL else regions

  exrate_day_offset <- if (length(regions) > 1) 0 else regions_dt$EXRATE_DAY_OFFSET
  exrate_time <- if (length(regions) > 1) 0 else regions_dt$EXRATE_TIME

  # Fetching Application settings- LinkFileName, CenshareTag, NetchartsFolder and Deal Module ids
  app_settings <- argusDT.PriceStudioMain::fct_get_app_settings(
    app_id = get_config("application_id"),
    db_env = db_env,
    connection = ora_connection
  )

  linkfile_filename <- NA_character_
  censhare_tag <- NA_character_
  charts_folders <- NULL
  deal_module_ids <- NULL
  commodity_ids <- NA_integer_
  exrate_unit_ids <- NA_integer_

  # Check App specific settings
  if (!is.null(app_settings)) {
    ## Check for Deal modules
    deal_module_ids <- as.numeric(app_settings[SETTING_TYPE == "Deal Module ID"]$PRC_SETTING)
    deal_module_ids <- if (length(deal_module_ids) > 0) deal_module_ids else NULL

    ## Check for Commodity ids - Market Survey
    commodity_ids <- as.numeric(app_settings[SETTING_TYPE == "Commodity ID"]$PRC_SETTING)

    ## Check for exrate unit ids
    exrate_unit_ids <- as.numeric(app_settings[SETTING_TYPE == "Exchange Rate Unit ID"]$PRC_SETTING)
    exrate_unit_ids <- if (length(exrate_unit_ids) > 0) exrate_unit_ids else c(3, 18)

    ## Check for Indesign variables
    if (all(c("LinkFileName", "CenshareTag") %in% app_settings$SETTING_TYPE)) {
      linkfile_filename <- app_settings[SETTING_TYPE == "LinkFileName"]$PRC_SETTING
      censhare_tag <- app_settings[SETTING_TYPE == "CenshareTag"]$PRC_SETTING
    }
  }

  # Stop app if Market Survey tab should be shown but no commodity ids are given
  if (get_config("show_tab_market_survey") && !is_truthy(commodity_ids)) {
    stop(
      "Market Survey tab can't be shown without commodity ids.\nEither add commodity ids to prc_app_settings or set the `show_tab_market_survey` config to `FALSE`."
    )
  }

  # Stop app if Indesign tab should be shown but no linkfile or censhare tag are given
  if (
    get_config("show_tab_indesign") && !is_truthy(linkfile_filename) && !is_truthy(censhare_tag)
  ) {
    stop(
      "Indesign tab can't be shown without a linkfile or censhare tag.\nEither add those to prc_app_settings or set the `show_tab_indesign` config to `FALSE`."
    )
  }

  # Set NetCharts folder if exists
  if ("NetchartsFolder" %in% app_settings$SETTING_TYPE) {
    charts_folders <- app_settings[SETTING_TYPE == "NetchartsFolder"]$PRC_SETTING
  }

  subtitle <- app_properties$SUBTITLE
  holiday_region <- app_properties$HOLIDAY
  csv_filename <- app_properties$SHORT_NAME
  s3_dir <- app_properties$SHORT_NAME
  hist_days <- app_properties$HIST_DAYS # used to find start_date in query for prices
  data_points <- app_properties$DATA_POINTS # n. of data points in a sparkline in tabulator summary
  fwd_list_start <- app_properties$FWD_LIST_START
  fwd_list_count <- app_properties$FWD_LIST_COUNT
  dbr_list_start <- app_properties$DBR_LIST_START
  dbr_list_count <- app_properties$DBR_LIST_COUNT
  app_start_date <- as.Date(app_properties$START_DATE)
  app_end_date <- as.Date(app_properties$END_DATE)
  deals_days <- app_properties$DEALS_DAYS
  frequency <- app_properties$FREQUENCY
  publish_day <- app_properties$PUBLISH_DAY

  # Market survey queries
  dt_traders <- if (get_config("show_tab_market_survey")) {
    argusDT.PriceStudioMain::fct_get_trader(
      commodity_ids = commodity_ids,
      db_env = db_env,
      connection = ora_connection
    )
  } else {
    data.table::data.table(NULL)
  }

  dt_ports <- if (get_config("show_tab_market_survey")) {
    argusDT.PriceStudioMain::fct_get_port(
      commodity_ids = commodity_ids,
      db_env = db_env,
      connection = ora_connection
    )
  } else {
    data.table::data.table(NULL)
  }

  dt_delivery_periods <- if (get_config("show_tab_market_survey")) {
    argusDT.PriceStudioMain::fct_get_delivery_period(
      commodity_ids = commodity_ids,
      db_env = db_env,
      connection = ora_connection
    )
  } else {
    data.table::data.table(NULL)
  }

  dt_comm_methods <- if (get_config("show_tab_market_survey")) {
    argusDT.PriceStudioMain::fct_get_comm_methods(db_env = db_env, connection = ora_connection)
  } else {
    data.table::data.table(NULL)
  }

  dt_price_category <- if (get_config("show_tab_market_survey")) {
    argusDT.PriceStudioMain::fct_get_price_category(db_env = db_env, connection = ora_connection)
  } else {
    data.table::data.table(NULL)
  }

  dt_unit <- if (get_config("show_tab_market_survey")) {
    argusDT.PriceStudioMain::fct_get_commodity_unit(
      commodity_ids = commodity_ids,
      db_env = db_env,
      connection = ora_connection
    )
  } else {
    data.table::data.table(NULL)
  }

  # Scheduled Scripts Trigger ----

  user_onStart <- onStart

  ## Wrapper that will run when the R process starts
  onStart <- function() {
    # Create the controller once per R process
    controller <- crew::crew_controller_local(
      name = "connect_controller",
      workers = 10,
      seconds_idle = 10
    )
    # controller <- crew::crew_controller_sequential() # Sequential for debugging
    controller$start()

    # Create script locks environment once per R process
    script_locks <- new.env(parent = emptyenv())
    options(script.locks = script_locks)

    # Initialize locks for each script as NULL
    # This environment is shared across all user sessions in this R process

    # Expose controller to the rest of the app via an option
    options(crew.controller = controller)

    # Ensure shutdown when the R process stops
    reg.finalizer(
      environment(),
      function(e) {
        try(controller$terminate(), silent = TRUE)
      },
      onexit = TRUE
    )

    # Call user-supplied onStart if present
    if (is.function(user_onStart)) user_onStart()
  }

  # Set onStop for process ----
  shiny::onStop(function() {
    argusDT.PriceStudioMain::fct_oracle_close_connection(ora_connection)
    log_info("process ended: ", get_config("pid"))
  })

  # Run app ----
  golem::with_golem_options(
    app = shiny::shinyApp(
      ui = app_ui,
      server = app_server,
      onStart = onStart,
      options = options,
      enableBookmarking = enableBookmarking,
      uiPattern = uiPattern
    ),
    golem_opts = list(
      title = title,
      local = local,
      deal_module_ids = deal_module_ids,
      db_env = db_env,
      ora_connection = ora_connection,
      mysql_connection = mysql_connection,
      subtitle = subtitle,
      holiday_region = holiday_region,
      csv_filename = csv_filename,
      linkfile_filename = linkfile_filename,
      s3_dir = s3_dir,
      charts_folders = charts_folders,
      censhare_tag = censhare_tag,
      hist_days = hist_days,
      deals_days = deals_days,
      data_points = data_points,
      exrate_day_offset = exrate_day_offset,
      exrate_time = exrate_time,
      exrate_unit_ids = exrate_unit_ids,
      commodity_ids = commodity_ids,
      fwd_list_start = fwd_list_start,
      fwd_list_count = fwd_list_count,
      dbr_list_start = dbr_list_start,
      dbr_list_count = dbr_list_count,
      app_start_date = app_start_date,
      app_end_date = app_end_date,
      regions = regions,
      region = region,
      dt_traders = dt_traders,
      dt_ports = dt_ports,
      dt_unit = dt_unit,
      dt_delivery_periods = dt_delivery_periods,
      dt_comm_methods = dt_comm_methods,
      dt_price_category = dt_price_category,
      dt_script_map = dt_script_map,
      dt_script_guids = dt_script_guids,
      frequency = frequency,
      publish_day = publish_day,
      ...
    )
  )
}
