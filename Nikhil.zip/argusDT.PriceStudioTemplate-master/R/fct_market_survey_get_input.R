#' fct_market_survey_get_input
#' @description A fct function
#' @param dt_data data.table containing the edited data
#' @param dt_market_survey data.table containing the market survey data
#' @param dt_input data.table containing the current inputs
#' @param dt_pricetype data.table containing the pricetype settings
#' @return The return value, if any, from executing the function.
#' @export
fct_market_survey_get_input <- function(dt_data, dt_market_survey, dt_input, dt_pricetype) {
  log_info("fct_market_survey_get_input", level = 2)

  ## Reformat columns
  dt_data[, `:=`(
    TRADER_ID = as.integer(TRADER_ID),
    PRICE_CATEGORY_ID = as.integer(PRICE_CATEGORY_ID),
    COMM_CONTACT_NAME = as.character(COMM_CONTACT_NAME),
    COMM_METHOD_ID = as.integer(COMM_METHOD_ID),
    COMM_REPORTER = as.character(COMM_REPORTER),
    COMM_TIMESTAMP = as.character(COMM_TIMESTAMP),
    COMM_TIMESTAMP_UTC = format(
      lubridate::with_tz(as.POSIXct(COMM_TIMESTAMP, optional = TRUE), tzone = "UTC"),
      "%Y-%m-%d %H:%M:%S",
      usetz = TRUE
    ),
    PORT_ID = as.integer(PORT_ID),
    DELIVERY_PERIOD_ID = as.integer(DELIVERY_PERIOD_ID),
    DELIVERY_YEAR = as.numeric(DELIVERY_YEAR),
    INCLUDE = as.logical(INCLUDE),
    DELETED = as.logical(DELETED),
    NOTES = as.character(NOTES),
    LOW = as.numeric(LOW),
    HIGH = as.numeric(HIGH),
    MID = as.numeric(MID),
    UNIT_ID1 = as.integer(UNIT_ID1),
    UNIT_ID2 = as.integer(UNIT_ID2)
  )]

  dt <- dt_market_survey[
    QPT_MID %in% dt_data$QPT_MID & MARKET_SURVEY_ITEM_ID %in% dt_data$MARKET_SURVEY_ITEM_ID
  ]

  if (dt[, .N] == 0) {
    dt <- unique(dt_market_survey[QPT_MID %in% dt_data$QPT_MID], by = "QUOTE_PRICETYPE_ID")

    dt[, MARKET_SURVEY_ITEM_ID := dt_data$MARKET_SURVEY_ITEM_ID]
    dt[, NEW := TRUE]
  }

  dt[, VALUE_SOURCE := "INPUT"]

  dt[
    dt_data,
    `:=`(
      TRADER_ID = i.TRADER_ID,
      PRICE_CATEGORY_ID = i.PRICE_CATEGORY_ID,
      COMM_CONTACT_NAME = i.COMM_CONTACT_NAME,
      COMM_METHOD_ID = i.COMM_METHOD_ID,
      COMM_REPORTER = i.COMM_REPORTER,
      COMM_TIMESTAMP = i.COMM_TIMESTAMP,
      COMM_TIMESTAMP_UTC = i.COMM_TIMESTAMP_UTC,
      PORT_ID = i.PORT_ID,
      UNIT_ID1 = i.UNIT_ID1,
      UNIT_ID2 = i.UNIT_ID2,
      DELIVERY_PERIOD_ID = i.DELIVERY_PERIOD_ID,
      DELIVERY_YEAR = i.DELIVERY_YEAR,
      INCLUDE = i.INCLUDE,
      DELETED = i.DELETED,
      NOTES = i.NOTES,
      PIVOT_LOW = i.LOW,
      PIVOT_HIGH = i.HIGH,
      PIVOT_MID = i.MID,
      PIVOT_PT_LOW = i.PT_LOW,
      PIVOT_PT_HIGH = i.PT_HIGH,
      PIVOT_PT_MID = i.PT_MID,
      EDITED = i.EDITED
    ),
    on = .(QPT_MID, MARKET_SURVEY_ITEM_ID)
  ]

  # Set INCLUDE to FALSE if DELETED is TRUE
  dt[DELETED == TRUE, INCLUDE := FALSE]

  ## Update values high low and mid in market survey table
  ### LOW
  dt[
    PT %in% dt_pricetype[TABULATOR_COL == "LOW"]$PRICE_TYPE_ID & QPT_MID %in% dt_data$QPT_MID,
    `:=`(VALUE = PIVOT_LOW, PT = PIVOT_PT_LOW)
  ]

  ### HIGH
  dt[
    PT %in% dt_pricetype[TABULATOR_COL == "HIGH"]$PRICE_TYPE_ID & QPT_MID %in% dt_data$QPT_MID,
    `:=`(VALUE = PIVOT_HIGH, PT = PIVOT_PT_HIGH)
  ]

  ### MID
  dt[
    PT %in% dt_pricetype[TABULATOR_COL == "MID"]$PRICE_TYPE_ID & QPT_MID %in% dt_data$QPT_MID,
    `:=`(VALUE = PIVOT_MID, PT = PIVOT_PT_MID)
  ]

  ## Remove unnecessary columns
  cols <- c("PIVOT_LOW", "PIVOT_HIGH", "PIVOT_MID", "PIVOT_PT_LOW", "PIVOT_PT_HIGH", "PIVOT_PT_MID")
  dt <- dt[, .SD, .SDcols = -cols]

  ## Round values
  dt[, VALUE := argus_round(VALUE, DECIMALPLACES)]

  ## Combine new inputs to rest of previous inputs
  if (!is.null(dt_input)) {
    dt <- rbind(
      dt_input[
        !(QPT_MID %in% dt_data$QPT_MID & MARKET_SURVEY_ITEM_ID %in% dt_data$MARKET_SURVEY_ITEM_ID)
      ],
      dt
    )
  }

  return(dt)
}
