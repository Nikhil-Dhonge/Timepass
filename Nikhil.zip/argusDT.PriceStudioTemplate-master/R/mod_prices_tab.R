#' prices_tab UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_prices_tab_ui <- function(id) {
  ns <- NS(id)

  shiny::tagList(
    htmltools::tags$div(
      id = ns("tabulator_prices-div"),
      style = "overflow-x: auto; padding-top: 0.5rem;",
      class = "main-box",

      shinyjs::hidden(
        htmltools::tags$div(
          id = ns("error_message_prices"),
          htmltools::tags$h5("No imported prices available for today.")
        )
      ),

      argusDS.tabulator::tabulatorOutput(
        outputId = ns("tabulator_prices"),
        height = "100%",
        width = "auto"
      )
    )
  )
}

#' prices_tab Server Functions
#'
#' @noRd
mod_prices_tab_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    ## Add tabulator table in Prices tab
    output$tabulator_prices <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator_prices"), level = 4)

      if (nrow(r$rv$dt_imported) > 0) {
        shinyjs::hide("error_message_prices")

        r$rv$dt_imported |> argusDT.PriceStudioMain::fct_render_tabulator_auto(paginationsize = 50)
      } else {
        shinyjs::show("error_message_prices")
      }
    }) |>
      shiny::bindEvent(r$rv$dt_imported)
  })
}
