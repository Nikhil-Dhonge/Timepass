#' check_staged_exrates
#'
#' @description This function checks the forex date and time staged by different markets of the selected region
#' @param r The global environment variable 'r'.
#' @return Nothing
#'
#' @noRd
#'
fct_check_staged_exrates <- function(r = r) {
  ### Reset these checks / variables just in case r$rv$dt_price_stg is either NULL
  ## or containing zero rows
  r$rv$xr_dte_stg_curr_m <- NA_character_
  r$rv$xr_time_stg_curr_m <- NA_character_

  r$rv$xr_dte_stg_other_m <- NA_character_
  r$rv$xr_time_stg_other_m <- NA_character_

  if (!is.null(r$rv$dt_prices_stg)) {
    if (r$rv$dt_prices_stg[, .N] > 0) {
      dt_mc <- r$rv$dt_market_content[
        TYPE != "Imported" & REGION == r$rv$region,
        .(CODE_ID, TS, CF, PT, MARKET)
      ]

      #### Perform the check on the selected market
      dt_exrate_curr_market <- unique(r$rv$dt_prices_stg[
        dt_mc[MARKET == r$rv$market],
        .(EXRATE_DATE, EXRATE_TIME, MARKET),
        on = c("CODE_ID", "TS", "CF", "PT"),
        nomatch = 0
      ])

      if (dt_exrate_curr_market[, .N] > 0) {
        r$rv$xr_dte_stg_curr_m <- dt_exrate_curr_market$EXRATE_DATE %>% unique()
        r$rv$xr_time_stg_curr_m <- dt_exrate_curr_market$EXRATE_TIME %>% unique()
      }

      #### Perform the check on any other markets within the selected region
      dt_exrate_other_markets <- unique(r$rv$dt_prices_stg[
        dt_mc[MARKET != r$rv$market],
        .(EXRATE_DATE, EXRATE_TIME, MARKET),
        on = c("CODE_ID", "TS", "CF", "PT"),
        nomatch = 0
      ])

      if (dt_exrate_other_markets[, .N]) {
        r$rv$xr_dte_stg_other_m <- dt_exrate_other_markets$EXRATE_DATE %>% unique()
        r$rv$xr_time_stg_other_m <- dt_exrate_other_markets$EXRATE_TIME %>% unique()

        #### If multiple different dates/time stamps were staged for other markets, set to 1 different to the current one.
        xr_date_to_check <- if (is.na(r$rv$xr_dte_stg_curr_m)) {
          r$rv$report_date
        } else {
          r$rv$xr_dte_stg_curr_m
        }

        if (any(xr_date_to_check != r$rv$xr_dte_stg_other_m)) {
          r$rv$xr_dte_stg_other_m <- r$rv$xr_dte_stg_other_m[
            xr_date_to_check != r$rv$xr_dte_stg_other_m
          ][1]
        }

        xr_time_to_check <- if (is.na(r$rv$xr_time_stg_curr_m)) {
          golem::get_golem_options("exrate_time")
        } else {
          r$rv$xr_time_stg_curr_m
        }

        if (any(xr_time_to_check != r$rv$xr_time_stg_other_m)) {
          r$rv$xr_time_stg_other_m <- r$rv$xr_time_stg_other_m[
            xr_time_to_check != r$rv$xr_time_stg_other_m
          ][1]
        }
      }
    }
  }
}
