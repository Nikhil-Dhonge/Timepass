#' fct_get_script_guids
#'
#' @description A fct function
#'
#' @return The return value, if any, from executing the function.
#'
#' @noRd
fct_get_script_guids <- function(db_env, s3_bucket) {
  # Get GUIDs from json mapping in S3 for all selected scripts
  folder <- ".ds-connect-internal-group-mapping"
  filename <- paste0("mapping-", tolower(db_env))
  fp <- file.path(folder, filename)
  dt <- data.table::as.data.table(
    argusDT.S3::s3_read_using(
      FUN = jsonlite::read_json,
      simplifyVector = TRUE,
      object = paste0(fp, ".json"),
      bucket = s3_bucket,
      prompt = FALSE
    )$apps
  )

  # Filter the scripts from argusDt.ScheduledScripts repo and is a quarto file (app-mode = 14)
  dt <- dt[`app-mode` == 14 & grepl("argusDT.ScheduledScripts", repo)]

  return(dt)
}
