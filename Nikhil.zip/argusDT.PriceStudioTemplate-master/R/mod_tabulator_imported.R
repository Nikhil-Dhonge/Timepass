#' tabulator_imported UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @param input_box_id The id of the box where to insert the tabulator.
#' @noRd
mod_tabulator_imported_ui <- function(id, input_box_id) {
  ns <- shiny::NS(id)

  log_info("mod_tabulator_imported_ui ns:", get_ns(ns), level = 3)

  shiny::insertUI(
    selector = paste0("#", input_box_id),
    where = "beforeBegin",
    ui = htmltools::div(
      class = "tabulator-table-ui",
      id = ns("div"),

      ## Table Title
      htmltools::tags$div(
        shiny::strong("Imported prices")
      ),

      ## Tabulator table
      htmltools::tags$div(
        argusDS.tabulator::tabulatorOutput(
          outputId = ns("table_cust"),
          height = "100%",
          width = 'auto'
        )
      )
    ),
    immediate = TRUE
  )
}


#' tabulator_imported Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @inheritParams fct_render_tabulator_imported
#' @noRd
mod_tabulator_imported_server <- function(id, r, paginationsize = 0) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_tabulator_imported_server ns:", get_ns(ns), level = 3)

    ## Set up a dt_prc object containing the information on calculation dependencies
    dt_prc <- unique(r$rv$dt_prc_asmp[
      SOURCE_TYPE %in% c("CODE_ID-TS-PT", "QUOTE_ID", "QUOTE_PRICETYPE_ID", "CODE_ID"),
      .(SOURCE_TYPE, SOURCE, QUOTE_ID, SOURCE_CODE_ID)
    ])

    ## Keep in dt_prc only the codes which belong to the current market selected by the user
    dt_prc <- unique(dt_prc[
      r$rv$dt_market_content[MARKET == r$rv$market],
      on = .(QUOTE_ID == QUOTE_ID)
    ])

    if (r$rv$dt_prices_all[TYPE == "Imported", .N] > 0 & dt_prc[, .N] > 0) {
      ## Set up a selection of columns to keep for the imported tabulator
      cols_to_keep <- c(
        "QUOTE_PRICETYPE_ID",
        "QUOTE_ID",
        "PUBLICATION_DATE",
        "CODE_ID",
        "CODE_DESCRIPTION",
        "PT",
        "LATEST",
        "PUBLISH",
        "FORWARD",
        "FORWARD_DROPDOWN",
        "FWD_DROPDOWN",
        "DBR",
        "VALUE",
        "CHANGE",
        "UNIT",
        "RANK",
        "DECIMALPLACES",
        "DIFF_BASE",
        "BASIS_DROPDOWN",
        "DBR_DROPDOWN"
      )

      ## Create a dt object which contains only imported prices where PUBLISH is true
      ## and order this by RANK ASC
      dt <- r$rv$dt_prices_all[TYPE == "Imported" & PUBLISH == TRUE, ..cols_to_keep]
      data.table::setorder(dt, RANK)

      ## For each QUOTE_PRICETYPE_ID, filter by first and second row of each group in order
      ## to extract only the latest and the second latest values expected, then add a RANK_IMPORTED
      ## column that will be used to pivot the data
      dt_imported <- dt[, .SD[1:2], by = QUOTE_PRICETYPE_ID]
      dt_imported[, RANK_IMPORTED := 1:.N, by = QUOTE_PRICETYPE_ID]

      ## Pivot dt_imported to display current and previous values in the columns
      dt_imported <- unique(data.table::dcast(
        dt_imported,
        QUOTE_PRICETYPE_ID +
          QUOTE_ID +
          CODE_ID +
          CODE_DESCRIPTION +
          UNIT +
          PT +
          DECIMALPLACES +
          DIFF_BASE ~
          RANK_IMPORTED,
        value.var = c("PUBLICATION_DATE", "VALUE", "CHANGE", "FORWARD", "DBR")
      ))

      ## Create a dt_forward_dbr_lists object to join with dt_imported to be able to
      ## format the forwards and the DBRs
      dt_forward_dbr_lists <- r$rv$dt_prices_all[, .(
        QUOTE_PRICETYPE_ID,
        FORWARD_DROPDOWN,
        FWD_DROPDOWN,
        BASIS_DROPDOWN,
        DBR_DROPDOWN
      )]

      dt_forward_dbr_lists <- dt_forward_dbr_lists[, .SD[1], by = QUOTE_PRICETYPE_ID]

      dt_imported <- dt_forward_dbr_lists[
        dt_imported,
        on = .(QUOTE_PRICETYPE_ID = QUOTE_PRICETYPE_ID)
      ]

      ## Set up vectors containing the sources to filter the dt_imported by
      code_ids <- dt_prc[SOURCE_TYPE %in% c("CODE_ID-TS-PT", "CODE_ID"), SOURCE_CODE_ID] |> unique()

      quote_ids <- dt_prc[SOURCE_TYPE == "QUOTE_ID", SOURCE] |> unique()

      qpt_ids <- dt_prc[SOURCE_TYPE == "QUOTE_PRICETYPE_ID", SOURCE] |> unique()

      ## Keep in dt_imported only the records effectively imported in the calculations for the
      ## selected market
      dt_imported <- dt_imported[
        CODE_ID %in% code_ids | QUOTE_ID %in% quote_ids | QUOTE_PRICETYPE_ID %in% qpt_ids
      ]

      data.table::setorder(dt_imported, CODE_DESCRIPTION, PT)

      ## Retrieve decoded names of PT from argusDT.PriceStudioMain::dt_pricetype object and join
      ## them with the code descriptions
      dt_imported <- argusDT.PriceStudioMain::dt_pricetype[dt_imported, on = .(PRICE_TYPE_ID == PT)]

      dt_imported[, CODE_DESCRIPTION := paste0(CODE_DESCRIPTION, " (", DESCRIPTION, ")")]

      ## Remove un-used columns
      dt_imported[, `:=`(
        QUOTE_PRICETYPE_ID = NULL,
        QUOTE_ID = NULL,
        DESCRIPTION = NULL,
        TABULATOR_COL = NULL,
        OUT_DIFF_TYPE = NULL,
        PT_MID = NULL,
        PT_LOW = NULL,
        PT_HIGH = NULL
      )]

      ## Rename and re-order columns previously pivoted
      data.table::setnames(dt_imported, gsub("1", "LATEST", names(dt_imported)))
      data.table::setnames(dt_imported, gsub("2", "PREVIOUS", names(dt_imported)))

      dt_imported[, ID := 1:.N]

      ## Display relevant DBR columns only if any PA code in the list has a DBR property
      display_dbr_cols <- !all(dt_imported$DIFF_BASE == "-")
    } else {
      dt_imported <- data.table::data.table()
    }

    ## Display imported tabulator
    if (dt_imported[, .N] > 0) {
      log_info("tabulatorOutput ID:", ns("table_cust"), level = 4)

      output$table_cust <- argusDS.tabulator::renderTabulator({
        argusDT.PriceStudioMain::fct_render_tabulator_imported(
          dt_imported,
          paginationsize,
          display_dbr_cols
        )
      }) |>
        shiny::bindEvent(dt_imported, paginationsize)
    } else {
      log_info("remove table_cust:", ns(""), level = 4)

      shiny::removeUI(
        selector = paste0("#", ns(""), "div"),
        multiple = FALSE,
        immediate = TRUE,
        session = session
      )
    }
  })
}
