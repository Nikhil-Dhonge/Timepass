#' summary UI Function
#' @description A shiny Module.
#' @param id,input,output,session Internal parameters for {shiny}.
#' @noRd
mod_summary_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_summary_ui ns:", get_ns(ns), level = 2)

  htmltools::tagList(
    bslib::layout_columns(
      class = "main-nav",
      col_widths = 12,
      row_heights = list("auto", 1),
      max_height = "100vh",
      bslib::layout_columns(
        col_widths = c(3, 3, 3, 3),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,

          #### Select market ----
          argusDT.PriceStudioMain::mod_pickerinput_ui(
            id = ns("summary_market"),
            choices = "",
            disabled_msg = if (length(golem::get_golem_options("regions")) > 1) {
              "Refresh data first..."
            } else {
              NULL
            },
            options = list(title = "Select market", `actions-box` = TRUE),
            multiple = TRUE
          ),

          ####  Refresh Data ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("refresh_summary"),
            label = "Refresh Data",
            disabled_msg = if (length(golem::get_golem_options("regions")) > 1) {
              "Select a region first..."
            } else {
              NULL
            },
            icon = shiny::icon("refresh", lib = "glyphicon"),
            style = "font-size: 16px"
          )
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = c(12, 12),

          ### Upload Prices ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("upload_prices"),
            label = "Upload Prices",
            disabled_msg = "Refresh data first...",
            icon = shiny::icon("cloud-upload", lib = "glyphicon"),
            style = "font-size: 16px"
          ),

          ### Include seasons in upload switch ----
          argusDT.PriceStudioMain::mod_switchinput_ui(
            id = ns("upload_seasons_switch"),
            label = "Include seasonal PA codes in upload",
            disabled_msg = "Refresh data first...",
            value = FALSE
          ),

          ### Tabulator filter message ----
          shinyjs::hidden(
            htmltools::tags$div(
              id = ns("tabulator_filter_message"),
              class = "tabulator_filter_status",
              shiny::textOutput(ns("textoutput"))
            )
          )
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = c(12, 12, 12),

          ### Create CSV ----
          mod_download_csv_ui(
            id = ns("create_csv"),
            label = "Download Full CSV",
            disabled_msg = "Refresh data first...",
            icon = shiny::icon("cloud-download", lib = "glyphicon"),
            style = "font-size: 16px"
          ),
          mod_download_csv_ui(
            id = ns("create_csv_filtered"),
            label = "Download Filtered CSV",
            disabled_msg = "Table not filtered",
            icon = shiny::icon("cloud-download", lib = "glyphicon"),
            style = "font-size: 16px",
          ),

          ### Run Scheduled Scripts ----
          shiny::uiOutput(outputId = ns("sched_script_btn_show"))
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,
          id = ns("status-box"),

          ### Progress bars and correction flag notice ----
          mod_prices_status_ui(id = ns("summary_status")),

          ### Total count switch ----
          argusDT.PriceStudioMain::mod_switchinput_ui(
            id = ns("total_count_switch"),
            label = "Total prices with filters applied",
            disabled_msg = "Show total prices with filters applied.",
            value = FALSE
          )
        )
      ),

      bslib::layout_columns(
        class = "main-box",
        col_widths = 12,
        id = ns("tabulator_box"),
        gap = 0,
        # Summary table ----
        shinyjs::hidden(
          htmltools::tags$div(
            id = ns("error_box"),
            style = "overflow-x: auto; text-align:center; color:red;",
            shiny::tags$h2(shiny::textOutput(outputId = ns("no_price_box")))
          )
        ),
        argusDS.tabulator::tabulatorOutput(
          outputId = ns("tabulator"),
          height = "100%"
        )
      )
    )
  )
}


#' summary Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_summary_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_summary_server ns:", get_ns(ns), level = 2)

    # Initialise triggers ----
    gargoyle::init(ns("visible_columns"))
    gargoyle::init(ns("summary_status-review_corrections"))

    # Modules ----
    ## Price status and correction box ----
    mod_prices_status_server(id = "summary_status", r, is_summary = TRUE)

    # Add widgets ----
    ## Pickers ----
    argusDT.PriceStudioMain::mod_pickerinput_server(
      id = "summary_market",
      rv = r$rv,
      choices_rv = "summary_markets",
      enable_trigger = "enable_market",
      ignoreNULL = FALSE,
      ignoreInit_choices = FALSE
    )

    output$sched_script_btn_show <- shiny::renderUI({
      if (is.null(golem::get_golem_options("dt_script_map"))) {
        NULL
      } else {
        argusDT.PriceStudioMain::mod_actionbutton_ui(
          id = ns("open_modal_sched_scripts"),
          label = "Run calculation scripts",
          disabled_msg = "Refresh data first...",
          icon = shiny::icon("cloud-download", lib = "glyphicon"),
          style = "font-size: 16px"
        )
      }
    })

    argusDT.PriceStudioMain::mod_pickerinput_server(
      id = "selected_sched_script",
      rv = r$rv,
      choices_rv = "sched_scripts",
      ignoreNULL = FALSE,
      ignoreInit_choices = FALSE
    )

    ## Buttons ----
    ### Refresh button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "refresh_summary",
      triggers = c("show_waiter", "fill_empty_market"),
      enable_trigger = "enable_market",
      disable_trigger = "disable_market"
    )

    ### Upload button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "upload_prices",
      triggers = "upload_prices_start",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### "OK" button in scheduled scripts modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "sched_script_ok",
      triggers = "run_scheduled_script"
    )

    ### "OK" button in upload modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "upload_warning",
      triggers = "save_csv_in_s3"
    )

    ### "OK" button in upload modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "upload_final",
      triggers = c("show_waiter", "upload_prices_end")
    )

    ### "OK" button in re-upload modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "reupload_final",
      triggers = c("show_waiter", "reupload_final_warnings")
    )

    ### Download CSV button ----
    mod_download_csv_server(
      id = "create_csv",
      r = r,
      full = TRUE,
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    mod_download_csv_server(
      id = "create_csv_filtered",
      r = r,
      full = FALSE,
      disable_trigger = "disable_buttons"
    )

    ## Total count switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "total_count_switch",
      rv = r$rv
    )

    ### Open modal Scheduled Scripts button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "open_modal_sched_scripts",
      triggers = "show_scheduled_scripts",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Include seasons in upload switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "upload_seasons_switch",
      rv = r$rv
    )

    ## Tables ----
    ### Summary table ----
    output$tabulator <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator"), level = 4)

      shiny::req(nrow(r$rv$dt_pivot_summary) > 0)

      argusDT.PriceStudioMain::fct_render_tabulator_summary(
        dt = r$rv$dt_pivot_summary,
        visible_cols = r$rv$columns_visible_summary,
        spk_filler_color = r$rv$spk_filler_color,
        spk_stroke_color = r$rv$spk_stroke_color
      )
    })

    #### No prices error box
    output$no_price_box <- shiny::renderText({
      if (!is.null(r$rv$summary_market)) {
        paste0(
          "There is no ",
          r$rv$region,
          " data for ",
          format(r$rv$report_date, "%e-%b-%Y"),
          " for the markets selected. Make sure you refreshed the app",
          " and have FINAL data saved for the day selected."
        )
      } else {
        paste0("There is no market selected.", " Make sure you select the market(s).")
      }
    })

    # Add observe events ----

    ## Fill empty market variable ----
    shiny::observeEvent(
      gargoyle::watch("fill_empty_market"),
      {
        log_info("observeEvent:", "fill_empty_market", level = 1)

        shiny::req(r$rv$region)

        ### Set a market if one hasn't been selected yet.
        if (!is.null(r$rv$market)) {
          if (r$rv$market == "") {
            r$rv$market <- r$rv$markets[1]
          }
        } else {
          r$rv$market <- r$rv$markets[1]
        }

        gargoyle::trigger("import_prices")
      },
      ignoreInit = TRUE
    )

    ## Scheduled Scripts Trigger ----

    if (!is.null(r$dt_script_map)) {
      ### Track which scripts this session has triggered ----
      session$userData$triggered_scripts <- list()

      ### Show the scheduled scripts list in a modal ----
      shiny::observeEvent(
        gargoyle::watch("show_scheduled_scripts"),
        {
          #### UI for scripts status ----
          req(length(r$rv$script_names) > 0)

          script_outputs <- Map(
            function(script_name, script_guid) {
              bslib::layout_columns(
                class = "main-box",
                style = "margin-bottom: 10px",
                col_widths = 12,
                shiny::div(
                  shiny::h4(script_name),
                  shiny::h6(script_guid, style = "font-size: 10px"),
                  shiny::uiOutput(ns(paste0("run_script_task_", script_name, "_status"))),
                )
              )
            },
            r$rv$script_names,
            r$rv$script_guids
          )

          #### Scripts selection ----
          shiny::showModal(shiny::modalDialog(
            title = "Run calculation scripts",
            size = "l",
            bslib::layout_columns(
              col_widths = c(6, 6),
              bslib::layout_columns(
                col_widths = c(12, 12, 6),
                shiny::h3("Select scripts"),
                argusDT.PriceStudioMain::mod_pickerinput_ui(
                  id = ns("selected_sched_script"),
                  choices = r$rv$script_names,
                  options = list(title = "Select script to run", `actions-box` = TRUE),
                  multiple = TRUE
                )
              ),
              bslib::layout_columns(
                col_widths = c(12),
                shiny::h3("Result"),
                script_outputs
              )
            ),
            footer = bslib::layout_columns(
              col_widths = c(6, 6),
              max_height = "100%",
              argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("sched_script_ok"),
                label = "Run script"
              ),
              shiny::modalButton("Close") |> shiny::tagAppendAttributes(class = "btn-default")
            ),
            easyClose = TRUE
          ))
        },
        ignoreInit = TRUE
      )

      ### Run the selected scheduled scripts ----
      shiny::observeEvent(
        gargoyle::watch("run_scheduled_script"),
        {
          shiny::req(r$dt_script_map)

          purrr::walk(r$rv$selected_sched_script, function(script_name) {
            task_name <- paste0("run_script_task_", script_name)
            if (exists(task_name, envir = r)) {
              task <- r[[task_name]]
              if (is.function(task$invoke)) {
                guid <- r$dt_script_guids[`app-name` == script_name, guid]

                # Track that this session triggered this script
                session$userData$triggered_scripts[[script_name]] <- Sys.time()

                task$invoke(
                  db_env = r$rv$db_env,
                  selected_script_name = script_name,
                  selected_script_guid = guid,
                  user_id = session$token
                )
              }
            }
          })
        },
        ignoreInit = TRUE
      )

      ### Show the script status ----
      purrr::walk(r$rv$script_names, function(script_name) {
        output_name <- paste0("run_script_task_", script_name, "_status")
        task_name <- paste0("run_script_task_", script_name)

        if (exists(task_name, envir = r)) {
          task <- r[[task_name]]

          output[[output_name]] <- shiny::renderUI({
            if (task$status() == "running") {
              shiny::span(
                shiny::icon("spinner", class = "fa-spin"),
                " Running...",
                style = "color: #ffc107;"
              )
            } else if (task$status() == "success") {
              result <- task$result()

              # Clean up lock after completion
              if (result$status == "triggered" || result$status == "error") {
                fct_cleanup_script_lock(result$script_name)
              }

              # Show status with appropriate styling
              if (result$status == "triggered") {
                shiny::span(
                  shiny::icon("check-circle"),
                  " Successfully triggered",
                  style = "color: #28a745;"
                )
              } else if (result$status == "locked") {
                shiny::span(
                  shiny::icon("lock"),
                  paste(" Already running (started", format(result$locked_at, "%H:%M:%S"), ")"),
                  style = "color: #dc3545;"
                )
              } else if (result$status == "error") {
                shiny::span(
                  shiny::icon("exclamation-circle"),
                  " Failed to trigger",
                  style = "color: #dc3545;"
                )
              } else {
                shiny::span(result$message)
              }
            } else {
              "" # No status to show yet
            }
          }) |>
            bindEvent(task$status())
        }
      })

      ### Clean up locks when session ends (only for scripts this session triggered) ----
      shiny::onStop(function() {
        # Access non-reactive userData directly - no reactive context needed
        triggered <- session$userData$triggered_scripts

        if (length(triggered) > 0 && !is.null(r$script_locks)) {
          for (script_name in names(triggered)) {
            # Only clean up if this session owns the lock
            lock_info <- r$script_locks[[script_name]]
            if (!is.null(lock_info) && lock_info$user_id == session$token) {
              r$script_locks[[script_name]] <- NULL
            }
          }
        }
      })
    }

    ## Create summary ----
    shiny::observeEvent(
      gargoyle::watch("create_summary"),
      {
        log_info("observeEvent:", "create_summary", level = 2)

        dt_summary <- fct_create_prices_table(
          report_date = r$rv$report_date,
          all_dates = r$rv$all_dates,
          dt_market_content = r$rv$dt_market_content[REGION == r$rv$region],
          dt_codemaster = unique(
            r$rv$dt_codemaster[QUOTE_ID %in% r$rv$region_quote_id],
            by = "QUOTE_PRICETYPE_ID"
          ),
          dt_prc_asmp = r$rv$region_dt_prc_asmp,
          dt_holidays = r$rv$dt_holidays,
          fwd_list_start = r$rv$fwd_list_start,
          fwd_list_count = r$rv$fwd_list_count,
          dbr_list_start = r$rv$dbr_list_start,
          dbr_list_count = r$rv$dbr_list_count,
          calendars = r$rv$all_calendars
        )

        dt_summary <- argusDT.PriceStudioMain::fct_combine_price_data(
          report_date = r$rv$report_date,
          dt_prices_all = dt_summary,
          dt_prices_live = r$rv$dt_prices_live,
          dt_prices_stg = r$rv$dt_prices_stg,
          dt_latest_notes = NULL,
          dt_prices_input = NULL,
          dt_pricetype = argusDT.PriceStudioMain::dt_pricetype,
          tab = "Summary",
          include_imported = FALSE,
          market = NULL
        )

        ## Remove all imported prices from dt_summary, if any
        dt_summary <- dt_summary[TYPE != "Imported"]

        ## Calculate change
        dt_summary[, PREV_RANK := RANK + 1]

        dt_summary[, QUOTE_PRICETYPE_ID := as.character(QUOTE_PRICETYPE_ID)]

        dt_summary[
          r$rv$dt_prices_all[, .(QUOTE_PRICETYPE_ID, VALUE, RANK)],
          `:=`(PREV_VALUE_CFWD = i.VALUE),
          on = .(QUOTE_PRICETYPE_ID == QUOTE_PRICETYPE_ID, PREV_RANK == RANK)
        ]

        dt_summary[
          r$rv$dt_prices_all[, .(CODE_ID, TS, PT, FWD, YEAR, VALUE, RANK)],
          `:=`(PREV_VALUE_FWD = i.VALUE),
          on = .(
            CODE_ID == CODE_ID,
            TS == TS,
            PT == PT,
            FWD == FWD,
            YEAR == YEAR,
            PREV_RANK == RANK
          )
        ]

        dt_summary[,
          CHANGE := data.table::fcase(
            CHANGE_MODE == "CFWD based" , VALUE - PREV_VALUE_CFWD ,
            CHANGE_MODE == "FWD based"  , VALUE - PREV_VALUE_FWD
          )
        ]

        ### Add ERROR and CORRECTION columns
        argusDT.PriceStudioMain::fct_check_prices(dt_summary, is_summary = TRUE)

        prompt_timings <- c("prompt", "spot", "dated", "day-ahead", "weekend", "week-ahead")

        ### Compute FORWARD column
        dt_summary[,
          FORWARD := data.table::fcase(
            !is.na(FWD) & !is.na(YEAR) & FWD != 0 , paste(YEAR, FWD, sep = "-") ,
            TIMING %in% prompt_timings            , TIMING                      ,
            default = "na"
          )
        ]

        ### Compute BASIS column
        dt_summary[,
          BASIS := data.table::fcase(
            !is.na(DBR) & DBR != 0 , as.integer(DBR) ,
            default = 0L
          )
        ]

        ### Create a dt with total prices to create status bar
        r$rv$dt_summary_total <- dt_summary[PUBLISH == TRUE]

        ### Only include assessments where PUBLISH == TRUE & FINAL == TRUE (final)
        r$rv$dt_summary <- dt_summary[PUBLISH == TRUE & FINAL == TRUE]

        # Warn if newly calculated prices are not staged and old prices remain on summary:
        final_summary <- r$rv$dt_summary[RANK == 1 & FINAL == TRUE & TYPE != "Imported"]
        final_price_input <- r$rv$dt_prices_all[RANK == 1 & FINAL == TRUE & TYPE != "Imported"]

        final_check <- !is.null(final_summary) &&
          !is.null(final_price_input) &&
          nrow(final_summary) > 0 &&
          nrow(final_price_input) > 0 &&
          nrow(final_summary) > nrow(final_price_input)

        if (final_check) {
          market <- unique(
            final_summary[!QUOTE_PRICETYPE_ID %in% final_price_input$QUOTE_PRICETYPE_ID]$MARKET
          )

          log_warn(
            c("Re-calculated prices need to be staged again in the following markets:", market),
            prompt = TRUE,
            collapse = "\n",
            title = "Calculated prices need to be staged",
            type = "info"
          )
        }

        r$rv$dt_summary_report_day <- r$rv$dt_summary[RANK == 1]

        r$rv$summary_ui_switch <- !r$rv$summary_ui_switch

        if (nrow(r$rv$dt_summary_report_day) == 0) {
          r$rv$dt_pivot_summary <- data.table::as.data.table(NULL)
          r$rv$dt_summary_report_day <- data.table::as.data.table(NULL)
          r$rv$summary_ui_switch <- !r$rv$summary_ui_switch
        }

        shiny::req(nrow(r$rv$dt_summary_report_day) > 0)

        ### Get summary pivot
        r$rv$dt_pivot_summary_all <- argusDT.PriceStudioMain::fct_pivot_prices(
          dt_prices = r$rv$dt_summary,
          dt_market_content = r$rv$dt_market_content[REGION == r$rv$region]
        )

        ### Format summary table
        r$rv$dt_pivot_summary_all <- argusDT.PriceStudioMain::fct_get_pivot_section(
          r$rv$dt_pivot_summary_all
        )

        ### Add sparklines to pivot
        dt_sparklines <- argusDT.PriceStudioMain::fct_get_sparklines(r$rv$dt_summary)

        r$rv$dt_pivot_summary_all[
          dt_sparklines,
          SPARKLINE := i.SPARKLINE,
          on = c(QPT_MID = "QUOTE_PRICETYPE_ID")
        ]

        ### Filter summary based on Market selected
        if (!is.null(r$rv$summary_market)) {
          r$rv$dt_pivot_summary <- r$rv$dt_pivot_summary_all[MARKET %in% r$rv$summary_market]
        } else {
          r$rv$dt_pivot_summary <- data.table::as.data.table(NULL)
          r$rv$dt_summary_report_day <- data.table::as.data.table(NULL)
        }

        ### Create datawell
        gargoyle::trigger("create_datawell")

        ### Get status
        gargoyle::trigger("get_summary_status")
      },
      ignoreInit = TRUE
    )

    ## Display no prices error ----
    shiny::observeEvent(
      r$rv$summary_market,
      {
        shiny::req(nrow(r$rv$dt_pivot_summary_all) > 0)

        ### Filter summary based on Market selected
        if (!is.null(r$rv$summary_market)) {
          r$rv$dt_pivot_summary <- r$rv$dt_pivot_summary_all[MARKET %in% r$rv$summary_market]
          r$rv$dt_summary_report_day <- r$rv$dt_summary[RANK == 1]
          r$rv$summary_ui_switch <- !r$rv$summary_ui_switch
        } else {
          r$rv$dt_pivot_summary <- data.table::as.data.table(NULL)
          r$rv$dt_summary_report_day <- data.table::as.data.table(NULL)
          r$rv$summary_ui_switch <- !r$rv$summary_ui_switch
        }

        gargoyle::trigger("get_summary_status")
      },
      ignoreInit = TRUE,
      ignoreNULL = FALSE
    )

    ## Display no prices error ----
    shiny::observeEvent(r$rv$summary_ui_switch, {
      log_info("observeEvent:", "r$rv$dt_summary", level = 2)

      if (is_truthy(nrow(r$rv$dt_pivot_summary) > 0)) {
        shinyjs::show("tabulator")
        shinyjs::hide("error_box")
      } else {
        shinyjs::hide("tabulator")
        shinyjs::show("error_box")
      }
    })

    ## Create datawell ----
    shiny::observeEvent(
      gargoyle::watch("create_datawell"),
      {
        log_info("observeEvent:", "create_datawell", level = 2)

        shiny::req(nrow(r$rv$dt_summary_report_day) > 0)

        r$rv$dt_datawell_full <- argusDT.PriceStudioMain::fct_create_datawell(r$rv$dt_summary)
      },
      ignoreInit = TRUE
    )

    ## Update status bar totals based on switch ----
    shiny::observeEvent(
      r$rv$total_count_switch,
      {
        gargoyle::trigger("get_summary_status")
      },
      ignoreInit = TRUE
    )

    ## Get status ----
    shiny::observeEvent(
      gargoyle::watch("get_summary_status"),
      {
        log_info("observeEvent:", "get_summary_status", level = 2)

        shiny::req(nrow(r$rv$dt_summary_report_day) > 0)

        # If no filters are applied, use the total summary data
        dt_summary_total <- r$rv$dt_summary_total[MARKET %in% r$rv$summary_market]

        # If filters are applied, apply them to the total summary data
        if (nrow(r$rv$filters) > 0 && r$rv$total_count_switch == TRUE) {
          # Named vector of filters
          filters <- setNames(
            lapply(r$rv$filters[[2]], function(x) {
              gsub("([.|()\\^{}+$*?\\[\\]\\\\])", "\\\\\\1", x)
            }),
            r$rv$filters[[1]]
          )

          # Apply filters to total summary data
          r$rv$dt_summary_total_filtered <- purrr::reduce(
            names(filters),
            function(dt, col) {
              dt[grepl(filters[[col]], dt[[col]], ignore.case = TRUE)]
            },
            .init = dt_summary_total
          )
        } else {
          r$rv$dt_summary_total_filtered <- NULL
        }

        gargoyle::trigger("get_prices_status")
      },
      ignoreInit = TRUE
    )

    ## Update filters ----
    shiny::observeEvent(
      input$tabulator_filters_summary,
      {
        if (length(input$tabulator_filters_summary$data) > 0) {
          r$rv$filters <- input$tabulator_filters_summary$data
        } else {
          r$rv$filters <- data.table::data.table(field = character(0), value = character(0))
        }

        gargoyle::trigger("get_summary_status")
      },
      ignoreInit = TRUE
    )

    ## Update filtered data message ----
    shiny::observeEvent(
      input$tabulator_filtered_table$data,
      {
        log_info("observeEvent:", "Update filtered data message", level = 2)

        dt <- data.table::data.table(input$tabulator$data)

        dt_filt <- data.table::data.table(input$tabulator_filtered_table$data)

        if (dt[, .N] != dt_filt[, .N]) {
          output$textoutput <- shiny::renderText(glue::glue(
            "N.B.: Only filtered data (currently {dt_filt[is.na(LIVE_MID), .N]} record(s)) will
            be uploaded when a filter is applied to the headers of the table."
          ))
          shinyjs::show("tabulator_filter_message")

          filtered_qpt_mid <- dt_filt$QPT_MID

          r$rv$dt_datawell_filtered <- argusDT.PriceStudioMain::fct_create_datawell(r$rv$dt_summary[
            MARKET %in% r$rv$summary_market & QPT_MID %in% filtered_qpt_mid
          ])

          shinyjs::enable(id = "summary-create_csv_filtered-download_csv", asis = TRUE)
        } else {
          shinyjs::hide("tabulator_filter_message")

          shinyjs::disable(id = "summary-create_csv_filtered-download_csv", asis = TRUE)

          r$rv$dt_datawell_filtered <- argusDT.PriceStudioMain::fct_create_datawell(r$rv$dt_summary[
            MARKET %in% r$rv$summary_market
          ])
        }
      },
      ignoreInit = TRUE
    )

    ## Start upload ----
    ### Gathers user information and trigger final upload
    shiny::observeEvent(
      gargoyle::watch("upload_prices_start"),
      {
        log_info("observeEvent:", "upload_prices_start", level = 2)

        ### Reset skip_fp_validation argument at the start of each new upload user request
        r$rv$skip_fp_validation <- FALSE

        ### Retrieve data (filtered tabulator always matches full tabulator if no filters are
        # applied, therefore can use input$tabulator_filtered_table$data to retrieve QPTs)
        filtered_qpt_mid <- input$tabulator_filtered_table$data$QPT_MID

        ### Check switch to upload seasons, if ON then include seasons, if OFF filter them out
        if (r$rv$upload_seasons_switch) {
          r$rv$dt_datawell_api <- argusDT.PriceStudioMain::fct_create_datawell(r$rv$dt_summary[
            MARKET %in% r$rv$summary_market & QPT_MID %in% filtered_qpt_mid
          ][is.na(LIVE_VALUE)])
        } else {
          r$rv$dt_datawell_api <- argusDT.PriceStudioMain::fct_create_datawell(r$rv$dt_summary[
            MARKET %in% r$rv$summary_market & QPT_MID %in% filtered_qpt_mid & TIMING != "season"
          ][is.na(LIVE_VALUE)])
        }

        ### Alert user if there are no filtered data to upload via API
        if (nrow(r$rv$dt_datawell_api) == 0) {
          log_warn(
            "No prices match the filters selected.",
            prompt = TRUE,
            type = "info",
            title = "API upload failed"
          )
        }

        ### Check the timings included in the datawell, season timing needs to be uploaded
        ### separately due to the skip forward period validation check
        code_ids_api <- stringr::str_replace_all(r$rv$dt_datawell_api$Code |> unique(), "PA", "") |>
          as.numeric()

        timings_api <- r$rv$dt_summary[CODE_ID %in% code_ids_api, TIMING] |> unique()

        if (length(timings_api) > 1 & "season" %in% timings_api) {
          log_warn(
            "PA codes with timing season are required to be uploaded separately. \n
            Toggle 'upload seasons switch' or use filter in Timing column to do so.",
            prompt = TRUE,
            type = "info",
            title = "API upload failed"
          )
          r$rv$dt_datawell_api <- NULL
        } else if (length(timings_api) == 1 & "season" %in% timings_api) {
          r$rv$skip_fp_validation <- TRUE
        }

        shiny::req(nrow(r$rv$dt_datawell_api) > 0)

        ### Check if summary needs to be refreshed
        max_staged_time <- argusDT.PriceStudioMain::fct_get_max_time_staged(
          app_id = get_config("application_id"),
          markets = r$rv$summary_market,
          region = r$rv$region,
          db_env = r$rv$db_env,
          connection = r$rv$ora_connection
        )

        is_summary_updated <- FALSE

        max_loaded_time <- max(
          r$rv$dt_summary_report_day[MARKET %in% r$rv$summary_market]$TIME_STAGED
        )

        if (is_truthy(max_staged_time$TIME_STAGED != max_loaded_time)) {
          is_summary_updated <- TRUE
          shiny::showModal(shiny::modalDialog(
            title = "New prices were saved",
            " New prices were recently saved.
              Before uploading, consider refreshing the Summary to obtain the latest changes.",
            easyClose = FALSE,
            footer = bslib::layout_columns(
              col_widths = 6,
              max_height = "100%",

              argusDT.PriceStudioMain::mod_actionbutton_ui(ns("upload_warning"), "Proceed"),

              shiny::modalButton("Cancel") %>% shiny::tagAppendAttributes(class = "btn-default")
            )
          ))
        }

        if (is_summary_updated == FALSE) {
          gargoyle::trigger("save_csv_in_s3")
        }
      },
      ignoreInit = TRUE
    )

    ### Save CSV file to S3 bucket
    shiny::observeEvent(
      gargoyle::watch("save_csv_in_s3"),
      {
        log_info("observeEvent:", "save_csv_in_s3", level = 2)

        log_info("save CSV file to s3 bucket", level = 3)

        r$rv$csv_filename <- argusDT.PriceStudioMain::fct_get_csv_filename(
          report_date = r$rv$report_date,
          basename = golem::get_golem_options("csv_filename"),
          region = r$rv$region,
          timezone = r$rv$user_timezone
        )

        ### Save file to S3 bucket
        argusDT.PriceStudioMain::fct_save_csv_to_s3(
          dt_csv = r$rv$dt_datawell_api,
          file_path = file.path(r$rv$s3_csv_dir, r$rv$csv_filename),
          s3_bucket = get_config("s3_bucket")
        )

        gargoyle::trigger("upload_prices_pwd_modal")
      },
      ignoreInit = TRUE
    )

    ## Upload uid and pwd ----
    ### Get username and pwd for price upload
    shiny::observeEvent(
      gargoyle::watch("upload_prices_pwd_modal"),
      {
        log_info("observeEvent:", "upload_prices_pwd_modal", level = 2)

        ### Ask user to enter API upload credentials
        shiny::showModal(shiny::modalDialog(
          inputId = "password_modal",
          shiny::tags$h2("Argus Admin/ Direct Credentials"),
          shiny::textInput(
            inputId = ns("username_input"),
            placeholder = ("xxx.xxx@argusmedia.com"),
            label = shiny::tagList(shiny::icon("user", lib = "glyphicon"), "Username"),
            value = if (is.null(r$rv$user_email)) get_config("username") else r$rv$user_email
          ),
          shiny::passwordInput(
            inputId = ns("password_input"),
            label = "Password",
            value = r$rv$user_pwd
          ),
          footer = shiny::tagList(
            col_4(argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("upload_final"),
              label = "OK"
            )),
            col_4(
              shiny::modalButton("Cancel") %>% shiny::tagAppendAttributes(class = "btn-default")
            )
          ),
          size = "s",
          easyClose = FALSE
        ))
      },
      ignoreInit = TRUE
    )

    ## Finish upload ----
    ### Calls API upload function
    shiny::observeEvent(
      gargoyle::watch("upload_prices_end"),
      {
        log_info("observeEvent:", "upload_prices_end", level = 2)

        ### Do not upload if username and/or password are missing
        shiny::req(input$username_input, input$password_input)

        ### Update user email and password so any changes remain persistent
        r$rv$user_email <- input$username_input
        r$rv$user_pwd <- input$password_input

        # Regular expression for validating email format
        valid_email <- grepl(
          "^[A-Za-z'-]+(?:\\.[A-Za-z'-]+){1,2}@argusmedia\\.com$",
          r$rv$user_email,
          perl = TRUE
        )

        # Remove any previous notification
        shiny::removeNotification(id = "user_cred_notification")

        if (!valid_email) {
          shiny::showNotification(
            "Please enter a valid username in the format 'firstname.lastname@argusmedia.com'",
            id = "user_cred_notification",
            duration = NULL,
            type = "warning",
            closeButton = TRUE
          )
        } else {
          shiny::removeModal()

          ### Upload prices
          r$rv$api_feedback <- argusDT.PriceStudioMain::fct_upload_prices_api(
            data = r$rv$dt_datawell_api,
            descriptions = unique(r$rv$dt_summary_report_day[, .(CODE_ID, CODE_DESCRIPTION)]),
            filename = r$rv$csv_filename,
            db_env = r$rv$db_env,
            test_mode = r$rv$test_mode,
            email_notification_to = r$rv$user_email,
            argus_username = r$rv$user_email,
            argus_password = r$rv$user_pwd,
            skip_fp_validation = r$rv$skip_fp_validation
          )

          ### If data uploaded successfully
          if (r$rv$api_feedback$success == TRUE) {
            gargoyle::trigger("send_deadline_email")
            gargoyle::trigger("get_live_prices")
            gargoyle::trigger("combine_price_data")
            gargoyle::trigger("calculate_prices")
            gargoyle::trigger("check_prices")
            gargoyle::trigger("pivot_prices")
            gargoyle::trigger("update_price_input")
            gargoyle::trigger("create_summary")
            gargoyle::trigger("get_prices_status")
            gargoyle::trigger("user_msg_modal")

            ### Any other error messages
          } else {
            gargoyle::trigger("user_msg_modal")
          }
        }
      },
      ignoreInit = TRUE
    )

    ### Show modal dialog to the user based on upload API feedback
    shiny::observeEvent(
      gargoyle::watch("user_msg_modal"),
      {
        log_info("observeEvent:", "user_msg_modal", level = 2)

        ### If data uploaded successfully
        if (r$rv$api_feedback$success == TRUE) {
          shiny::showModal(shiny::modalDialog(
            r$rv$api_feedback$message,
            title = "Information",
            easyClose = TRUE,
            footer = shiny::tagList(col_4(shiny::modalButton("OK")), col_4())
          ))

          ### If red errors occur
        } else if ("Error" %in% r$rv$api_feedback$tbl$severity) {
          shiny::showModal(shiny::modalDialog(
            size = "xl",
            shiny::tags$h2(r$rv$api_feedback$message),
            htmltools::tags$div(
              id = ns("tabulator_box"),
              style = "overflow-x: auto;",
              argusDS.tabulator::tabulatorOutput(
                outputId = ns("tabulator_api_errors"),
                height = "100%",
                width = "auto"
              )
            ),
            easyClose = TRUE,
            footer = shiny::tagList(col_4(shiny::modalButton("OK")), col_4())
          ))

          ### If green warnings occur
        } else if ("Warn" %in% r$rv$api_feedback$tbl$severity) {
          shiny::showModal(shiny::modalDialog(
            size = "xl",
            shiny::tags$h2(r$rv$api_feedback$message),
            htmltools::tags$div(
              id = ns("tabulator_box"),
              style = "overflow-x: auto;",
              argusDS.tabulator::tabulatorOutput(
                outputId = ns("tabulator_api_errors"),
                height = "100%",
                width = "auto"
              )
            ),
            footer = shiny::tagList(
              ### re-upload values
              col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("reupload_final"),
                label = "Proceed"
              )),
              col_2(
                shiny::modalButton("Cancel") %>% shiny::tagAppendAttributes(class = "btn-default")
              )
            )
          ))

          ### Any other error messages
        } else {
          shiny::showModal(shiny::modalDialog(
            r$rv$api_feedback$message,
            title = "Information",
            easyClose = TRUE,
            footer = shiny::tagList(col_4(shiny::modalButton("OK")), col_4())
          ))
        }

        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## API Errors table ----
    output$tabulator_api_errors <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator_api_errors"), level = 4)

      argusDT.PriceStudioMain::fct_render_tabulator_auto(r$rv$api_feedback$tbl)
    }) |>
      shiny::bindEvent(r$rv$api_feedback$tbl)

    ## Finish upload w/ warnings ----
    ### Calls API upload function after warnings override
    shiny::observeEvent(
      gargoyle::watch("reupload_final_warnings"),
      {
        log_info("observeEvent:", "reupload_final_warnings", level = 2)

        shiny::removeModal()

        ### Upload prices
        r$rv$api_feedback <- argusDT.PriceStudioMain::fct_upload_prices_api(
          data = r$rv$dt_datawell_api,
          descriptions = unique(r$rv$dt_summary_report_day[, .(CODE_ID, CODE_DESCRIPTION)]),
          filename = r$rv$csv_filename,
          db_env = r$rv$db_env,
          test_mode = r$rv$test_mode,
          email_notification_to = r$rv$user_email,
          argus_username = r$rv$user_email,
          argus_password = r$rv$user_pwd,
          ignore_warnings = TRUE,
          skip_fp_validation = r$rv$skip_fp_validation
        )

        ### Refresh uploaded data
        if (r$rv$api_feedback$success == TRUE) {
          gargoyle::trigger("send_deadline_email")
          gargoyle::trigger("get_live_prices")
          gargoyle::trigger("combine_price_data")
          gargoyle::trigger("calculate_prices")
          gargoyle::trigger("check_prices")
          gargoyle::trigger("pivot_prices")
          gargoyle::trigger("update_price_input")
          gargoyle::trigger("create_summary")
          gargoyle::trigger("get_prices_status")
          gargoyle::trigger("user_msg_modal")
        } else {
          gargoyle::trigger("user_msg_modal")
        }

        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## Late upload email ----
    ### Send email if prices have passed their deadlines
    shiny::observeEvent(
      gargoyle::watch("send_deadline_email"),
      {
        log_info("observeEvent:", "send_deadline_email", level = 2)

        dt_report_day <- data.table::copy(r$rv$dt_summary_report_day)

        dt_report_day[,
          OFFSET := as.numeric(gsub(".*\\(([-+]?\\d+)\\).*", "\\1", DUE_TIME, perl = TRUE))
        ]

        dt_report_day[is.na(OFFSET), OFFSET := 0]

        dt_report_day[, DUE_TIME := gsub(".*(\\d{2}:\\d{2}:\\d{2}).*", "\\1", DUE_TIME)]

        dt_report_day[,
          DUE_DATETIME := lubridate::ymd_hms(
            paste(Sys.Date() + OFFSET * lubridate::hours(24), DUE_TIME),
            tz = r$rv$user_timezone
          )
        ]

        time_now <- lubridate::now(tzone = r$rv$user_timezone) - lubridate::seconds(40) # offset by 40 seconds to take time for uploading

        if (r$rv$db_env == "LIVE" & any(time_now > (dt_report_day$DUE_DATETIME))) {
          cols <- c(
            "PUBLICATION_DATE",
            "QUOTE_ID",
            "CODE_DESCRIPTION",
            "VALUE",
            "TIME_STAGED",
            "DUE_DATETIME"
          )

          dt_email <- dt_report_day[DUE_DATETIME < time_now, .SD, .SDcols = cols]

          ## Convert TIME_STAGED to user_timezone from UTC
          dt_email <- dt_email[,
            TIME_STAGED := lubridate::with_tz(
              as.POSIXct(paste(Sys.Date(), TIME_STAGED), tz = "UTC"),
              tzone = r$rv$user_timezone
            )
          ]

          time_now <- format(time_now, "%d %b %Y %H:%M:%S")

          dt_email[, `:=`(
            PUBLICATION_DATE = format(PUBLICATION_DATE, "%d %b %Y"),
            TIME_STAGED = format(TIME_STAGED, "%H:%M:%S"),
            DUE_DATETIME = format(DUE_DATETIME, "%H:%M:%S")
          )]

          argusDT.PriceStudioMain::fct_send_email(
            to = get_config("feedback_email"),
            subject = paste("Warning!", r$subtitle, "uploaded quotes have passed their deadline"),
            html = TRUE,
            body = paste(
              "<p><b style = 'color:orange';>Warning!</b> The following quotes of",
              r$subtitle,
              "were uploaded at<b>",
              time_now,
              r$rv$user_timezone,
              "</b>and have passed their deadline: </p><br><br>",

              tableHTML::tableHTML(obj = dt_email, rownames = FALSE, replace_NA = " - ") %>%
                tableHTML::add_css_table(css = list(c("padding"), c("5px"))) %>%
                tableHTML::add_css_header(
                  css = list("background-color", "lightsteelblue"),
                  headers = 1:ncol(dt_email)
                ) %>%
                tableHTML::add_css_column(
                  css = list("text-align", "center"),
                  columns = names(dt_email)
                ) %>%
                tableHTML::add_css_row(
                  css = list("background-color", "#FFFFFF"),
                  rows = tableHTML::odd(2:nrow(dt_email))
                ) %>%
                tableHTML::add_css_row(
                  css = list("background-color", "#E7E7E7"),
                  rows = tableHTML::even(2:nrow(dt_email))
                )
            )
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Column visibility (once)----
    shiny::observeEvent(
      r$rv$dt_pivot_summary,
      {
        log_info("observeEvent:", "r$rv$dt_pivot_summary", level = 1)

        r$rv$columns_visible_summary <- argusDT.PriceStudioMain::fct_s3_visiblecols_read(
          col_names = c(colnames(r$rv$dt_pivot_summary)),
          filename = id,
          db_env = r$rv$db_env,
          folder = r$s3_dir,
          s3_bucket = get_config("s3_bucket")
        )
      },
      ignoreInit = TRUE,
      once = TRUE,
      priority = 1
    )

    ## Visible columns modal ----
    shiny::observeEvent(
      gargoyle::watch(ns("visible_columns")),
      {
        log_info("observeEvent:", ns("visible_columns"), level = 2)

        shiny::req(r$rv$columns_visible_summary, r$rv$dt_pivot_summary)

        cols_vis <- r$rv$columns_visible_summary
        cols_dt <- c(colnames(r$rv$dt_pivot_summary))
        selected <- names(cols_vis[which(cols_vis == TRUE)])

        shiny::showModal(shiny::modalDialog(
          inputId = ns("visible_columns_modal"),
          title = "Show / Hide Price Summary Columns",
          size = "xl",
          easyClose = TRUE,

          bslib::card(
            max_height = "60vh",
            shinyWidgets::checkboxGroupButtons(
              inputId = ns("columns_checkbox_group"),
              choices = cols_dt,
              selected = selected,
              status = "primary",
              size = "sm",
              direction = "vertical",
              justified = TRUE,
              individual = TRUE,
              checkIcon = list(
                yes = fontawesome::fa("check", fill = "#44AB05"),
                no = fontawesome::fa("xmark", fill = "#DD2303")
              )
            )
          ),

          footer = bslib::layout_columns(
            col_widths = 6,
            max_height = "100%",

            argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("update_columns"),
              label = "Update"
            ),

            shiny::modalButton("Cancel") |> shiny::tagAppendAttributes(class = "btn-default")
          )
        ))
      },
      ignoreInit = TRUE
    )

    ## Update visible columns (S3) ----
    shiny::observeEvent(
      input$`update_columns-actionbutton`,
      {
        log_info("observeEvent:", "input$update_columns-actionbutton", level = 2)

        shiny::removeModal()

        shiny::req(input$columns_checkbox_group, r$rv$dt_pivot_summary)

        r$rv$columns_visible_summary <- argusDT.PriceStudioMain::fct_s3_visiblecols_write(
          col_names = c(colnames(r$rv$dt_pivot_summary)),
          col_selected = input$columns_checkbox_group,
          filename = id,
          db_env = r$rv$db_env,
          folder = r$s3_dir,
          s3_bucket = get_config("s3_bucket")
        )

        gargoyle::trigger("import_prices")
      },
      ignoreInit = TRUE
    )

    ## Review corrections specific to module ----
    r$rv$observeEvent_correction_box <- shiny::observeEvent(
      gargoyle::watch(ns("summary_status-review_corrections")),
      {
        log_info("observeEvent:", ns("summary_status-review_corrections"), level = 2)

        r$rv$dt_correction_review <- data.table::copy(r$rv$dt_pivot_summary)
        gargoyle::trigger("review_corrections")
      },
      ignoreInit = TRUE
    )
  }) # end of mod_summary_server
}
