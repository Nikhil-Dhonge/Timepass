#' mod_asmp_details UI Function
#' @description A shiny Module.
#' @param id A shiny id.
mod_asmp_details_ui <- function(id) {
  ns <- shiny::NS(id)

  shiny::modalDialog(
    title = 'Update Assumption',

    htmltools::tagList(
      bslib::layout_columns(
        col_widths = 12,
        gap = 20,

        bslib::layout_columns(
          col_widths = c(4, 8),

          # ID ----
          bslib::value_box(
            title = "Assumption ID",
            height = "100px",
            shiny::verbatimTextOutput(
              outputId = ns("asmp_id")
            ) |>
              shiny::tagAppendAttributes(class = "assumptions-box")
          ),

          # Details ----
          bslib::value_box(
            title = "Details",
            height = "100px",
            shiny::verbatimTextOutput(
              outputId = ns("asmp_details")
            ) |>
              shiny::tagAppendAttributes(class = "assumptions-box")
          )
        ),

        bslib::layout_columns(
          row_heights = list(1),
          col_widths = c(4, 4, 4),

          # Unit ----
          bslib::value_box(
            title = "Unit",
            height = "100px",
            shiny::verbatimTextOutput(
              outputId = ns("asmp_unit")
            ) |>
              shiny::tagAppendAttributes(class = "assumptions-box")
          ),

          # Current value ----
          bslib::value_box(
            title = "Current Value",
            height = "100px",
            shiny::verbatimTextOutput(
              outputId = ns("asmp_old_value")
            ) |>
              shiny::tagAppendAttributes(class = "assumptions-box")
          ),

          # New value ----
          bslib::value_box(
            title = "New Value",
            height = "100px",
            shiny::textInput(
              inputId = ns("asmp_value"),
              label = NULL,
              value = ""
            ) |>
              shiny::tagAppendAttributes(class = "assumptions-box")
          )
        )
      )
    ),

    footer = bslib::layout_columns(
      col_widths = 6,
      max_height = "100%",
      argusDT.PriceStudioMain::mod_actionbutton_ui(
        id = ns("update_asmp"),
        label = "Submit"
      ),
      shiny::modalButton("Cancel") |> shiny::tagAppendAttributes(class = "btn-default")
    ),
    easyClose = TRUE,
    size = "xl"
  )
}

#' mod_asmp_details Server Functions
#' @param id A shiny id.
#' @param asmp_id assumption id
#' @param details assumption information
#' @param unit assumption units
#' @param old_value previous assumption value
#' @param r The global environment variable 'r'.
#'
mod_asmp_details_server <- function(
  id,
  asmp_id,
  details,
  unit,
  old_value,
  r
) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- shiny::NS(id)

    log_info("show_modal_dialog_server ns:", get_ns(ns), session = session, level = 3)

    # Initialise variables ----
    r$rv$asmp_value <- ""

    # Add widgets ----
    ## ID ----
    output$asmp_id <- shiny::renderText({
      htmltools::HTML(paste0(asmp_id, collapse = "<br>"))
    })

    ## Details ----
    output$asmp_details <- shiny::renderText({
      htmltools::HTML(paste0(details, collapse = "<br>"))
    })

    ## Unit ----
    output$asmp_unit <- shiny::renderText({
      htmltools::HTML(paste0(unit, collapse = "<br>"))
    })

    ## Current value ----
    output$asmp_old_value <- shiny::renderText({
      htmltools::HTML(paste0(old_value, collapse = "<br>"))
    })

    ## Update button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "update_asmp",
      triggers = "update_asmp"
    )

    # Observe Event ----
    ## New value ----
    shiny::observeEvent(input$asmp_value, {
      if (r$rv$asmp_value != input$asmp_value) {
        log_change(
          id = ns("asmp_value"),
          from = r$rv$asmp_value,
          to = input$asmp_value,
          session = session
        )
      }

      r$rv$asmp_value <- input$asmp_value
    })
  })
}
