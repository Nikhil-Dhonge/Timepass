#' Render `argusDS.tabulator` table for Market Survey
#'
#' @description
#' `fct_market_survey_render_tabulator()` renders an `argusDS.tabulator` table
#' with customizable columns configuration parameters for the market survey.
#'
#' @param dt A data.table object to display in tabulator output.
#' @param visible_columns A list of columns to be displayed.
#' @param timezone A character object specifying the timezone.
#' @param comm_reporter A character object specifying the username of the reporter.
#' @param titles A named list specifying custom titles for columns.
#' (e.g. titles$FIELD_NAME <- "New Custom Title")
#' @param dt_price_category A list of options for the price category.
#' @param dt_comm_methods A list of options for the communication method.
#' @param dt_traders A list of options for the trader/company.
#' @param dt_ports A list of options for the port/location.
#' @param dt_unit A list of options for the units.
#' @param dt_delivery_periods A list of options for the delivery period.
#' @param delivery_years A list of options for the delivery year.
#' @param tabulator_id A character object specifying the tabulator id of a table.
#'
#' @returns
#' The rendered `argusDS.tabulator` table.
#'
#' @export
#'
#' @family market survey
#' @family argusDS.tabulator
#'
fct_market_survey_render_tabulator <- function(
  dt,
  visible_columns,
  timezone,
  comm_reporter,
  titles = NULL,
  dt_price_category = NULL,
  dt_comm_methods = NULL,
  dt_traders = NULL,
  dt_ports = NULL,
  dt_unit = NULL,
  dt_delivery_periods = NULL,
  delivery_years = NULL,
  tabulator_id = NULL
) {
  log_info("fct_market_survey_render_tabulator", level = 5)

  # Set color coding ----
  color_green <- "#C6E0B4"
  color_yellow <- list("#FFFFCC", "#E6E6B8") # rgb 255 255 204 rgb 230 230 184
  color_red <- list("#FFC8C8", "#FFB0B0") # rgb 255 200 200 rgb 255 176 176
  color_blue <- list("#C8E6FF", "#B4CFEB") # rgb 200 230 255 rgb 180 207 235
  color_highlight <- "#FFA500"

  # Function for titles ----
  ## - Column is the column name in the data.table.
  ## - default is the default string the column header.
  ##   - if the column is privided in the `titles` named list, then the
  ##     default will be overwritten with that value.
  ##   - if the default isn't provided the data.table column name will be used.
  fct_title <- function(column, default = column) {
    if (column %in% names(titles)) titles[[column]] else default
  }

  # Set columns variables in alphabetical order ----
  ## ADD ----
  col_add_rows <- argusDS.tabulator::colDef(
    title = fct_title("ADD", "+"),
    field = "ADD",
    visible = visible_columns[["ADD"]],
    formatter = htmlwidgets::JS(
      "function(e,cell,  onRendered) {
        return `<i class='fa fa-plus-square'></i>`;
      }"
    ),
    cellClick = argusDT.PriceStudioMain::fct_js_tabulator_cellclick(tabulator_id),
    width = 50
  )

  ## CF ----
  col_cf <- argusDS.tabulator::colDef(
    title = fct_title("CF"),
    field = "CF",
    visible = visible_columns[["CF"]],
    width = 55
  )

  ## CODE_DESCRIPTION ----
  col_code_description <- argusDS.tabulator::colDef(
    title = fct_title("CODE_DESCRIPTION", "Description"),
    field = "CODE_DESCRIPTION",
    visible = visible_columns[["CODE_DESCRIPTION"]]
  )

  ## CODE_ID ----
  col_code_id <- argusDS.tabulator::colDef(
    title = fct_title("CODE_ID", "Code ID"),
    field = "CODE_ID",
    visible = visible_columns[["CODE_ID"]]
  )

  ## COMM_CONTACT_NAME ----
  col_comm_contact_name <- argusDS.tabulator::colDef(
    title = fct_title("COMM_CONTACT_NAME", "Contact Name"),
    field = "COMM_CONTACT_NAME",
    visible = visible_columns[["COMM_CONTACT_NAME"]],
    editable = TRUE,
    editor = "input",
    validator = "string",
    hozAlign = "left",
    minWidth = 100,
    widthGrow = 2
  )

  ## COMM_REPORTER ----
  col_comm_reporter <- argusDS.tabulator::colDef(
    title = fct_title("COMM_REPORTER", "Reporter"),
    field = "COMM_REPORTER",
    visible = visible_columns[["COMM_REPORTER"]],
    editable = TRUE,
    editor = "input",
    editorParams = argusDS.tabulator::editorParams(values = comm_reporter),
    validator = "string",
    hozAlign = "left",
    minWidth = 150,
    widthGrow = 2
  )

  ## COMM_METHOD_ID ----
  col_comm_method <- argusDS.tabulator::colDef(
    title = fct_title("COMM_METHOD_ID", "Method"),
    field = "COMM_METHOD_ID",
    visible = visible_columns[["COMM_METHOD_ID"]],
    editable = TRUE,
    editor = "list",
    editorParams = argusDS.tabulator::editorParams(
      values = as.list(na.omit(setNames(
        dt_comm_methods$COMM_METHOD,
        dt_comm_methods$COMM_METHOD_ID
      ))),
      sort = "asc",
      maxWidth = TRUE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "numeric",
    formatter = "lookup",
    formatterParams = as.list(na.omit(setNames(
      dt_comm_methods$COMM_METHOD,
      dt_comm_methods$COMM_METHOD_ID
    ))),
    minWidth = 100
  )

  ## COMM_TIMESTAMP ----
  col_comm_timestamp <- argusDS.tabulator::colDef(
    title = fct_title("COMM_TIMESTAMP", "Contact Time"),
    field = "COMM_TIMESTAMP",
    visible = visible_columns[["COMM_TIMESTAMP"]],
    editable = TRUE,
    editor = argusDT.PriceStudioMain::fct_js_tabulator_editor_datetime(),
    editorParams = argusDS.tabulator::editorParams(format = "yyyy-MM-dd HH:mm:ss z"),
    formatter = "datetime",
    formatterParams = argusDS.tabulator::formatterParams(
      inputFormat = "yyyy-MM-dd HH:mm:ss z",
      outputFormat = "yyyy-LL-dd HH:mm"
    ),
    minWidth = 150
  )

  ## COMM_TIMESTAMP_UTC ----
  col_comm_timestamp_utc <- argusDS.tabulator::colDef(
    title = fct_title("COMM_TIMESTAMP_UTC", "Contact Time UTC"),
    field = "COMM_TIMESTAMP_UTC",
    visible = visible_columns[["COMM_TIMESTAMP_UTC"]],
    formatter = "datetime",
    formatterParams = argusDS.tabulator::formatterParams(
      inputFormat = "yyyy-MM-dd HH:mm:ss z",
      outputFormat = "yyyy-LL-dd HH:mm z",
      timezone = "UTC"
    ),
    minWidth = 150
  )

  ## DBR_TIMING ----
  col_dbr_timing <- argusDS.tabulator::colDef(
    title = fct_title("DBR_TIMING", "Diff timing"),
    field = "DBR_TIMING_ID",
    visible = visible_columns[["DBR_TIMING"]]
  )

  ## DECIMALPLACES_HIGH ----
  col_dp_high_id <- argusDS.tabulator::colDef(
    title = fct_title("DECIMALPLACES_HIGH", "DP High"),
    field = "DECIMALPLACES_HIGH",
    visible = visible_columns[["DECIMALPLACES_HIGH"]]
  )

  ## DECIMALPLACES_LOW ----
  col_dp_low_id <- argusDS.tabulator::colDef(
    title = fct_title("DECIMALPLACES_LOW", "DP Low"),
    field = "DECIMALPLACES_LOW",
    visible = visible_columns[["DECIMALPLACES_LOW"]]
  )

  ## DECIMALPLACES_MID ----
  col_dp_mid_id <- argusDS.tabulator::colDef(
    title = fct_title("DECIMALPLACES_MID", "DP Mid"),
    field = "DECIMALPLACES_MID",
    visible = visible_columns[["DECIMALPLACES_MID"]]
  )

  ## DELETED ====
  col_deleted <- argusDS.tabulator::colDef(
    title = fct_title("DELETED", "D"),
    field = "DELETED",
    visible = visible_columns[["DELETED"]],
    formatter = "tickCross",
    formatterParams = argusDS.tabulator::formatterParams(
      tickElement = "<i class='fa-solid fa-arrow-rotate-left'></i>",
      crossElement = "<i class='fa-solid fa-trash'></i>"
    ),
    cellClick = htmlwidgets::JS(
      " function(e, cell) {
          var value = cell.getValue();
          cell.setValue(!value);
        }"
    ),
    width = 50
  )

  ## DELIVERY_PERIOD_ID ----
  col_delivery_period <- argusDS.tabulator::colDef(
    title = fct_title("DELIVERY_PERIOD_ID", "Delivery Period"),
    field = "DELIVERY_PERIOD_ID",
    visible = visible_columns[["DELIVERY_PERIOD_ID"]],
    editable = TRUE,
    editor = "list",
    editorParams = argusDS.tabulator::editorParams(
      values = as.list(na.omit(setNames(
        dt_delivery_periods$DELIVERY_PERIOD,
        dt_delivery_periods$DELIVERY_PERIOD_ID
      ))),
      sort = "asc",
      maxWidth = FALSE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "numeric",
    formatter = "lookup",
    formatterParams = as.list(na.omit(setNames(
      dt_delivery_periods$DELIVERY_PERIOD,
      dt_delivery_periods$DELIVERY_PERIOD_ID
    ))),
    minWidth = 100
  )

  ## DELIVERY_YEAR ----
  col_delivery_year <- argusDS.tabulator::colDef(
    title = fct_title("DELIVERY_YEAR", "Delivery Year"),
    field = "DELIVERY_YEAR",
    visible = visible_columns[["DELIVERY_YEAR"]],
    editable = TRUE,
    editor = "list",
    editorParams = list(
      values = delivery_years,
      sort = "asc",
      maxWidth = TRUE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "numeric",
    minWidth = 100
  )

  ## DIFF_BASE ----
  col_diff_base <- argusDS.tabulator::colDef(
    title = fct_title("DIFF_BASE", "Diff to"),
    field = "DIFF_BASE",
    visible = visible_columns[["DIFF_BASE"]],
    hozAlign = "left",
    minWidth = 100
  )

  ## DISPLAY_ORDER ----
  col_display_order <- argusDS.tabulator::colDef(
    title = fct_title("DISPLAY_ORDER", "Table Order"),
    field = "DISPLAY_ORDER",
    visible = visible_columns[["DISPLAY_ORDER"]],
    width = 55
  )

  ## EDIT_MID ----
  col_edit_mid <- argusDS.tabulator::colDef(
    title = fct_title("EDIT_MID"),
    field = "EDIT_MID",
    visible = visible_columns[["EDIT_MID"]],
    width = 55
  )

  ## EDITED ----
  col_edited <- argusDS.tabulator::colDef(
    title = fct_title("EDITED", "Edited"),
    field = "EDITED",
    visible = visible_columns[["EDITED"]]
  )

  ## FREQUENCY ----
  col_frequency <- argusDS.tabulator::colDef(
    title = fct_title("FREQUENCY", "Frequency"),
    field = "FREQUENCY",
    visible = visible_columns[["FREQUENCY"]],
    minWidth = 100
  )

  ## LOW ----
  col_low <- argusDS.tabulator::colDef(
    title = fct_title("LOW", "Low"),
    field = "LOW",
    visible = visible_columns[["LOW"]],
    editable = htmlwidgets::JS(
      argusDT.PriceStudioMain::fct_js_tabulator_editable(
        target_column_edit_mid = "EDIT_MID",
        target_column_edit_mid_bln = "false",
        target_column_type = "TYPE"
      )
    ),
    editor = "input",
    validator = "numeric",
    formatter = fct_js_tblr_mktsvy_format(
      target_column = "LOW",
      target_column_DP = "DECIMALPLACES_LOW",
      format_region = "en-US",
      color_green = color_green[1],
      color_yellow = color_yellow[1],
      color_red = color_red[1],
      color_highlight = color_highlight
    ),
    hozAlign = "right",
    minWidth = 100
  )

  ## HIGH ----
  col_high <- argusDS.tabulator::colDef(
    title = fct_title("HIGH", "High"),
    field = "HIGH",
    visible = visible_columns[["HIGH"]],
    editable = htmlwidgets::JS(
      argusDT.PriceStudioMain::fct_js_tabulator_editable(
        target_column_edit_mid = "EDIT_MID",
        target_column_edit_mid_bln = "false",
        target_column_type = "TYPE"
      )
    ),
    editor = "input",
    validator = "numeric",
    formatter = fct_js_tblr_mktsvy_format(
      target_column = "HIGH",
      target_column_DP = "DECIMALPLACES_HIGH",
      format_region = "en-US",
      color_green = color_green[1],
      color_yellow = color_yellow[1],
      color_red = color_red[1],
      color_highlight = color_highlight
    ),
    hozAlign = "right",
    minWidth = 100
  )

  ## ID ----
  col_id <- argusDS.tabulator::colDef(
    title = fct_title("ID"),
    field = "ID",
    visible = visible_columns[["ID"]],
    width = 50
  )

  ## INCLUDE ----
  col_include <- argusDS.tabulator::colDef(
    title = fct_title("INCLUDE", "Inc"),
    field = "INCLUDE",
    visible = visible_columns[["INCLUDE"]],
    formatter = "tickCross",
    cellClick = htmlwidgets::JS(
      " function(e, cell) {
          var value = cell.getValue();
          cell.setValue(!value);
        }"
    ),
    width = 50
  )

  ## MARKET ----
  col_market <- argusDS.tabulator::colDef(
    title = fct_title("MARKET", "Market"),
    field = "MARKET",
    visible = visible_columns[["MARKET"]],
    minWidth = 120
  )

  ## MARKET_SURVEY_ITEM_ID ----
  col_market_survey_item_id <- argusDS.tabulator::colDef(
    title = fct_title("MARKET_SURVEY_ITEM_ID", "MS Item"),
    field = "MARKET_SURVEY_ITEM_ID",
    visible = visible_columns[["MARKET_SURVEY_ITEM_ID"]],
    width = 50
  )

  ## MID ----
  col_mid <- argusDS.tabulator::colDef(
    title = fct_title("MID", "Mid"),
    field = "MID",
    visible = visible_columns[["MID"]],
    editable = TRUE,
    editor = "input",
    validator = "numeric",
    formatter = fct_js_tblr_mktsvy_format(
      target_column = "MID",
      target_column_DP = "DECIMALPLACES_MID",
      format_region = "en-US",
      color_green = color_green[1],
      color_yellow = color_yellow[1],
      color_red = color_red[1],
      color_highlight = color_highlight
    ),
    hozAlign = "right",
    minWidth = 100
  )

  ## NOTES ----
  col_notes <- argusDS.tabulator::colDef(
    title = fct_title("NOTES", "Note"),
    field = "NOTES",
    visible = visible_columns[["NOTES"]],
    hozAlign = "left",
    editor = "textarea",
    editable = TRUE,
    formatter = htmlwidgets::JS(
      argusDT.PriceStudioMain::fct_js_tabulator_formatter_notes(
        target_column = "NOTES",
        color_empty = color_yellow[1],
        color_filled = color_green[1]
      )
    ),
    minWidth = 400,
    widthGrow = 3
  )

  ## PA_CODE ----
  col_pacode <- argusDS.tabulator::colDef(
    title = fct_title("PA_CODE", "PA Code"),
    field = "PA_CODE",
    visible = visible_columns[["PA_CODE"]]
  )

  ## PORT_ID ----
  col_port <- argusDS.tabulator::colDef(
    title = fct_title("PORT_ID", "Location"),
    field = "PORT_ID",
    visible = visible_columns[["PORT_ID"]],
    editable = TRUE,
    editor = "list",
    editorParams = argusDS.tabulator::editorParams(
      values = as.list(na.omit(setNames(dt_ports$PORT, dt_ports$PORT_ID))),
      sort = "asc",
      maxWidth = FALSE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "numeric",
    formatter = "lookup",
    formatterParams = as.list(na.omit(setNames(dt_ports$PORT, dt_ports$PORT_ID))),
    minWidth = 100,
    widthGrow = 2
  )

  ## PRICE_CATEGORY_ID ----
  col_price_category <- argusDS.tabulator::colDef(
    title = fct_title("PRICE_CATEGORY_ID", "Price Category"),
    field = "PRICE_CATEGORY_ID",
    visible = visible_columns[["PRICE_CATEGORY_ID"]],
    editable = TRUE,
    editor = "list",
    editorParams = argusDS.tabulator::editorParams(
      values = as.list(na.omit(setNames(
        dt_price_category$PRICE_CATEGORY,
        dt_price_category$PRICE_CATEGORY_ID
      ))),
      sort = "asc",
      maxWidth = FALSE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "numeric",
    formatter = "lookup",
    formatterParams = as.list(na.omit(setNames(
      dt_price_category$PRICE_CATEGORY,
      dt_price_category$PRICE_CATEGORY_ID
    ))),
    minWidth = 100
  )

  ## PT_HIGH ----
  col_pt_high <- argusDS.tabulator::colDef(
    title = fct_title("PT_HIGH", "High PT"),
    field = "PT_HIGH",
    visible = visible_columns[["PT_HIGH"]],
    width = 55
  )

  ## PT_LOW ----
  col_pt_low <- argusDS.tabulator::colDef(
    title = fct_title("PT_LOW", "Low PT"),
    field = "PT_LOW",
    visible = visible_columns[["PT_LOW"]],
    width = 55
  )

  ## PT_MID ----
  col_pt_mid <- argusDS.tabulator::colDef(
    title = fct_title("PT_MID", "Mid PT"),
    field = "PT_MID",
    visible = visible_columns[["PT_MID"]],
    width = 55
  )

  ## PUBLICATION_DATE ----
  col_publication_date <- argusDS.tabulator::colDef(
    title = fct_title("PUBLICATION_DATE", "Date"),
    field = "PUBLICATION_DATE",
    visible = visible_columns[["PUBLICATION_DATE"]],
    formatter = "datetime",
    formatterParams = argusDS.tabulator::formatterParams(
      inputFormat = "iso",
      outputFormat = "dd LLL yyyy"
    ),
    width = 120
  )

  ## PUBLISH ----
  col_publish <- argusDS.tabulator::colDef(
    title = fct_title("PUBLISH", "Publish"),
    field = "PUBLISH",
    visible = visible_columns[["PUBLISH"]],
    width = 65
  )

  ## QPT_MID ----
  col_qpt_mid <- argusDS.tabulator::colDef(
    title = fct_title("QPT_MID", "QPT Mid"),
    field = "QPT_MID",
    visible = visible_columns[["QPT_MID"]]
  )

  ## QUOTE_ID ----
  col_quote_id <- argusDS.tabulator::colDef(
    title = fct_title("QUOTE_ID", "Quote ID"),
    field = "QUOTE_ID",
    visible = visible_columns[["QUOTE_ID"]]
  )

  ## SECTION ----
  col_section <- argusDS.tabulator::colDef(
    title = fct_title("SECTION", "Section"),
    field = "SECTION",
    visible = visible_columns[["SECTION"]],
    minWidth = 100
  )

  ## SECTION_DISPLAY_ORDER ----
  col_section_display_order <- argusDS.tabulator::colDef(
    title = fct_title("SECTION_DISPLAY_ORDER", "Tab Order"),
    field = "SECTION_DISPLAY_ORDER",
    visible = visible_columns[["SECTION_DISPLAY_ORDER"]],
    width = 55
  )

  ## SOURCE ----
  col_source <- argusDS.tabulator::colDef(
    title = fct_title("SOURCE", "Source"),
    field = "SOURCE",
    visible = visible_columns[["SOURCE"]]
  )

  ## TIMING ----
  col_timing <- argusDS.tabulator::colDef(
    title = fct_title("TIMING", "Timing"),
    field = "TIMING",
    visible = visible_columns[["TIMING"]],
    minWidth = 100
  )

  ## TRADER_ID ----
  col_trader <- argusDS.tabulator::colDef(
    title = fct_title("TRADER_ID", "Company"),
    field = "TRADER_ID",
    visible = visible_columns[["TRADER_ID"]],
    editable = TRUE,
    editor = "list",
    editorParams = argusDS.tabulator::editorParams(
      values = as.list(na.omit(setNames(dt_traders$TRADER, dt_traders$TRADER_ID))),
      sort = "asc",
      maxWidth = FALSE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "numeric",
    formatter = "lookup",
    formatterParams = as.list(na.omit(setNames(dt_traders$TRADER, dt_traders$TRADER_ID))),
    minWidth = 100,
    widthGrow = 2
  )

  ## TS ----
  col_ts <- argusDS.tabulator::colDef(
    title = fct_title("TS"),
    field = "TS",
    visible = visible_columns[["TS"]],
    width = 55
  )

  ## TYPE ----
  col_type <- argusDS.tabulator::colDef(
    title = fct_title("TYPE", "Type"),
    field = "TYPE",
    visible = visible_columns[["TYPE"]]
  )

  ## UNIT_ID1 ----
  dt_unit_1 <- unique(dt_unit[, .(UNIT_ID1, DESCRIPTION1)])

  col_unit1 <- argusDS.tabulator::colDef(
    title = fct_title("UNIT_ID1", "Currency unit"),
    field = "UNIT_ID1",
    visible = visible_columns[["UNIT_ID1"]],
    editable = TRUE,
    editor = "list",
    editorParams = argusDS.tabulator::editorParams(
      values = as.list(na.omit(setNames(dt_unit_1$DESCRIPTION1, dt_unit_1$UNIT_ID1))),
      sort = "asc",
      maxWidth = TRUE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "integer",
    formatter = "lookup",
    formatterParams = as.list(na.omit(setNames(dt_unit_1$DESCRIPTION1, dt_unit_1$UNIT_ID1))),
    minWidth = 100
  )

  ## UNIT_ID2 ----
  dt_unit_2 <- unique(dt_unit[, .(UNIT_ID2, DESCRIPTION2)])

  col_unit2 <- argusDS.tabulator::colDef(
    title = fct_title("UNIT_ID2", "Measure unit"),
    field = "UNIT_ID2",
    visible = visible_columns[["UNIT_ID2"]],
    editable = TRUE,
    editor = "list",
    editorParams = argusDS.tabulator::editorParams(
      values = as.list(na.omit(setNames(dt_unit_2$DESCRIPTION2, dt_unit_2$UNIT_ID2))),
      sort = "asc",
      maxWidth = TRUE,
      autocomplete = TRUE,
      allowEmpty = TRUE,
      listOnEmpty = TRUE,
      placeholderLoading = "Loading List..."
    ),
    validator = "integer",
    formatter = "lookup",
    formatterParams = as.list(na.omit(setNames(dt_unit_2$DESCRIPTION2, dt_unit_2$UNIT_ID2))),
    minWidth = 100
  )

  ## OUT_DIFF_TYPE ----
  col_out_diff_type <- argusDS.tabulator::colDef(
    title = fct_title("OUT_DIFF_TYPE", "Price Type"),
    field = "OUT_DIFF_TYPE",
    visible = visible_columns[["OUT_DIFF_TYPE"]],
    minWidth = 100
  )

  # Default Column ----
  col_default <- argusDS.tabulator::colDef(
    title = "",
    visible = FALSE,
    headerFilter = FALSE,
    headerHozAlign = "center",
    headerSort = FALSE,
    hozAlign = "center",
    vertAlign = "center",
    minWidth = 50,
    widthGrow = 1
  )

  # Render table ----
  argusDS.tabulator::tabulator(
    data = dt,
    layout = "fitColumns",
    autoColumns = FALSE,
    index = "ID",
    history = TRUE,
    height = "100%",
    maxHeight = "100%",
    renderVertical = "basic",
    columnDefaults = col_default,
    placeholder = "Loading...",
    rowFormatter = fct_js_tblr_mktsvy_rowformat(
      columns = list("DELETED", "SOURCE", "SOURCE"),
      values = list(TRUE, "INPUT", "NEW"),
      colors = list(color_red, color_yellow, color_blue)
    ),
    columns = list(
      ## Code ----
      col_id,
      col_market_survey_item_id,
      col_qpt_mid,
      col_quote_id,
      col_code_id,
      col_ts,
      col_cf,
      col_pt_low,
      col_pt_high,
      col_pt_mid,
      col_pacode,
      col_code_description,
      col_type,
      col_out_diff_type,
      col_edit_mid,
      col_frequency,
      col_market,
      col_display_order,
      col_section,
      col_section_display_order,
      ## Forward ----
      col_timing,
      ## Differential ----
      col_diff_base,
      col_dbr_timing,
      ## Price ----
      col_dp_low_id,
      col_dp_high_id,
      col_dp_mid_id,
      col_publication_date,
      col_price_category,
      col_comm_reporter,
      col_comm_method,
      col_comm_contact_name,
      col_comm_timestamp,
      col_comm_timestamp_utc,
      col_trader,
      col_port,
      col_delivery_period,
      col_delivery_year,
      col_low,
      col_high,
      col_mid,
      col_unit1,
      col_unit2,
      col_notes,
      col_include,
      col_add_rows,
      col_deleted,
      ## Status ----
      col_edited,
      col_source,
      col_publish
    )
  )
}
