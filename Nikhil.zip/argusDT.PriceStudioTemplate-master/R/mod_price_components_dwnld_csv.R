#' mod_price_components_dwnld_csv UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @inheritParams shiny::downloadButton
#' @inheritParams bslib::tooltip
#' @param disabled_msg Tooltip when widget is disabled. Widget isn't disabled
#' if NULL
#' @param width The width of the input, e.g. '400px', or '100%'; see
#' [validateCssUnit()](shiny::validateCssUnit()).
#' @param tooltip_placement The placement of the tooltip relative to its trigger.
#' @param tooltip_dark logical TRUE to show a dark background tooltip
mod_price_components_dwnld_csv_ui <- function(
  id,
  label = "Download",
  width = "100%",
  icon = shiny::icon("download"),
  disabled_msg = NULL,
  tooltip_placement = c("auto", "top", "right", "bottom", "left"),
  tooltip_dark = TRUE,
  ...
) {
  ns <- shiny::NS(id)

  tooltip_placement <- match.arg(tooltip_placement)

  log_info("mod_price_components_dwnld_csv_ui ns:", get_ns(ns), level = 3)

  outputId <- ns("download_csv")
  tooltipId <- ns("download_csv-tooltip")

  log_info("download_csv ID:", outputId, level = 4)

  widget <- shiny::downloadButton(
    outputId = outputId,
    label = label,
    icon = icon
  )

  shiny::tagList(
    bslib::tooltip(
      disabled_msg,
      placement = tooltip_placement,
      options = list(
        customClass = ifelse(tooltip_dark, "tooltip-dark", ""),
        trigger = ifelse(is.null(disabled_msg), "manual", "hover focus")
      ),
      trigger = shiny::tags$div(
        id = tooltipId,
        style = htmltools::css(width = shiny::validateCssUnit(width)),
        class = "btn-default-container",

        if (is.null(disabled_msg)) {
          widget
        } else {
          shinyjs::disabled(widget)
        }
      )
    )
  )
}

#' mod_price_components_dwnld_csv_server Server Functions
#' @param id,r Internal parameters for {shiny}.
#' @param dt_list List of data.tables to be downloaded as CSVs.
#' @param filename the filename or folder name for the download.
#' @param enable_trigger Character name of trigger used to enable
#' the widget. Ignored if NULL.
#' @param disable_trigger Character name of trigger used to disable
#' the widget. Ignored if NULL.
mod_price_components_dwnld_csv_server <- function(
  id,
  r,
  dt_list,
  filename,
  enable_trigger = NULL,
  disable_trigger = NULL
) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    outputId <- ns("download_csv")
    tooltipId <- ns("download_csv-tooltip")

    log_info("mod_price_components_dwnld_csv_server ns:", get_ns(ns), level = 3)
    log_info("download_csv ID:", outputId, level = 4)

    ## Download file locally
    output$download_csv <- shiny::downloadHandler(
      filename = function() {
        if (data.table::is.data.table(dt_list) || (is.list(dt_list) && length(dt_list) == 1)) {
          paste0(filename, ".csv")
        } else {
          paste0(filename, ".zip")
        }
      },
      content = function(file) {
        if (data.table::is.data.table(dt_list)) {
          # Single table
          data.table::fwrite(dt_list, file = file, eol = "\r\n", quote = FALSE)
        } else if (is.list(dt_list) && length(dt_list) == 1) {
          # Single table inside a list
          tbl <- dt_list[[1]]
          data.table::fwrite(tbl, file = file, eol = "\r\n", quote = FALSE)
        } else if (is.list(dt_list) && length(dt_list) > 1) {
          # Multiple tables — ZIP
          dt_named_list <- dt_list

          ## Create a temporary directory to save dt_list object(s) temporarily for the session
          temp_directory <- file.path(tempdir(), as.integer(Sys.time()))
          dir.create(temp_directory)

          csv_paths <- mapply(
            function(tbl, name) {
              file_name <- paste0(gsub("-", "", as.character(r$rv$report_date)), "_", name, ".csv")
              path <- file.path(temp_directory, file_name)
              data.table::fwrite(tbl, file = path, eol = "\r\n", quote = FALSE)
              return(path)
            },
            tbl = dt_named_list,
            name = names(dt_named_list),
            SIMPLIFY = TRUE,
            USE.NAMES = FALSE
          )

          zip::zip(zipfile = file, files = csv_paths, mode = "cherry-pick")
        }
      }
    )

    # Enable button ----
    ## If `enable_trigger` provided then use observe event to enable else
    ## enable on loading
    if (!is.null(enable_trigger)) {
      shiny::observeEvent(
        gargoyle::watch(enable_trigger),
        {
          log_info("observeEvent:", outputId, "enable", level = 1)

          shinyjs::enable(id = outputId, asis = TRUE)
          shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
            id = tooltipId,
            action = "disable"
          ))
        },
        ignoreInit = TRUE
      )
    } else {
      shinyjs::enable(id = outputId, asis = TRUE)
      shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
        id = tooltipId,
        action = "disable"
      ))
    }

    # Disable button ----
    if (!is.null(disable_trigger)) {
      shiny::observeEvent(
        gargoyle::watch(disable_trigger),
        {
          log_info("observeEvent:", outputId, "disable", level = 1)

          shinyjs::disable(id = outputId, asis = TRUE)
          shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
            id = tooltipId,
            action = "enable"
          ))
        },
        ignoreInit = TRUE
      )
    }
  })
}
