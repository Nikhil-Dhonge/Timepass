#' get_create_vars
#' @description Initialise the reactive and non reactive variable contained in
#' the r global variable.
#' @return r, the global variable.
#' @noRd
fct_create_env_vars <- function(session) {
  log_info("fct_create_env_vars", level = 1)

  r <- environment()
  r$rv <- shiny::reactiveValues()

  ## Golem options ----
  golem_options <- argusDT.PriceStudioMain::fct_get_golem_options()

  ## Golem options (non reactive) ----
  r$title <- golem_options$title
  r$local <- golem_options$local
  r$subtitle <- golem_options$subtitle
  r$csv_filename <- golem_options$csv_filename
  r$s3_dir <- golem_options$s3_dir
  r$hist_days <- golem_options$hist_days
  r$deals_days <- golem_options$deals_days
  r$data_points <- golem_options$data_points
  r$app_start_date <- golem_options$app_start_date
  r$app_end_date <- golem_options$app_end_date
  r$linkfile_filename <- golem_options$linkfile_filename
  r$charts_folders <- golem_options$charts_folders
  r$censhare_tag <- golem_options$censhare_tag
  r$commodity_ids <- golem_options$commodity_ids
  r$frequency <- golem_options$frequency
  r$publish_day <- golem_options$publish_day
  r$s3_bucket <- get_config("s3_bucket")

  ## Golem options (reactive) ----
  r$rv$deal_module_ids <- golem_options$deal_module_ids
  r$rv$db_env <- golem_options$db_env
  r$rv$ora_connection <- golem_options$ora_connection
  r$rv$mysql_connection <- golem_options$mysql_connection
  r$rv$holiday_region <- golem_options$holiday_region
  r$rv$exrate_time <- golem_options$exrate_time
  r$rv$forex_timestamps <- get_config("forex_timestamps")
  r$rv$fwd_list_start <- golem_options$fwd_list_start
  r$rv$fwd_list_count <- golem_options$fwd_list_count
  r$rv$dbr_list_start <- golem_options$dbr_list_start
  r$rv$dbr_list_count <- golem_options$dbr_list_count
  r$rv$regions <- golem_options$regions
  r$rv$region <- golem_options$region

  r$rv$forex_day_offsets <- get_config("forex_day_offsets")
  r$rv$exrate_day_offset <- golem_options$exrate_day_offset
  r$rv$exrate_unit_ids <- golem_options$exrate_unit_ids

  ## Scheduled Scripts Trigger ----

  ### Script names and GUIDs ----
  r$dt_script_guids <- golem_options$dt_script_guids
  r$dt_script_map <- golem_options$dt_script_map

  if (!is.null(r$dt_script_map)) {
    script_names <- r$dt_script_map$SCRIPT_NAME
    script_names <- script_names[(script_names %in% golem_options$dt_script_guids$`app-name`)]
    r$rv$script_names <- script_names
    dt_script_names <- data.table(`app-name` = script_names)
    guids <- r$dt_script_guids[dt_script_names, on = "app-name", nomatch = 0]$guid
    r$rv$script_guids <- guids

    if (length(guids) == 0) {
      log_warn("No GUIDs found in mapping JSON file for this app_id.")
    }

    ### Get reference to shared script locks environment ----
    r$script_locks <- getOption("script.locks")

    ### Get the controller created at process startup ----
    controller <- getOption("crew.controller")
    r$controller <- controller

    ### ExtendedTasks creation ----
    for (i in 1:length(script_names)) {
      task_name_i <- paste0("run_script_task_", script_names[i])
      assign(
        x = task_name_i,
        value = shiny::ExtendedTask$new(function(...) {
          mir <- controller$push(
            command = fct_run_sched_script(
              db_env,
              selected_script_name,
              selected_script_guid,
              user_id
            ),
            data = list(...),
            globals = list(
              fct_run_sched_script = fct_run_sched_script,
              fct_cleanup_script_lock = fct_cleanup_script_lock
            )
          )
          promises::then(
            promises::as.promise(mir),
            onFulfilled = function(m) {
              m$result[[1]]
            },
            onRejected = function(e) {
              stop(e)
            }
          )
        })
      )
      r[[task_name_i]] <- get(task_name_i)
    }

    log_info(
      "ExtendedTask created: ",
      names(r)[grep(x = names(r), pattern = "run_script_task")],
      level = 3
    )
  }

  ## Define standards for the selected region ----
  r$rv$exrate_day_offset_region <- golem_options$exrate_day_offset
  r$rv$exrate_time_region <- golem_options$exrate_time

  r$rv$selected_nav_panel <- NULL

  ## Turn on test mode if ENV is either DEV or UAT
  test_mode <- !(golem_options$db_env %in% c("LIVE"))
  r$rv$test_mode <- test_mode

  ## BBS2 Deals ----
  bbs_id <- c(3, 25)
  r$rv$bbs_id <- bbs_id
  r$rv$dt_deals_empty <- data.table::data.table(
    BOARD_ID = bbs_id,
    BOARD_NAME = c(
      "Argus European Gasoline Bulletin Board",
      "Argus European Gasoline non-oxy Bulletin Board"
    ),
    VWA = c(NA_real_, NA_real_),
    Volume = c(NA_real_, NA_real_)
  )

  ## Auto calc ----
  r$rv$auto_calc <- TRUE

  ## Switches ----
  r$rv$notes_switch <- FALSE
  r$rv$override_switch <- FALSE
  r$rv$use_draft_switch <- FALSE
  r$rv$browser_active_switch <- FALSE
  r$rv$summary_ui_switch <- FALSE
  r$rv$total_count_switch <- FALSE
  r$rv$upload_seasons_switch <- FALSE

  ## Checkboxes ----
  r$rv$final_status <- FALSE

  ## Ex-rates ----
  r$rv$exrate_timing_id <- 0

  ## Dates ----
  r$rv$user_timezone <- NULL
  r$rv$report_date <- NULL
  r$rv$prior_date <- NULL
  r$rv$all_dates <- NULL
  r$rv$from_date <- NULL
  r$rv$calendar <- NULL
  r$rv$exrate_date <- NULL

  r$rv$xr_dte_stg_curr_m <- NA_character_
  r$rv$xr_time_stg_curr_m <- NA_character_

  r$rv$xr_dte_stg_other_m <- NA_character_
  r$rv$xr_time_stg_other_m <- NA_character_

  ## Tables ----
  r$rv$dt_errors <- NULL
  r$rv$dt_deals <- NULL
  r$rv$dt_bbs_deals <- NULL
  r$rv$dt_bbs_vwa <- NULL
  r$rv$dt_asmp <- NULL
  r$rv$dt_exrates <- NULL
  r$rv$dt_codemaster <- NULL
  r$rv$dt_futures_calendar <- data.table::as.data.table(NULL)
  r$rv$dt_pivot_summary <- NULL
  r$rv$dt_pivot_summary_all <- NULL
  r$rv$dt_summary <- NULL
  r$rv$dt_summary_report_day <- NULL
  r$rv$dt_summary_total <- NULL
  r$rv$filters <- data.table::data.table(field = character(0), value = character(0))
  r$rv$dt_datawell_api <- NULL
  r$rv$dt_datawell_filtered <- NULL
  r$rv$dt_datawell_full <- NULL
  r$rv$dt_indesign <- NULL
  r$rv$dt_prc_asmp <- NULL
  r$rv$dt_edit_latest <- data.table::as.data.table(NULL)
  r$rv$region_dt_prc_asmp <- NULL
  r$rv$dt_prices_all <- NULL
  r$rv$dt_prices_input <- NULL
  r$rv$dt_prices_live <- NULL
  r$rv$dt_prices_live_all_regions <- NULL
  r$rv$dt_prices_stg_all_regions <- NULL
  r$rv$dt_prices_stg <- NULL
  r$rv$dt_prices_pivot <- NULL
  r$rv$dt_imported <- data.table::as.data.table(NULL)
  r$rv$dt_user_upd <- data.table::as.data.table(NULL)
  r$rv$quote_id <- NULL
  r$rv$region_quote_id <- NULL
  r$rv$dt_market_content <- NULL
  r$rv$markets <- NULL
  r$rv$market <- NULL
  r$rv$summary_markets <- NULL
  r$rv$summary_market <- NULL
  r$rv$random_data <- NULL
  r$rv$dt_correction_review <- NULL
  r$rv$dt_summary_total_filtered <- NULL

  r$rv$spk_filler_color <- "#8EB4E3" # light blue
  r$rv$spk_stroke_color <- "#333333" # dark grey

  ## Assumptions Tab variables
  r$rv$asmp_id_selected <- NULL
  r$rv$asmp_details_selected <- NULL
  r$rv$asmp_unit_selected <- NULL
  r$rv$asmp_old_value <- NULL
  r$rv$asmp_added_on <- NULL

  ## Holiday regions ----
  r$rv$dt_holidays <- NULL
  r$rv$holiday_regions <- NULL
  r$rv$holiday_combinations <- NULL

  ## API feedback and arguments ----
  r$rv$api_feedback <- NULL
  r$rv$skip_fp_validation <- FALSE

  ## CSV path ----
  r$rv$csv_filename <- NULL
  r$rv$s3_csv_dir <- NULL
  r$rv$s3_source_dir <- NULL
  r$rv$s3_documents_dir <- NULL
  r$rv$s3_price_components_base_dir <- NULL
  r$rv$s3_price_components_dir <- NULL

  ## File input
  r$rv$fileinput <- NULL

  ## LinkFile path ----
  r$rv$s3_linkfile_raw_dir <- file.path(
    golem_options$s3_dir,
    tolower(golem_options$db_env),
    "censhare"
  )

  r$rv$s3_linkfile_dir <- NULL

  ## Input tables ----
  r$rv$prices_curr_sections <- NULL
  r$rv$prices_curr_tabulator_ids <- NULL
  r$rv$iteration <- 0

  ## Input tbl obs. events ----
  r$rv$observeEvent <- list()

  ## Help and feedback ----
  r$rv$help_guide <- FALSE
  r$rv$feedback_form <- FALSE

  ## Summary ----
  r$rv$show_columns_picker <- NULL
  r$rv$hide_columns_picker <- NULL

  ## InDesign ----

  ## List of data.tables for all IND_ range names in raw link file
  r$rv$ind_tables_raw <- NULL
  ## List of data.tables for all IND_ range names after calculating cell values
  r$rv$ind_tables_calc <- NULL
  ## A data.table listing the names, sheet & location of all IND_ range from
  ## raw link file
  r$rv$dt_ind_ranges <- NULL
  ## List of table range names selected in InDesign
  r$rv$selected_tables <- NULL
  ## List of table range names displayed in InDesign
  r$rv$displayed_tables <- NULL
  ## Database source for tables
  r$rv$indesign_source <- c("Live", "Saved")[1]

  ## Price Components ---
  r$rv$price_components_prevtabs <- NULL
  r$rv$price_components_tabs <- NULL
  r$rv$price_components_dt <- NULL
  r$rv$price_components_market <- NULL
  r$rv$price_components_markets <- NULL
  r$rv$price_components_dt_filenames <- NULL

  ## Waiters ----
  r$rv$w <- waiter::Waiter$new(
    id = c(
      "input_prices-status-box",
      "input_prices-insert_prices-row",
      "input_prices-tabulator_prices-div",
      "input_prices-tabulator_deals-div",
      "input_prices-tabulator_forex-div",
      "input_prices-market_survey-row",
      "input_prices-prices_tab-tabulator_prices-div",
      "input_prices-deals_tab-tabulator_deals-div",
      "input_prices-asmp_tab-tabulator_asmp-div",
      "input_prices-forex_tab-tabulator_forex-div",
      "summary-status-box",
      "summary-tabulator_box",
      "indesign-status-box",
      "indesign-tables-row",
      "market_survey-Input_Yearly-nav_panel-div",
      "price_components-status-box"
    ),
    html = utils_waiter(),
    color = "#333333"
  )

  return(r)
}
