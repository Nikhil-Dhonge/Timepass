#' input_market UI Function
#' @description A shiny Module.
#' @param id,input,output,session Internal parameters for {shiny}.
#' @noRd

mod_inputprices_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_inputprices_ui ns:", get_ns(ns), level = 2)

  htmltools::tagList(
    htmltools::tags$head(
      htmltools::tags$script(
        argusDT.PriceStudioMain::fct_js_msg_closing_app()
      )
    ),

    htmltools::tags$div(
      class = "main-nav",

      bslib::layout_columns(
        col_widths = 12,
        row_heights = list("auto", 1),

        bslib::layout_columns(
          col_widths = c(9, 3),

          # Control box ----
          bslib::layout_columns(
            class = "main-box",
            col_widths = 6,

            ## Dropdown & Switches ----
            bslib::layout_columns(
              col_widths = c(12, 3, 3, 3, 3),

              ### Market picker ----
              argusDT.PriceStudioMain::mod_pickerinput_ui(
                id = ns("market"),
                choices = "",
                disabled_msg = if (length(golem::get_golem_options("regions")) > 1) {
                  "Select a region first..."
                } else {
                  NULL
                },
                options = list(title = "Select market...")
              ),

              ### Auto calculate switch ----
              argusDT.PriceStudioMain::mod_switchinput_ui(
                id = ns("auto_calc"),
                label = "Auto-calc",
                disabled_msg = "Select a region / market first...",
                value = TRUE
              ),

              ### Notes switch ----
              argusDT.PriceStudioMain::mod_switchinput_ui(
                id = ns("notes_switch"),
                label = "Notes",
                disabled_msg = "Select a region / market first...",
                value = FALSE
              ),

              ### Override switch ----
              argusDT.PriceStudioMain::mod_switchinput_ui(
                id = ns("override_switch"),
                label = "Overrides",
                disabled_msg = "Select a region / market first...",
                value = FALSE
              ),

              ### Draft switch ----
              argusDT.PriceStudioMain::mod_switchinput_ui(
                id = ns("use_draft_switch"),
                label = "Use Draft",
                disabled_msg = "Select a region / market first...",
                value = FALSE
              )
            ),

            ## Buttons ----
            bslib::layout_columns(
              col_widths = c(6, 4, 2, 6, 6),

              ### Refresh Data ----
              argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("import_prices"),
                label = "Refresh Data",
                disabled_msg = "Select a region / market first...",
                icon = shiny::icon("refresh", lib = "glyphicon")
              ),

              ### Stage Prices ----
              argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("stage_prices"),
                label = "Save Prices",
                disabled_msg = "Select a region / market first...",
                icon = shiny::icon("floppy-save", lib = "glyphicon")
              ),

              ### Update final status ----
              argusDT.PriceStudioMain::mod_checkbox_ui(
                id = ns("final_status"),
                label = "All final",
                disabled_msg = "Select a region / market first...",
                value = FALSE
              ),

              ### Copy prices ----
              argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("copy_prices"),
                label = "Copy Prior Prices",
                disabled_msg = "Select a region / market first...",
                icon = shiny::icon("copy", lib = "glyphicon")
              ),

              ### View Staged Prices ----
              argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("view_staged_prices"),
                label = "View Saved Inputs",
                disabled_msg = "Select a region / market first...",
                icon = shiny::icon("list", lib = "glyphicon")
              )
            )
          ),

          # Progress bar box ----
          bslib::layout_columns(
            class = "main-box",
            col_widths = 12,
            id = ns("status-box"),
            mod_prices_status_ui(id = ns("input_status"))
          )
        ),

        # Body tabs ----
        bslib::navset_tab(
          id = ns("tabs"),

          ## Input tab ----
          bslib::nav_panel(
            title = "Price Input",

            bslib::layout_columns(
              class = "main-box",
              col_widths = 12,
              id = ns("insert_prices-row"),
              min_height = "65vh",
              htmltools::tags$div(
                id = ns("box_insert_prices")
              )
            )
          ),

          ## Imported Prices tab ----
          bslib::nav_panel(
            title = "Imported Prices",
            mod_prices_tab_ui(id = ns("prices_tab"))
          ),

          ## Deals tab ----
          bslib::nav_panel(
            title = "Deals",
            mod_deals_tab_ui(id = ns("deals_tab"))
          ),

          ## Forex tab ----
          bslib::nav_panel(
            title = "Forex",
            mod_forex_tab_ui(id = ns("forex_tab"))
          ),

          # Assumption tab ----
          bslib::nav_panel(
            title = "Assumptions",
            mod_asmp_tab_ui(id = ns("asmp_tab"))
          )
        )
      )
    )
  )
}


#' input_market Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_inputprices_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_inputprices_server:", get_ns(ns), level = 2)

    # Initialise triggers ----
    gargoyle::init(ns("visible_columns"))
    gargoyle::init(ns("input_status-review_corrections"))

    # Modules ----
    ## Deals tab ----
    mod_deals_tab_server(id = "deals_tab", r)

    ## Imported tab ----
    mod_prices_tab_server(id = "prices_tab", r)

    ## Forex tab ----
    mod_forex_tab_server(id = "forex_tab", r)

    ## Assumption tab ----
    mod_asmp_tab_server(id = "asmp_tab", r)

    ## Staged prices ----
    mod_stage_prices_server(id = "stage_data", r)

    ## Price status and correction box ----
    mod_prices_status_server(id = "input_status", r, is_summary = FALSE)

    # Widget modules ----
    ## Checkboxes ----
    ### Final checkbox ----
    argusDT.PriceStudioMain::mod_checkbox_server(
      id = "final_status",
      rv = r$rv,
      triggers = c(
        "show_waiter",
        "update_final_flag",
        "combine_price_data",
        "calculate_prices",
        "check_prices",
        "pivot_prices",
        "update_price_input",
        "update_statuses"
      ),
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ## Switches ----
    ### Auto-calc switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "auto_calc",
      rv = r$rv,
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Draft switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "use_draft_switch",
      rv = r$rv,
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Notes switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "notes_switch",
      rv = r$rv,
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Override switch ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "override_switch",
      rv = r$rv,
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ## Pickers ----
    ### Market picker input ----
    argusDT.PriceStudioMain::mod_pickerinput_server(
      id = "market",
      rv = r$rv,
      choices_rv = "markets",
      enable_trigger = "enable_market",
      disable_trigger = "disable_market"
    )

    ## Buttons ----
    ### Stage prices button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "stage_prices",
      triggers = "stage_prices_start",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Get prices button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "import_prices",
      triggers = "import_prices",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### Copy prices button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "copy_prices",
      triggers = "copy_prices",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    ### View staged inputs button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "view_staged_prices",
      triggers = "view_staged_prices",
      enable_trigger = "import_prices",
      disable_trigger = "disable_buttons"
    )

    # Observe Events ----
    ## Region change ----
    ## When region picker input is updated, update market list and reset some
    ## global variables
    shiny::observeEvent(
      r$rv$region,
      {
        log_info("observeEvent:", "r$rv$region", level = 2)

        r$rv$markets <- sort(unique(
          r$rv$dt_market_content[DISPLAY_YN == "Y" & REGION == r$rv$region]$MARKET
        ))

        ### Set Summary markets to the entire list of markets
        r$rv$summary_markets <- r$rv$markets
        r$rv$summary_market <- r$rv$markets

        r$rv$exrate_day_offset_region <- unique(
          r$rv$dt_market_content[REGION == r$rv$region]$EXRATE_DAY_OFFSET
        )
        r$rv$exrate_time_region <- unique(r$rv$dt_market_content[REGION == r$rv$region]$EXRATE_TIME)

        ### Retrieve exrate_day_offset for the selected region from PRC_MARKET table
        ### Check that the same is unique, multiple values within the same region are not allowed
        if (length(r$rv$exrate_day_offset_region) == 1) {
          r$rv$exrate_day_offset <- r$rv$exrate_day_offset_region
        }

        ### Retrieve exrate_time for the selected region from PRC_MARKET table
        ### Check that the same is unique, multiple values within the same region are not allowed
        if (length(r$rv$exrate_time_region) == 1) {
          r$rv$exrate_time <- r$rv$exrate_time_region
        }

        if (!is.null(r$rv$market)) {
          r$rv$prev$market <- r$rv$market
          r$rv$market <- ""
        }

        r$rv$dt_prices_input <- NULL

        r$rv$dt_summary_report_day <- data.table::as.data.table(NULL)
        r$rv$dt_datawell_api <- data.table::as.data.table(NULL)
        r$rv$dt_datawell_filtered <- data.table::as.data.table(NULL)
        r$rv$dt_datawell_full <- data.table::as.data.table(NULL)
        r$rv$dt_imported <- data.table::as.data.table(NULL)

        r$rv$region_quote_id <- r$rv$dt_market_content[REGION == r$rv$region]$QUOTE_ID

        if (is.null(r$rv$dt_prc_asmp)) {
          r$rv$region_dt_prc_asmp <- NULL
        } else {
          r$rv$region_dt_prc_asmp <- r$rv$dt_prc_asmp[QUOTE_ID %in% r$rv$region_quote_id]
        }

        gargoyle::trigger("disable_buttons")
        gargoyle::trigger("disable_send_tables_button")
        gargoyle::trigger("change_region")
        gargoyle::trigger("enable_market")
        gargoyle::trigger("hide_waiter")

        if (!is.null(r$rv$region)) {
          if (r$rv$region == "") gargoyle::trigger("disable_market")
        }
      },
      ignoreNULL = TRUE
    )

    ## Auto-calc ----
    # When user switches from Manual to Automatic calculations, trigger
    # calculations and re-rendering
    shiny::observeEvent(
      r$rv$auto_calc,
      {
        log_info("observeEvent:", "r$rv$auto_calc", level = 2)

        shiny::req(r$rv$dt_prices_all)

        if (r$rv$auto_calc) {
          gargoyle::trigger("reset_dependencies")
          gargoyle::trigger("combine_price_data")
          gargoyle::trigger("calculate_prices")
          gargoyle::trigger("check_prices")
          gargoyle::trigger("get_prices_status")
          gargoyle::trigger("pivot_prices")
          gargoyle::trigger("update_price_input")
        }
      },
      ignoreInit = TRUE
    )

    ## Draft switch ----
    # When user switches from FALSE to TRUE - include draft prices from other markets, trigger
    # calculations and re-rendering
    shiny::observeEvent(
      r$rv$use_draft_switch,
      {
        log_info("observeEvent:", "r$rv$use_draft_switch", level = 2)

        shiny::req(r$rv$dt_prices_all)

        gargoyle::trigger("show_waiter")
        gargoyle::trigger("tabulator_destroy")
        gargoyle::trigger("create_price_table")
        gargoyle::trigger("get_live_prices")
        gargoyle::trigger("get_stg_prices")
        gargoyle::trigger("get_asmp")
        gargoyle::trigger("check_staged_exrates")
        gargoyle::trigger("get_exrates")
        gargoyle::trigger("get_fixed_conv")
        gargoyle::trigger("get_deals")
        gargoyle::trigger("get_random_data")
        gargoyle::trigger("combine_price_data")
        gargoyle::trigger("send_js_prices")
        gargoyle::trigger("check_final_status")
        gargoyle::trigger("calculate_prices")
        gargoyle::trigger("populate_custom_column")
        gargoyle::trigger("check_prices")
        gargoyle::trigger("get_prices_status")
        gargoyle::trigger("pivot_prices")
        gargoyle::trigger("show_custom_tbl")
        gargoyle::trigger("show_price_input")
        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## Show notes ----
    # When Show notes is on - NOTES column is visible
    shiny::observeEvent(
      r$rv$notes_switch,
      {
        log_info("observeEvent:", "r$rv$notes_switch", level = 2)

        shiny::req(r$rv$prices_curr_tabulator_ids)

        if (r$rv$notes_switch) {
          r$rv$columns_visible_input[["NOTES"]] <- TRUE
          r$rv$columns_visible_input[["NOTES_POPUP"]] <- TRUE
          r$rv$columns_visible_input[["LATEST_NOTES"]] <- TRUE

          purrr::walk(.x = r$rv$prices_curr_tabulator_ids, .f = function(id) {
            tabulator_id <- paste(id, "tabulator", sep = "-")

            argusDS.tabulator::tabulatorProxy(tabulator_id) %>%
              argusDS.tabulator::show_column("NOTES") %>%
              argusDS.tabulator::show_column("NOTES_POPUP") %>%
              argusDS.tabulator::show_column("LATEST_NOTES")
          })
        } else {
          r$rv$columns_visible_input[["NOTES"]] <- FALSE
          r$rv$columns_visible_input[["NOTES_POPUP"]] <- FALSE
          r$rv$columns_visible_input[["LATEST_NOTES"]] <- FALSE

          purrr::walk(.x = r$rv$prices_curr_tabulator_ids, .f = function(id) {
            tabulator_id <- paste(id, "tabulator", sep = "-")

            argusDS.tabulator::tabulatorProxy(tabulator_id) %>%
              argusDS.tabulator::hide_column("NOTES") %>%
              argusDS.tabulator::hide_column("NOTES_POPUP") %>%
              argusDS.tabulator::hide_column("LATEST_NOTES")
          })
        }
      },
      ignoreInit = TRUE
    )

    ## Show overrides ----
    ## When Show overrides is on, override columns (VALUE, DBR, FWD) are visible
    shiny::observeEvent(
      r$rv$override_switch,
      {
        log_info("observeEvent:", "r$rv$override_switch", level = 2)

        shiny::req(r$rv$prices_curr_tabulator_ids)

        ovr_cols <- c("OVERRIDE")

        if (r$rv$override_switch) {
          r$rv$columns_visible_input[["OVERRIDE"]] <- TRUE

          if (r$rv$columns_visible_input[["BASIS"]] == TRUE) {
            r$rv$columns_visible_input[["OVERRIDE_DBR"]] <- TRUE
            ovr_cols <- append(ovr_cols, "OVERRIDE_DBR")
          }

          if (r$rv$columns_visible_input[["FORWARD"]] == TRUE) {
            r$rv$columns_visible_input[["OVERRIDE_FWD"]] <- TRUE
            ovr_cols <- append(ovr_cols, "OVERRIDE_FWD")
          }
        } else {
          r$rv$columns_visible_input[["OVERRIDE"]] <- FALSE

          if (r$rv$columns_visible_input[["BASIS"]] == TRUE) {
            r$rv$columns_visible_input[["OVERRIDE_DBR"]] <- FALSE
            ovr_cols <- append(ovr_cols, "OVERRIDE_DBR")
          }

          if (r$rv$columns_visible_input[["FORWARD"]] == TRUE) {
            r$rv$columns_visible_input[["OVERRIDE_FWD"]] <- FALSE
            ovr_cols <- append(ovr_cols, "OVERRIDE_FWD")
          }
        }

        purrr::walk(.x = r$rv$prices_curr_tabulator_ids, .f = function(id) {
          tabulator_id <- paste(id, "tabulator", sep = "-")

          purrr::walk(.x = ovr_cols, .f = function(col) {
            argusDS.tabulator::tabulatorProxy(tabulator_id) %>%
              argusDS.tabulator::toggle_column(col)
          })
        })
      },
      ignoreInit = TRUE
    )

    ## Calculate prices ----
    shiny::observeEvent(
      gargoyle::watch("calculate_prices"),
      {
        log_info("observeEvent:", "calculate_prices", level = 1)

        shiny::req(r$rv$dt_prices_all)

        r$rv$dt_prices_all <- argusDT.PriceStudioMain::fct_calculate_prices(
          report_date = r$rv$report_date,
          dt_prices = r$rv$dt_prices_all,
          dt_deals = r$rv$dt_deals,
          dt_exrates = r$rv$dt_exrates,
          dt_fixed_conv = r$rv$dt_fixed_conv,
          dt_prc_asmp = r$rv$region_dt_prc_asmp,
          exrate_time = r$rv$exrate_time,
          market = r$rv$market,
          dt_edit_latest = r$rv$dt_edit_latest,
          r = r
        )
      },
      ignoreInit = TRUE
    )

    ## Add ERROR and CORRECTION columns ---
    shiny::observeEvent(
      gargoyle::watch("check_prices"),
      {
        log_info("observeEvent:", "check_prices", level = 1)

        shiny::req(r$rv$dt_prices_all)

        argusDT.PriceStudioMain::fct_check_prices(r$rv$dt_prices_all)

        r$rv$final_status <- all(
          r$rv$dt_prices_all[
            TYPE != "Imported" & RANK == 1 & MARKET == r$rv$market & PUBLISH == TRUE
          ]$FINAL
        )
      },
      ignoreInit = TRUE
    )

    ## Pivot prices ----
    shiny::observeEvent(
      gargoyle::watch("pivot_prices"),
      {
        log_info("observeEvent:", "pivot_prices", level = 1)

        shiny::req(r$rv$dt_prices_all)

        r$rv$dt_prices_pivot <- argusDT.PriceStudioMain::fct_pivot_prices(
          dt_prices = r$rv$dt_prices_all,
          dt_market_content = r$rv$dt_market_content[REGION == r$rv$region]
        )
      },
      ignoreInit = TRUE
    )

    ## Show custom tbls ----
    shiny::observeEvent(
      gargoyle::watch("show_custom_tbl"),
      {
        log_info("observeEvent:", "show_custom_tbl", level = 1)

        shiny::req(r$rv$dt_prices_all)

        ## Remove function calls within this observeEvent if they do not apply
        ## to your application

        if (nrow(r$rv$dt_prices_all[TYPE == "Imported"]) > 0 & !is.null(r$rv$dt_prc_asmp)) {
          ## Display Imported table
          argusDT.PriceStudioMain::fct_show_custom_tbl(
            input,
            output,
            session,
            r,
            mod_ui = "mod_tabulator_imported_ui",
            mod_server = "mod_tabulator_imported_server",
            box_id = "box_insert_prices",
            id = "imported_or",
            curr_market = r$rv$market,
            used_markets = r$rv$market,
            paginationsize = 10
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Show prices ----
    shiny::observeEvent(
      gargoyle::watch("show_price_input"),
      {
        log_info("observeEvent:", "show_price_input", level = 1)

        shiny::req(r$rv$dt_prices_all)

        r$rv$iteration <- r$rv$iteration + 1

        fct_show_price_input(input, session, r, box_id = "box_insert_prices", r$rv$iteration)

        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## Change market ----
    shiny::observeEvent(
      r$rv$market,
      {
        log_info("observeEvent:", "r$rv$market", level = 1)

        if (!is.null(r$rv$prev$market)) {
          if (r$rv$prev$market == "" & r$rv$market != "") {
            gargoyle::trigger("import_prices")
          } else {
            fct_check_staged_exrates(r = r)
            gargoyle::trigger("show_waiter")
            gargoyle::trigger("tabulator_destroy")
            gargoyle::trigger("combine_price_data")
            gargoyle::trigger("check_final_status")
            gargoyle::trigger("calculate_prices")
            gargoyle::trigger("check_prices")
            gargoyle::trigger("get_prices_status")
            gargoyle::trigger("pivot_prices")
            gargoyle::trigger("show_custom_tbl")
            gargoyle::trigger("show_price_input")
            gargoyle::trigger("get_prices_status")
          }
        } else {
          if (r$rv$market != "") {
            gargoyle::trigger("import_prices")
          } else {
            fct_check_staged_exrates(r = r)
            gargoyle::trigger("show_waiter")
            gargoyle::trigger("tabulator_destroy")
            gargoyle::trigger("combine_price_data")
            gargoyle::trigger("check_final_status")
            gargoyle::trigger("calculate_prices")
            gargoyle::trigger("check_prices")
            gargoyle::trigger("get_prices_status")
            gargoyle::trigger("pivot_prices")
            gargoyle::trigger("show_custom_tbl")
            gargoyle::trigger("show_price_input")
            gargoyle::trigger("get_prices_status")
          }
        }
      },
      ignoreNULL = TRUE
    )

    ## Check final status ----
    shiny::observeEvent(
      gargoyle::watch("check_final_status"),
      {
        log_info("observeEvent:", "check_final_status", level = 1)

        status <- r$rv$dt_prices_all[
          TYPE != "Imported" & RANK == 1 & MARKET == r$rv$market & PUBLISH == TRUE
        ]$FINAL %>%
          unique()

        r$rv$final_status <- if (is_truthy(length(status) == 1)) status else FALSE
      },
      ignoreInit = TRUE,
      ignoreNULL = TRUE
    )

    ## Reset dependecies ----
    shiny::observeEvent(
      gargoyle::watch("reset_dependencies"),
      {
        log_info("observeEvent:", "reset_dependencies", level = )

        # Empty record of lastest input
        r$rv$dt_edit_latest <- data.table::as.data.table(NULL)
      },
      ignoreInit = TRUE
    )

    ## Update price tables ----
    shiny::observeEvent(
      gargoyle::watch("update_price_input"),
      {
        log_info("observeEvent:", "update_price_input", level = 1)

        shiny::req(
          r$rv$prices_curr_tabulator_ids,
          r$rv$prices_curr_sections,
          r$rv$market,
          r$rv$dt_prices_pivot
        )

        purrr::walk2(
          .x = r$rv$prices_curr_tabulator_ids,
          .y = r$rv$prices_curr_sections,
          .f = function(id, section, dt_market) {
            tabulator_id <- paste(id, "tabulator", sep = "-")

            dt_section <- argusDT.PriceStudioMain::fct_get_pivot_section(
              dt = dt_market,
              section = section
            )

            ## Add index
            dt_section[, `:=`(ID, 1:.N)]

            ## Update columns excluding LOW / HIGH / MID / CHANGE/ FINAL / NOTES / SPREAD input
            cols_no_upd <- names(dt_section)[
              !names(dt_section) %in%
                c("LOW", "HIGH", "MID", "CHANGE", "FINAL", "NOTES", "CHANGE_PCT", "SPREAD")
            ]

            dt_upd_input <- dt_section[TYPE == "Input", ..cols_no_upd]

            if (nrow(dt_upd_input) > 0) {
              argusDS.tabulator::tabulatorProxy(tabulator_id) %>%
                argusDS.tabulator::update_data(dt_upd_input)
            }

            ## Update columns excluding in FINAL / NOTES / SPREAD input
            cols_calc <- names(dt_section)[!names(dt_section) %in% c("FINAL", "NOTES", "SPREAD")]

            dt_cols_calc <- dt_section[TYPE == "Calculated", ..cols_calc]

            if (nrow(dt_cols_calc) > 0) {
              argusDS.tabulator::tabulatorProxy(tabulator_id) %>%
                argusDS.tabulator::update_data(dt_cols_calc)

              ## Re-run reformat of rows for calculated prices only
              lapply(dt_cols_calc$ID, function(x) {
                shinyjs::runjs(glue::glue(
                  "get_tabulator('<<ns(tabulator_id)>>').getRow(<<x>>).reformat();",
                  .open = "<<",
                  .close = ">>"
                ))
              })
            }

            ## Update Status column if calculations got updated after it was set to FINAL
            if (is_truthy(r$rv$dt_edit_latest[, .N] > 0) & !is.null(r$rv$dt_prc_asmp)) {
              ## Update status for calculations
              pattern_code <- r$rv$dt_edit_latest[, paste0(CODE_ID, collapse = "|")]
              pattern_qpt <- r$rv$dt_edit_latest[, paste0(QUOTE_PRICETYPE_ID, collapse = "|")]
              quote_ids <- r$rv$dt_prc_asmp[
                grepl(pattern_code, NEED_CODE) | grepl(pattern_qpt, NEED_QPT),
                QUOTE_ID
              ]

              dt_upd_status <- dt_section[QUOTE_ID %in% quote_ids & FINAL == FALSE, .(ID, FINAL)]

              if (nrow(dt_upd_status) > 0) {
                argusDS.tabulator::tabulatorProxy(tabulator_id) |>
                  argusDS.tabulator::update_data(dt_upd_status)
              }
            }
          },
          dt_market = r$rv$dt_prices_pivot[MARKET == r$rv$market]
        )

        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## Update statuses on screen ----
    shiny::observeEvent(
      gargoyle::watch("update_statuses"),
      {
        log_info("observeEvent:", "update_statuses", level = 1)

        shiny::req(
          r$rv$prices_curr_tabulator_ids,
          r$rv$prices_curr_sections,
          r$rv$market,
          r$rv$dt_prices_pivot
        )

        purrr::walk2(
          .x = r$rv$prices_curr_tabulator_ids,
          .y = r$rv$prices_curr_sections,
          .f = function(id, section, dt_market) {
            tabulator_id <- paste(id, "tabulator", sep = "-")

            dt_section <- argusDT.PriceStudioMain::fct_get_pivot_section(
              dt = dt_market,
              section = section
            )

            ## Add index
            dt_section[, `:=`(ID, 1:.N)]

            ## Update STATUS column
            dt_upd <- dt_section[, c("ID", "FINAL")]

            argusDS.tabulator::tabulatorProxy(tabulator_id) %>%
              argusDS.tabulator::update_data(dt_upd)
          },
          dt_market = r$rv$dt_prices_pivot[MARKET == r$rv$market]
        )

        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## Copy prices ----
    shiny::observeEvent(
      gargoyle::watch("copy_prices"),
      {
        log_info("observeEvent:", "copy_prices", level = 1)

        ## Do not proceed if auto-calc is OFF
        if (!r$rv$auto_calc) {
          log_warn(
            "The \"Auto calculate\" switch must be turned ON before copying prices.",
            prompt = TRUE,
            title = "\"Auto calculate\" switch is OFF"
          )
          return(NULL)
        }

        shiny::showModal(shiny::modalDialog(
          paste(
            "Are you sure you want to overwrite your selected market data",
            "with the prior day values?"
          ),
          footer = shiny::tagList(
            col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("confirm_copy"),
              label = "Confirm"
            )),
            col_2(
              shiny::modalButton("Cancel") %>% shiny::tagAppendAttributes(class = "btn-default")
            )
          )
        ))
      },
      ignoreInit = TRUE
    )

    ## Confirm copy button ----
    shiny::observeEvent(
      input$`confirm_copy-actionbutton`,
      {
        log_info("observeEvent:", "copy_prices", level = 1)

        dt_market_pivot <- r$rv$dt_prices_pivot[TYPE == "Input" & MARKET == r$rv$market]

        dt_input <- argusDT.PriceStudioMain::fct_copy_previous_values(
          dt_market_pivot = dt_market_pivot,
          dt_prices_all = r$rv$dt_prices_all[PUBLISH == TRUE],
          dt_pricetype = argusDT.PriceStudioMain::dt_pricetype
        )

        ## Calculate mid
        dt_input <- argusDT.PriceStudioMain::fct_calculate_mid(dt_input)

        ### Combine new inputs to rest of previous inputs
        if (!is.null(r$rv$dt_prices_input)) {
          r$rv$dt_prices_input <- rbind(
            r$rv$dt_prices_input[!QPT_MID %in% dt_input$QPT_MID],
            dt_input
          )
        } else {
          r$rv$dt_prices_input <- dt_input
        }

        if (r$rv$auto_calc) {
          gargoyle::trigger("combine_price_data")
          gargoyle::trigger("calculate_prices")
          gargoyle::trigger("check_prices")
          gargoyle::trigger("get_prices_status")
          gargoyle::trigger("pivot_prices")
          gargoyle::trigger("update_price_input_copied")
        }

        shiny::removeModal()
      },
      ignoreInit = TRUE
    )

    ## Update for copied prices ----
    shiny::observeEvent(
      gargoyle::watch("update_price_input_copied"),
      {
        log_info("observeEvent:", "update_price_input_copied", level = 1)

        shiny::req(
          r$rv$prices_curr_tabulator_ids,
          r$rv$prices_curr_sections,
          r$rv$market,
          r$rv$dt_prices_pivot
        )

        purrr::walk2(
          .x = r$rv$prices_curr_tabulator_ids,
          .y = r$rv$prices_curr_sections,
          .f = function(id, section, dt_market) {
            tabulator_id <- paste(id, "tabulator", sep = "-")

            dt_section <- argusDT.PriceStudioMain::fct_get_pivot_section(
              dt = dt_market,
              section = section
            )

            ## Add index
            dt_section[, `:=`(ID, 1:.N)]

            argusDS.tabulator::tabulatorProxy(tabulator_id) %>%
              argusDS.tabulator::update_data(dt_section)

            ### Set to draft ----
            shinyjs::runjs(glue::glue_collapse(glue::glue(
              "get_tabulator('<<ns(tabulator_id)>>').getRows().forEach(row => {
                row.update({ FINAL: false });
              });",
              .open = "<<",
              .close = ">>"
            )))
          },
          dt_market = r$rv$dt_prices_pivot[MARKET == r$rv$market]
        )

        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## View staged prices ----
    shiny::observeEvent(
      gargoyle::watch("view_staged_prices"),
      {
        log_info("observeEvent:", "view_staged_prices", level = 1)

        # Get table with staged/live input values
        cols <- c(
          "CODE_ID",
          "TS",
          "CF",
          "SECTION",
          "CODE_DESCRIPTION",
          "OUT_DIFF_TYPE",
          "FORWARD",
          "LOW",
          "HIGH",
          "MID",
          "CHANGE",
          "CHANGE_PCT"
        )

        dt <- r$rv$dt_prices_pivot[
          MARKET == r$rv$market & TYPE == "Input" & SOURCE %in% c("STG", "LIVE"),
          .SD,
          .SDcols = cols
        ]

        shiny::showModal(shiny::modalDialog(
          shiny::tags$style(type = 'text/css', '.modal-dialog { width: fit-content !important; }'),

          if (nrow(dt) > 0) {
            output$tabulator_stg_inp <- argusDS.tabulator::renderTabulator({
              log_info("tabulatorOutput ID:", ns("tabulator_stg_inp"), level = 4)

              argusDT.PriceStudioMain::fct_render_tabulator_auto(dt)
            })
          } else {
            shiny::tags$h2("No values saved")
          },
          size = "xl",
          easyClose = TRUE,
          footer = shiny::tagList(col_4(shiny::modalButton("Close")), col_4())
        ))
      },
      ignoreInit = TRUE
    )

    ## All final checkbox ----
    ## When Final status checkbox is updated, update all tables
    shiny::observeEvent(
      gargoyle::watch("update_final_flag"),
      {
        log_info("observeEvent:", "update_final_flag", level = 2)

        shiny::req(r$rv$market != "")

        ## Only run through the update final flag process below if a market is selected,
        ## otherwise skip that
        r$rv$dt_prices_all[
          RANK == 1 &
            TYPE != "Imported" &
            MARKET == r$rv$market &
            PUBLISH == TRUE &
            !is.na(VALUE) &
            !is.na(FWD) &
            !is.na(YEAR) &
            !is.na(DBR),
          FINAL := r$rv$final_status
        ]

        ### Remove unnecessary columns
        cols <- setdiff(
          names(r$rv$dt_prices_all),
          c("VALUE_SOURCE", "PIVOT_LOW", "PIVOT_HIGH", "PIVOT_MID", "PIVOT_FORWARD", "PIVOT_BASIS")
        )

        ### Update input to store new Status
        if (is_truthy(nrow(r$rv$dt_prices_input) > 0)) {
          dt_update_calc <- r$rv$dt_prices_all[
            RANK == 1 &
              TYPE == "Calculated" &
              MARKET == r$rv$market &
              !(QPT_MID %in% r$rv$dt_prices_input$QPT_MID),
            ..cols
          ][, `:=`(
            VALUE = NA_real_,
            FWD = NA_integer_,
            YEAR = NA_integer_,
            DBR = NA_integer_,
            CHANGE = NA_real_,
            FORWARD = NA_character_,
            BASIS = NA_integer_
          )]

          dt_update_input <- r$rv$dt_prices_all[
            RANK == 1 &
              TYPE == "Input" &
              MARKET == r$rv$market &
              !(QPT_MID %in% r$rv$dt_prices_input$QPT_MID),
            ..cols
          ][, `:=`(
            VALUE = VALUE,
            FWD = FWD,
            YEAR = YEAR,
            DBR = DBR,
            CHANGE = CHANGE,
            FORWARD = FORWARD,
            BASIS = BASIS
          )]

          r$rv$dt_prices_input <- rbind(r$rv$dt_prices_input, dt_update_calc, dt_update_input)

          r$rv$dt_prices_input[
            TYPE == "Input" &
              MARKET == r$rv$market &
              PUBLISH == TRUE &
              !is.na(VALUE) &
              !is.na(FWD) &
              !is.na(YEAR) &
              !is.na(DBR),
            FINAL := r$rv$final_status
          ]

          r$rv$dt_prices_input[
            TYPE == "Calculated" & MARKET == r$rv$market & PUBLISH == TRUE,
            FINAL := r$rv$final_status
          ]
        } else {
          dt_update_input <- r$rv$dt_prices_all[
            RANK == 1 & TYPE == "Input" & MARKET == r$rv$market,
            ..cols
          ][, `:=`(
            VALUE = VALUE,
            FWD = FWD,
            YEAR = YEAR,
            DBR = DBR,
            CHANGE = CHANGE,
            FORWARD = FORWARD,
            BASIS = BASIS
          )]

          dt_update_calc <- r$rv$dt_prices_all[
            RANK == 1 & TYPE == "Calculated" & MARKET == r$rv$market,
            ..cols
          ][, `:=`(
            VALUE = NA_real_,
            FWD = NA_integer_,
            YEAR = NA_integer_,
            DBR = NA_integer_,
            CHANGE = NA_real_,
            FORWARD = NA_character_,
            BASIS = NA_integer_
          )]

          r$rv$dt_prices_input <- rbind(dt_update_calc, dt_update_input)
        }
      },
      ignoreInit = TRUE
    )

    ## Column visibility (once)----
    shiny::observeEvent(
      r$rv$dt_prices_pivot,
      {
        log_info("observeEvent:", "r$rv$dt_prices_pivot", level = 1)

        r$rv$columns_visible_input <- argusDT.PriceStudioMain::fct_s3_visiblecols_read(
          col_names = c(colnames(r$rv$dt_prices_pivot), "ID"),
          filename = id,
          db_env = r$rv$db_env,
          folder = r$s3_dir,
          s3_bucket = get_config("s3_bucket")
        )

        r$rv$notes_switch <- any(r$rv$columns_visible_input[["NOTES"]])

        r$rv$override_switch <- any(
          r$rv$columns_visible_input[["OVERRIDE"]],
          r$rv$columns_visible_input[["OVERRIDE_DBR"]],
          r$rv$columns_visible_input[["OVERRIDE_FWD"]]
        )
      },
      ignoreInit = TRUE,
      once = TRUE,
      priority = 1
    )

    ## Visible columns modal ----
    shiny::observeEvent(
      gargoyle::watch(ns("visible_columns")),
      {
        log_info("observeEvent:", ns("visible_columns"), level = 2)

        shiny::req(r$rv$columns_visible_input, r$rv$dt_prices_pivot)

        cols_vis <- r$rv$columns_visible_input
        cols_dt <- c(colnames(r$rv$dt_prices_pivot), "ID")
        selected <- names(cols_vis[which(cols_vis == TRUE)])

        shiny::showModal(shiny::modalDialog(
          inputId = ns("visible_columns_modal"),
          title = "Show / Hide Price Input Columns",
          size = "xl",
          easyClose = TRUE,

          bslib::card(
            max_height = "60vh",
            shinyWidgets::checkboxGroupButtons(
              inputId = ns("columns_checkbox_group"),
              choices = cols_dt,
              selected = selected,
              status = "primary",
              size = "sm",
              direction = "vertical",
              justified = TRUE,
              individual = TRUE,
              checkIcon = list(
                yes = fontawesome::fa("check", fill = "#44AB05"),
                no = fontawesome::fa("xmark", fill = "#DD2303")
              )
            )
          ),

          footer = bslib::layout_columns(
            col_widths = 6,
            max_height = "100%",

            argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("update_columns"),
              label = "Update"
            ),

            shiny::modalButton("Cancel") |> shiny::tagAppendAttributes(class = "btn-default")
          )
        ))
      },
      ignoreInit = TRUE
    )

    ## Update visible columns (S3) ----
    shiny::observeEvent(
      input$`update_columns-actionbutton`,
      {
        log_info("observeEvent:", "input$update_columns-actionbutton", level = 2)

        shiny::removeModal()

        shiny::req(input$columns_checkbox_group, r$rv$dt_prices_pivot)

        r$rv$columns_visible_input <- argusDT.PriceStudioMain::fct_s3_visiblecols_write(
          col_names = c(colnames(r$rv$dt_prices_pivot), "ID"),
          col_selected = input$columns_checkbox_group,
          filename = id,
          db_env = r$rv$db_env,
          folder = r$s3_dir,
          s3_bucket = get_config("s3_bucket")
        )

        r$rv$notes_switch <- any(r$rv$columns_visible_input[["NOTES"]])

        r$rv$override_switch <- any(
          r$rv$columns_visible_input[["OVERRIDE"]],
          r$rv$columns_visible_input[["OVERRIDE_DBR"]],
          r$rv$columns_visible_input[["OVERRIDE_FWD"]]
        )

        gargoyle::trigger("import_prices")
      },
      ignoreInit = TRUE
    )

    ## Review corrections specific to module ----
    r$rv$observeEvent_correction_box <- shiny::observeEvent(
      gargoyle::watch(ns("input_status-review_corrections")),
      {
        log_info("observeEvent:", ns("input_status-review_corrections"), level = 2)

        r$rv$dt_correction_review <- data.table::copy(r$rv$dt_prices_pivot)
        gargoyle::trigger("review_corrections")
      },
      ignoreInit = TRUE
    )

    ## Review corrections modal ----
    r$rv$observeEvent_correction_box <- shiny::observeEvent(
      gargoyle::watch("review_corrections"),
      {
        log_info("observeEvent:", ns("review_corrections"), level = 2)

        ### If the button Review corrections has been clicked from Price Summary / InDesign, but
        ### r$rv$dt_pivot_summary is not built yet (because nothing is finalised), then use
        ### r$rv$dt_prices_pivot to display the records to correct
        if (r$rv$dt_correction_review[, .N] == 0) {
          r$rv$dt_correction_review <- data.table::copy(r$rv$dt_prices_pivot)
        }

        ### Filter by records who are flagged as a correction
        dt_display <- r$rv$dt_correction_review[CORRECTION == TRUE]

        ### Select only the columns to display within the tabulator
        cols <- c(
          "BASIS_DROPDOWN",
          "CODE_DESCRIPTION",
          "CODE_ID",
          "DBR",
          "DBR_DROPDOWN",
          "DECIMALPLACES_HIGH",
          "DECIMALPLACES_LOW",
          "DECIMALPLACES_MID",
          "FORWARD",
          "FORWARD_DROPDOWN",
          "FWD_DROPDOWN",
          "HIGH",
          "LIVE_DBR",
          "LIVE_FWD",
          "LIVE_HIGH",
          "LIVE_LOW",
          "LIVE_MID",
          "LIVE_YEAR",
          "LOW",
          "MID",
          "TIMING",
          "UNIT"
        )

        dt_display <- dt_display[, ..cols]

        prompt_timings <- c("prompt", "spot", "dated", "day-ahead", "weekend", "week-ahead")

        ### Add LIVE_FORWARD column using LIVE_FWD and LIVE_YEAR ones
        dt_display[,
          LIVE_FORWARD := data.table::fcase(
            !is.na(LIVE_FWD) & !is.na(LIVE_YEAR) & LIVE_FWD != 0 , paste(LIVE_YEAR, LIVE_FWD, sep = "-") ,
            TIMING %in% prompt_timings                           , TIMING
          )
        ]

        ### Add ID column
        dt_display[, ID := 1:.N]

        ### Remove un-used columns
        dt_display[, `:=`(LIVE_FWD = NULL, LIVE_YEAR = NULL, TIMING = NULL)]

        ### Display modal with tabulator containing correction records
        shiny::showModal(shiny::modalDialog(
          shiny::tags$style(type = 'text/css', '.modal-dialog {max-width: fit-content;}'),

          if (dt_display[, .N] > 0) {
            output$tabulator_review_corr <- argusDS.tabulator::renderTabulator({
              log_info("tabulatorOutput ID:", ns("tabulator_review_corr"), level = 3)

              argusDT.PriceStudioMain::fct_render_tabulator_corrections(dt_display)
            })
          } else {
            shiny::tags$h2("No corrections to review")
          },
          easyClose = TRUE,
          footer = shiny::tagList(col_4(shiny::modalButton("Close")), col_4())
        ))
      },
      ignoreInit = TRUE
    )
  })
}
