#' deals_tab UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_deals_tab_ui <- function(id) {
  ns <- NS(id)

  shiny::tagList(
    htmltools::tags$div(
      id = ns("tabulator_deals-div"),
      style = "overflow-x: auto; padding-top: 0.5rem;",
      class = "main-box",
      argusDS.tabulator::tabulatorOutput(
        outputId = ns("tabulator_deals"),
        height = "100%",
        width = "auto"
      ),

      shinyjs::hidden(
        htmltools::tags$div(
          id = ns("error_message_deals"),
          htmltools::tags$h5("No deals available for today.")
        )
      )
    )
  )
}

#' deals_tab Server Functions
#'
#' @noRd
mod_deals_tab_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    cols <- c("DEAL_CODE_ID", "DEAL_CODE", "PUBLICATION_DATE", "PRICE", "VOLUME")

    ## Add tabulator table in Deals tab
    output$tabulator_deals <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator_deals"), level = 4)

      if (!is.null(r$rv$dt_deals)) {
        shinyjs::hide("error_message_deals")

        argusDT.PriceStudioMain::fct_render_tabulator_auto(
          r$rv$dt_deals[order(-PUBLICATION_DATE, DEAL_CODE_ID)][, ..cols],
          paginationsize = 10,
          row_formatter = fct_js_deal_rowformat(r$rv$report_date)
        )
      } else {
        shinyjs::show("error_message_deals")
      }
    })
  })
}
