#' asmp_tab UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @importFrom shiny NS tagList
mod_asmp_tab_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_asmp_tab_ui ns:", get_ns(ns), level = 2)

  bslib::layout_columns(
    class = "main-box",
    id = ns("tabulator_asmp-div"),
    col_widths = 12,

    # Assumption Table ----
    shinyjs::hidden(htmltools::tags$div(
      id = ns("error_message_asmp"),
      htmltools::tags$h5("Assumptions not available")
    )),
    argusDS.tabulator::tabulatorOutput(
      outputId = ns("tabulator_asmp"),
      height = "100%",
      width = "auto"
    )
  )
}

#' asmp_tab Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.

mod_asmp_tab_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    r$asmp_tab$observeEvent <- list()

    # Add widgets ----
    ## Table ----
    output$tabulator_asmp <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator_asmp"), level = 4)

      if (!is.null(r$rv$dt_asmp)) {
        shinyjs::hide("error_message_asmp")

        argusDT.PriceStudioMain::fct_render_tabulator_asmp(
          dt = r$rv$dt_asmp,
          report_date = r$rv$report_date,
          tabulator_id = ns("tabulator_asmp"),
          paginationsize = 50
        )
      } else {
        shinyjs::show("error_message_asmp")
      }
    }) |>
      shiny::bindEvent(r$rv$dt_asmp)

    # Observe Events ----
    ## Cell click ----
    shiny::observeEvent(input$tabulator_asmp_cellClick, {
      log_info("observeEvent:", "Tabulator cell clicked", level = 2)

      shiny::req(input$tabulator_asmp_cellClick)

      r$rv$asmp_details_selected <- input$tabulator_asmp_cellClick$row$DETAILS
      r$rv$asmp_unit_selected <- input$tabulator_asmp_cellClick$row$UNIT
      r$rv$asmp_id_selected <- input$tabulator_asmp_cellClick$row$ASSUMPTION_ID
      r$rv$asmp_old_value <- input$tabulator_asmp_cellClick$row$VALUE
      r$rv$asmp_added_on <- input$tabulator_asmp_cellClick$row$ADDED_ON

      gargoyle::trigger("show_asmp_modal_dialog")
    })

    ## Show modal dialog ----
    shiny::observeEvent(
      gargoyle::watch("show_asmp_modal_dialog"),
      {
        log_info("observeEvent:", "show_asmp_modal_dialog", level = 1)

        if (r$rv$report_date != Sys.Date()) {
          log_warn(
            "Report Date should be present date.\n\n",
            "Assumption cannot be updated for past or future dates.",
            prompt = TRUE,
            title = "Date Error",
            type = "error"
          )
        } else if (r$rv$asmp_added_on == Sys.Date()) {
          log_warn(
            "This assumption was updated today.\n\n",
            "Assumption cannot be updated twice in a day.",
            prompt = TRUE,
            title = "Same Date Error",
            type = "error"
          )
        } else {
          shiny::showModal(mod_asmp_details_ui(id = ns("modal_popup")))

          mod_asmp_details_server(
            id = "modal_popup",
            asmp_id = r$rv$asmp_id_selected,
            details = r$rv$asmp_details_selected,
            unit = r$rv$asmp_unit_selected,
            old_value = r$rv$asmp_old_value,
            r = r
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Insert new value ----
    shiny::observeEvent(
      gargoyle::watch("update_asmp"),
      {
        log_info("observeEvent:", "update_asmp", level = 2)

        if (is.null(input$`modal_popup-asmp_value`) || input$`modal_popup-asmp_value` == "") {
          log_warn(
            "Input value cannot be empty.\n\n",
            "Enter the value and submit again.",
            prompt = TRUE,
            title = "Value Error",
            type = "error"
          )
        } else if (input$`modal_popup-asmp_value` == r$rv$asmp_old_value) {
          log_warn(
            "The entered value is the same as the existing value.\n\n",
            "Assumption cannot be updated with the same value",
            prompt = TRUE,
            title = "Same Value Error",
            type = "error"
          )
        } else {
          shiny::showModal(shiny::modalDialog(
            paste("Are you sure you want to update this assumption?"),
            footer = bslib::layout_columns(
              col_widths = 6,
              max_height = "100%",
              argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("confirm_update_asmp"),
                label = "Confirm"
              ),
              shiny::modalButton("Cancel") |> shiny::tagAppendAttributes(class = "btn-default")
            ),
            easyClose = TRUE
          ))
        }
      },
      ignoreInit = TRUE
    )

    ## Confirm update ----
    shiny::observeEvent(
      input$`confirm_update_asmp-actionbutton`,
      {
        log_info("observeEvent:", "confirm_update_asmp", level = 1)

        shiny::removeModal()

        asmp_updt <- argusDT.PriceStudioMain::fct_update_asmp(
          value = as.numeric(input$`modal_popup-asmp_value`),
          asmp_id = as.numeric(r$rv$asmp_id_selected),
          username = get_config("username"),
          db_env = r$rv$db_env,
          connection = NULL
        )

        if (all(class(asmp_updt) == "integer")) {
          if (asmp_updt == 1) {
            gargoyle::trigger("get_formulas")
            gargoyle::trigger("get_marketcontent")
            gargoyle::trigger("import_prices")

            log_warn(
              "Assumption has been updated.",
              prompt = TRUE,
              title = "Update successful",
              type = "success"
            )
          } else {
            log_warn(
              "Assumption has not been updated.",
              prompt = TRUE,
              title = "Update failed",
              type = "error"
            )
          }
        }

        r$rv$asmp_added_on <- Sys.Date()
      },
      ignoreInit = TRUE
    )
  })
}
