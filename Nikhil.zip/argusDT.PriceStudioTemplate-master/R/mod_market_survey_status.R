#' Market Survey Status UI Function
#'
#' @description
#' UI module for Market Survey status display with three progress bars and one text display:
#' - Saved Tables: number of tables with data added
#' - Saved Rows: number of rows saved
#' - Updated Values: number of rows with data entered
#' - Files Saved: number of files uploaded to S3 (text only)
#'
#' @param id A shiny id.
#'
#' @return
#' [shiny::tagList] UI element consisting of three progress bars and one text display
#'
#' @family shiny module
#'
#' @noRd
mod_market_survey_status_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_market_survey_status_ui ns:", get_ns(ns), level = 3)

  # Status box ----
  bslib::layout_columns(
    col_widths = c(12),
    gap = 0,
    ## Saved Tables progress bar ----
    mod_progressbar_ui(
      id = ns("progress_tables"),
      title = "Saved Tables"
    ),
    ## Saved Rows progress bar ----
    mod_progressbar_ui(
      id = ns("progress_rows"),
      title = "Saved Rows"
    ),
    ## Updated Values progress bar ----
    mod_progressbar_ui(
      id = ns("progress_updated"),
      title = "Updated Rows"
    ),
    ## Files Saved text display ----
    shiny::textOutput(ns("files_count_display"))
  )
}


#' Market Survey Status Server Function
#'
#' @description
#' Server-side logic for `mod_market_survey_status_ui` that calculates and updates
#' the progress bars and text display based on database data for the report date.
#'
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#'
#' @return
#' Side effects include:
#'  - Updates to the progress bars and files text display based on market survey status
#'
#' @family shiny module
#'
#' @noRd
mod_market_survey_status_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_market_survey_status_server ns:", get_ns(ns), level = 3)

    # Get Market Survey status ----
    shiny::observeEvent(
      gargoyle::watch("get_market_survey_status"),
      {
        log_info("observeEvent:", ns("get_market_survey_status"), level = 1)

        ## Require necessary data ----
        shiny::req(r$market_survey$dt_pivot)
        shiny::req(r$rv$region)
        shiny::req(r$market_survey$market)
        shiny::req(r$rv$report_date)

        ## Calculate status metrics from database data ----
        status <- fct_market_survey_get_status(
          dt_pivot = r$market_survey$dt_pivot,
          dt_available_files = r$market_survey$dt_available_files,
          region = r$rv$region,
          market = r$market_survey$market,
          report_date = r$rv$report_date
        )

        # Update progress bar: Saved Tables ----
        mod_progressbar_server(
          id = "progress_tables",
          value = status$tables_saved,
          total = status$tables_total,
          title = "Saved Tables"
        )

        # Update progress bar: Saved Rows ----
        mod_progressbar_server(
          id = "progress_rows",
          value = status$rows_saved,
          total = status$rows_total,
          title = "Saved Rows"
        )

        # Update progress bar: Updated Rows ----
        mod_progressbar_server(
          id = "progress_updated",
          value = status$updated_count,
          total = status$updated_total,
          title = "Updated Values"
        )

        # Update Files Saved ----
        output$files_count_display <- shiny::renderText(
          paste0("Files Saved: ", status$files_count)
        )
      },
      ignoreInit = TRUE
    )
  })
}
