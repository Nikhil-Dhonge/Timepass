#' Download files from S3 bucket UI Function
#' @description A shiny Module.
#' @description A shiny Module.
#' @param id A shiny id.
#' @param width The width of the widget.
#' @param disabled_msg Tooltip when widget is disabled. Widget isn't disabled
#' if NULL.
#' @param tooltip_placement Position of the tooltip relative to the widget.
#' One of "auto", "top", "right", "bottom", "left".
#' @param tooltip_dark logical TRUE to show a dark background tooltip.
#' @inheritParams shiny::downloadButton
#' @inheritParams bslib::tooltip
mod_downloadbutton_s3_ui <- function(
  id,
  label = NULL,
  width = "100%",
  icon = NULL,
  disabled_msg = NULL,
  tooltip_placement = c("auto", "top", "right", "bottom", "left"),
  tooltip_dark = TRUE,
  ...
) {
  ns <- shiny::NS(id)

  tooltip_placement <- match.arg(tooltip_placement)

  log_info("mod_downloadbutton_s3_ui ns:", get_ns(ns), level = 3)

  outputId <- ns("downloadbutton_s3")
  divId <- ns("downloadbutton_s3-div")
  tooltipId <- ns("downloadbutton_s3-tooltip")

  log_info("downloadbutton ID:", outputId, level = 4)

  widget <- shiny::tags$div(
    id = divId,
    width = "100%",
    shiny::downloadButton(
      outputId = outputId,
      label = label,
      icon = icon,
      ...
    )
  )

  shiny::tagList(
    shiny::tags$div(
      id = id,
      class = "btn-default-container",
      bslib::tooltip(
        disabled_msg,
        placement = tooltip_placement,
        options = list(
          customClass = ifelse(tooltip_dark, "tooltip-dark", ""),
          trigger = ifelse(is.null(disabled_msg), "manual", "hover focus")
        ),
        trigger = shiny::tags$div(
          id = tooltipId,
          style = htmltools::css(width = shiny::validateCssUnit(width)),
          if (is.null(disabled_msg)) {
            widget
          } else {
            shinyjs::disabled(widget)
          }
        )
      )
    )
  )
}


#' download_button Server Functions
#' @param id A shiny id.
#' @param out_filename Character name of output file (without extension).
#' @param files Character vector of file keys in S3 bucket to download.
#' @param enable_trigger Character name of trigger used to enable
#' the widget. Ignored if NULL.
#' @param disable_trigger Character name of trigger used to disable
#' the widget. Ignored if NULL.
#'
mod_downloadbutton_s3_server <- function(
  id,
  out_filename,
  files,
  enable_trigger = NULL,
  disable_trigger = NULL
) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_downloadbutton_s3_server ns:", get_ns(ns), level = 3)

    outputId <- ns("downloadbutton_s3")
    tooltipId <- ns("downloadbutton_s3-tooltip")

    ## Download file locally
    output$downloadbutton_s3 <- shiny::downloadHandler(
      filename = function() {
        if (is_truthy(files)) {
          paste0(out_filename, ".zip")
        }
      },
      content = function(file) {
        ## Create a temporary directory to save S3 object(s) temporarily for the session
        temp_directory <- file.path(tempdir(), as.integer(Sys.time()))
        dir.create(temp_directory)

        purrr::map(
          .x = files,
          .f = argusDT.PriceStudioMain::fct_download_file_s3,
          s3_bucket = get_config("s3_bucket"),
          temp_directory = temp_directory
        )

        zip::zip(zipfile = file, files = dir(temp_directory), root = temp_directory)
      },
      contentType = "application/zip"
    )

    # Enable button ----
    ## If `enable_trigger` provided then use observe event to enable else
    ## enable on loading
    if (!is.null(enable_trigger)) {
      shiny::observeEvent(
        gargoyle::watch(enable_trigger),
        {
          log_info("observeEvent:", outputId, "enable", level = 1, session = session)

          shinyjs::enable(id = outputId, asis = TRUE)
          shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
            id = tooltipId,
            action = "disable"
          ))
        },
        ignoreInit = TRUE
      )
    } else {
      shinyjs::enable(id = outputId, asis = TRUE)
      shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
        id = tooltipId,
        action = "disable"
      ))
    }

    # Disable button ----
    if (!is.null(disable_trigger)) {
      shiny::observeEvent(
        gargoyle::watch(disable_trigger),
        {
          log_info("observeEvent:", outputId, "disable", level = 1, session = session)

          shinyjs::disable(id = outputId, asis = TRUE)
          shinyjs::runjs(argusDT.PriceStudioMain::fct_js_tooltip_action(
            id = tooltipId,
            action = "enable"
          ))
        },
        ignoreInit = TRUE
      )
    }
  })
}
