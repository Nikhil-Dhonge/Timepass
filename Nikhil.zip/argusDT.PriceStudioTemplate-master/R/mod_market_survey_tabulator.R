#' mod_market_survey_tabulator_ui
#' @description A shiny module for a market survey tabulator element
#' @param id A shiny id.
#' @param box_id character id for the box to insert the element into
mod_market_survey_tabulator_ui <- function(id, box_id) {
  ns <- shiny::NS(id)

  log_info("mod_market_survey_tabulator_ui ns:", get_ns(ns), level = 3)

  id_div <- ns("div")
  id_textoutput <- ns("text_output")
  id_aggregation <- ns("aggregation")
  id_tabulator <- ns("tabulator")

  log_info("box ID: ", box_id, level = 4)
  log_info("div ID: ", id_div, level = 4)
  log_info("textOutput ID: ", id_textoutput, level = 4)
  log_info("aggregation ID: ", id_aggregation, level = 4)
  log_info("tabulatorOutput ID: ", id_tabulator, level = 4)

  shiny::insertUI(
    selector = paste0("#", box_id),
    where = "beforeEnd",
    ui = htmltools::tags$div(
      class = "tabulator-table-ui",
      id = id_div,

      bslib::layout_columns(
        col_widths = c(6, 6, 12),
        gap = 0,

        shiny::strong(shiny::textOutput(outputId = id_textoutput)),

        shiny::textOutput(outputId = id_aggregation) |>
          shiny::tagAppendAttributes(class = "text-output-right-align"),

        htmltools::tags$div(
          argusDS.tabulator::tabulatorOutput(
            outputId = id_tabulator,
            height = "100%"
          )
        )
      )
    )
  )
}

#' mod_market_survey_tabulator_server
#' @param id A shiny id.
#' @param title character for the title
#' @param dt data.table for the data to put in the tabulator
#' @param r The global environment variable 'r'.
mod_market_survey_tabulator_server <- function(id, title, dt, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_market_survey_tabulator_server ns:", get_ns(ns), level = 3)

    ## Create ids ----
    id_click <- paste0(id, "_cell_click")
    id_add <- paste0(id, "_add")
    id_update <- paste0(id, "_update")
    id_update_market <- paste0(id, "_market")
    id_notes <- paste0(id, "_notes")
    id_aggregation <- paste0(id, "_aggregation")
    gargoyle::init(id_add)
    gargoyle::init(id_update)
    gargoyle::init(id_aggregation)

    ## Add section title ----
    output$text_output <- shiny::renderText(title)
    output$aggregation <- shiny::renderText(r$market_survey[[id_aggregation]])

    ## Create ID column ----
    dt[, ID := paste0(QPT_MID, sprintf("%03d", MARKET_SURVEY_ITEM_ID))]

    ## Render tabulator ----
    output$tabulator <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator"), level = 4)

      start_date <- r$rv$report_date - lubridate::dyears(1)
      years <- lubridate::year(seq(from = start_date, by = "year", length.out = 50))

      fct_market_survey_render_tabulator(
        visible_columns = r$market_survey$visible_columns,
        timezone = r$rv$user_timezone,
        comm_reporter = get_config("username"),
        dt = dt[QPT_MID == id],
        dt_price_category = golem::get_golem_options("dt_price_category"),
        dt_comm_methods = golem::get_golem_options("dt_comm_methods"),
        dt_traders = golem::get_golem_options("dt_traders"),
        dt_ports = golem::get_golem_options("dt_ports"),
        dt_unit = golem::get_golem_options("dt_unit"),
        dt_delivery_periods = golem::get_golem_options("dt_delivery_periods"),
        delivery_years = years,
        tabulator_id = ns("tabulator")
      )
    }) |>
      shiny::bindEvent(dt)

    ## Get user input ----
    r$market_survey$observeEvent[[id]] <- shiny::observeEvent(input$tabulator$edited, {
      log_info("observeEvent:", glue::glue("r$market_survey$observeEvent${id}"), level = 1)

      ## Get Edited data table row
      dt_data <- data.table::as.data.table(input$tabulator$data)
      dt_data[, PUBLICATION_DATE := as.Date(PUBLICATION_DATE)]
      dt_data[!shiny::isTruthy(COMM_TIMESTAMP), COMM_TIMESTAMP := NA_character_]

      dt_edited <- data.table::as.data.table(input$tabulator$edited)
      dt_data_edited <- dt_data[dt_edited$row]

      ## Helper function to normalize values for comparison
      normalize_value <- function(val) {
        if (is.null(val)) {
          return(NA)
        }
        if (length(val) == 0) {
          return(NA)
        }
        if (is.na(val)) {
          return(NA)
        }
        if (is.character(val) && trimws(val) %in% c("", "NA", "NULL", "null", "undefined")) {
          return(NA)
        }
        return(val)
      }

      ## Normalize values
      old_val <- normalize_value(dt_edited$old_value)
      new_val <- normalize_value(dt_edited$new_value)

      ## Check for meaningful change
      ## Skip if both are NA/empty (no actual change)
      both_empty <- is.na(old_val) && is.na(new_val)

      ## Skip if values are equal (convert to character for safe comparison across types)
      values_equal <- !is.na(old_val) &&
        !is.na(new_val) &&
        identical(as.character(old_val), as.character(new_val))

      shiny::req(!both_empty && !values_equal)

      ## Update EDITED = TRUE (this column is used in fct_market_survey_combine)
      dt_data_edited[, EDITED := TRUE]

      ## Capture new input
      r$market_survey$dt_input <- fct_market_survey_get_input(
        dt_data = dt_data_edited,
        dt_market_survey = r$market_survey$dt_market_survey,
        dt_input = r$market_survey$dt_input,
        dt_pricetype = argusDT.PriceStudioMain::dt_pricetype
      )

      log_change(paste(id, dt_edited$col), dt_edited$old_value, dt_edited$new_value, level = 2)

      gargoyle::trigger("market_survey_combine")
      gargoyle::trigger("market_survey_pivot")
      gargoyle::trigger(id_update)
      gargoyle::trigger(id_aggregation)
      gargoyle::trigger("get_market_survey_status")
    })

    # Cell click ----
    r$market_survey$observeEvent[[id_click]] <- shiny::observeEvent(input$tabulator_cellClick, {
      log_info("observeEvent:", glue::glue("r$market_survey$observeEvents${id_click}"), level = 2)

      # Columns *NOT* to copy from the last row
      cols <- c(
        "TRADER_ID",
        "PRICE_CATEGORY_ID",
        "COMM_CONTACT_NAME",
        "COMM_METHOD_ID",
        "COMM_TIMESTAMP",
        "COMM_TIMESTAMP_UTC",
        "COMM_REPORTER",
        "PORT_ID",
        "DELIVERY_PERIOD_ID",
        "DELIVERY_YEAR",
        "NOTES",
        "LOW",
        "HIGH",
        "MID",
        "INCLUDE",
        "DELETED"
      )

      dt <- data.table::as.data.table(input$tabulator_cellClick$data)
      dt[, PUBLICATION_DATE := as.Date(PUBLICATION_DATE)]
      dt_new_row <- dt[nrow(dt), .SD, .SDcols = -cols]

      if (dt_new_row$MARKET_SURVEY_ITEM_ID < 999) {
        dt_new_row[, `:=`(
          MARKET_SURVEY_ITEM_ID = MARKET_SURVEY_ITEM_ID + 1,
          ID = paste0(QPT_MID, sprintf("%03d", MARKET_SURVEY_ITEM_ID)),
          COMM_REPORTER = get_config("username"),
          UNIT_ID1 = UNIT_ID1,
          UNIT_ID2 = UNIT_ID2
        )]

        # Get default TRADER_ID if prefill switch is ON
        default_trader_id <- NA_integer_

        if (isTRUE(r$market_survey$prefill_company_switch)) {
          # Get QUOTE_ID from the new row data
          quote_id <- dt_new_row$QUOTE_ID

          if (length(quote_id) > 0 && !is.null(r$market_survey$dt_pivot)) {
            # Get most-used TRADER_ID for this quote
            default_trader_id <- fct_market_survey_get_default_company(
              dt_pivot = r$market_survey$dt_pivot,
              quote_id = quote_id
            )

            # Convert NULL to NA
            if (is.null(default_trader_id)) {
              default_trader_id <- NA_integer_
            }

            # Log if we're prefilling
            if (!is.na(default_trader_id)) {
              log_info(
                glue::glue("Prefilling TRADER_ID: {default_trader_id}"),
                level = 3
              )
            }
          }
        }

        dt_new_row[, `:=`(
          TRADER_ID = default_trader_id,
          PRICE_CATEGORY_ID = NA_integer_,
          COMM_CONTACT_NAME = NA_character_,
          COMM_METHOD_ID = NA_integer_,
          COMM_TIMESTAMP = NA_character_,
          COMM_TIMESTAMP_UTC = NA_character_,
          PORT_ID = NA_integer_,
          DELIVERY_PERIOD_ID = NA_integer_,
          DELIVERY_YEAR = NA_integer_,
          INCLUDE = TRUE,
          DELETED = FALSE,
          NOTES = NA_character_,
          LOW = NA_real_,
          HIGH = NA_real_,
          MID = NA_real_
        )]

        ## Update EDITED = FALSE (this column is used in fct_market_survey_combine)
        dt_new_row[, EDITED := FALSE]

        r$market_survey$dt_input <- fct_market_survey_get_input(
          dt_data = dt_new_row,
          dt_market_survey = r$market_survey$dt_market_survey,
          dt_input = r$market_survey$dt_input,
          dt_pricetype = argusDT.PriceStudioMain::dt_pricetype
        )

        gargoyle::trigger("market_survey_combine")
        gargoyle::trigger("market_survey_pivot")
        gargoyle::trigger(id_add)
        gargoyle::trigger(id_aggregation)
        gargoyle::trigger("get_market_survey_status")
      } else {
        log_warn(
          "You have reached the item limit.\n",
          "The table must have fewer than 1,000 rows.",
          prompt = TRUE,
          type = "warning",
          title = "Too many rows"
        )
      }
    })

    ## Update ----
    ### This observeEvent allows the individual table to be updated (but not
    ### redrawn)
    r$market_survey$observeEvent[[id_update]] <- shiny::observeEvent(
      gargoyle::watch(id_update),
      {
        log_info("observeEvent:", id_update, level = 1, session = session)

        shiny::req(
          r$market_survey$tabulator_ids,
          r$market_survey$tabulators,
          r$market_survey$market,
          r$market_survey$dt_pivot
        )

        dt <- r$market_survey$dt_pivot[QPT_MID == id]

        dt[, ID := paste0(QPT_MID, sprintf("%03d", MARKET_SURVEY_ITEM_ID))]

        argusDS.tabulator::tabulatorProxy("tabulator") %>% argusDS.tabulator::update_data(dt)
      },
      ignoreInit = TRUE
    )

    ## Show/hide notes ----
    ### This observeEvent allows the tabulators to show/hide Notes column
    r$market_survey$observeEvent[[id_notes]] <- shiny::observeEvent(
      gargoyle::watch("market_survey_show_hide_notes"),
      {
        log_info("observeEvent:", id_notes, level = 1, session = session)

        shiny::req(r$market_survey$tabulator_ids, r$market_survey$tabulators)

        if (r$market_survey$notes_switch) {
          r$market_survey$visible_columns[["NOTES"]] <- TRUE

          argusDS.tabulator::tabulatorProxy("tabulator") |> argusDS.tabulator::show_column("NOTES")
        } else {
          r$market_survey$visible_columns[["NOTES"]] <- FALSE

          argusDS.tabulator::tabulatorProxy("tabulator") |> argusDS.tabulator::hide_column("NOTES")
        }
      },
      ignoreInit = TRUE
    )

    ## Replace market ----
    ### This observeEvent allows the tabulators for the entire market section
    ## to be replaced (and redrawn)
    r$market_survey$observeEvent[[id_update_market]] <- shiny::observeEvent(
      gargoyle::watch("market_survey_replace"),
      {
        log_info("observeEvent:", "market_survey_replace", id, level = 1, session = session)

        shiny::req(
          r$market_survey$tabulator_ids,
          r$market_survey$tabulators,
          r$market_survey$market,
          r$market_survey$dt_pivot
        )

        dt <- r$market_survey$dt_pivot[QPT_MID == id]

        dt[, ID := paste0(QPT_MID, sprintf("%03d", MARKET_SURVEY_ITEM_ID))]

        argusDS.tabulator::tabulatorProxy("tabulator") %>% argusDS.tabulator::replace_data(dt)
      },
      ignoreInit = TRUE
    )

    ## Replace ----
    ### This observeEvent allows the data for each individual tabulator to be
    ### replaced (and redrawn)
    r$market_survey$observeEvent[[id_add]] <- shiny::observeEvent(
      gargoyle::watch(id_add),
      {
        log_info("observeEvent:", id_add, level = 1, session = session)

        shiny::req(
          r$market_survey$tabulator_ids,
          r$market_survey$tabulators,
          r$market_survey$market,
          r$market_survey$dt_pivot
        )

        dt <- r$market_survey$dt_pivot[QPT_MID == id]

        dt[, ID := paste0(QPT_MID, sprintf("%03d", MARKET_SURVEY_ITEM_ID))]

        argusDS.tabulator::tabulatorProxy("tabulator") %>% argusDS.tabulator::replace_data(dt)
      },
      ignoreInit = TRUE
    )

    ## Aggregations ----
    ### This observeEvent updates the aggregations above each tabulator
    r$market_survey$observeEvent[[id_aggregation]] <- shiny::observeEvent(
      gargoyle::watch(id_aggregation),
      {
        log_info("observeEvent:", id_aggregation, level = 1, session = session)

        shiny::req(
          r$market_survey$tabulator_ids,
          r$market_survey$tabulators,
          r$market_survey$market,
          r$market_survey$dt_pivot
        )

        dt <- r$market_survey$dt_pivot[QPT_MID == id & INCLUDE == TRUE]
        dt[is.na(MID), MID := (HIGH + LOW) / 2]
        values <- c(dt$HIGH, dt$MID, dt$LOW)

        suppressWarnings({
          min <- if (all(is.na(values))) NA_real_ else min(values, na.rm = TRUE)
          max <- if (all(is.na(values))) NA_real_ else max(values, na.rm = TRUE)
          avg <- if (all(is.na(values))) NA_real_ else mean(dt$MID, na.rm = TRUE)
          cou <- if (all(is.na(values))) NA_real_ else length(na.omit(dt$MID))
        })

        avg <- argus_round(avg, digits = 8)

        # fmt: table
        r$market_survey[[id_aggregation]] <- paste(
          "Count: " , cou , "| Avg: " , avg , "| Min:" , min , "| Max:" , max
        )
      }
    )
  }) # End of ModuleServer function
}
