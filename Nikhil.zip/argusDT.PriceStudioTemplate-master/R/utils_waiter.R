#' utils_waiter
#' @param text A text to show under the spinner.
#' @param spin_loader An integer representing the spinner type from the
#'   'waiter' package.
#' @description A utils function
#' @return The return value, if any, from executing the utility.
#' @noRd
utils_waiter <- function(text = "", spin_loader = 42) {
  htmltools::tagList(
    waiter::spin_loaders(spin_loader),
    htmltools::tags$br(),
    htmltools::tags$h6(text)
  )
}
