#' Calculate Expected Publication Dates
#' @description Calculates expected publication dates for all QUOTE_PRICETYPE_IDs
#' in data.table argument `dt`.
#' @param dt (Required) Prices data.table object
#' @param calendars (Required) calendars object
#' @return Prices data.table with new columns
fct_calc_expected_dates <- function(dt, calendars) {
  ## Alert user if there are dates with missing package and formulas
  dt_err <- unique(dt[is.na(PACKAGE) | is.na(DTE_FORMULA), .(MARKET, SECTION, QUOTE_ID)])

  dt_err <- dt_err[!is.na(MARKET) & !is.na(SECTION)]

  ## Raise the error only if the quote_id(s) have market(s) and section(s) associated.
  ## If both are NA then it is ok to skip the warning as it means the quote_id(s)
  ## are actually not in the PRC_MARKET_CONTENT table
  if (dt_err[, .N] > 0) {
    log_warn(
      "The following ",
      dt_err[, .N],
      " quote ID's are missing date formulas:\n",
      paste(unique(dt_err$QUOTE_ID), collapse = ", "),
      prompt = TRUE,
      title = "Missing Date Formulas"
    )
  }

  if (length(calendars) == 0) {
    dt[, HOLIDAY_KEY := "No Holidays"]
  }

  ## Create ARGS columns for each unique date, holiday key and display type to
  ## calculate expected publication dates
  dt_uniq_dts <- unique(dt[
    !is.na(PACKAGE) & !is.na(DTE_FORMULA),
    .(
      DTE_FORMULA,
      PUBLICATION_DATE,
      HOLIDAY_KEY,
      PACKAGE,
      DISPLAY_TYPE_ID,
      WEEKENDISHOLIDAY_YN,
      ARGS = do.call(paste, c(.SD, sep = '","'))
    ),
    .SDcols = c("PUBLICATION_DATE", "HOLIDAY_KEY", "DISPLAY_TYPE_ID")
  ])

  ## Create formula to calculate expected dates
  dt_uniq_dts[, DATE_FORMULA := paste0(PACKAGE, "::", DTE_FORMULA, '(args = c("', ARGS, '"))')]

  dt_uniq_dts[,
    EXPECTED_DATE := as.Date(
      sapply(X = DATE_FORMULA, FUN = function(x) {
        tryCatch(eval(parse(text = x)), error = function(e) {
          log_warn("Error in `", x, "`:", e$message)
          return(NA)
        })
      }),
      origin = "1970-01-01"
    )
  ]

  ## Alert user if any expected dates were not calculated
  dt_err <- dt_uniq_dts[is.na(EXPECTED_DATE)]

  if (nrow(dt_err) > 0) {
    log_warn(
      "The following date formulas contain errors:\n",
      paste(unique(dt_err$DATE_FORMULA), collapse = "\n"),
      prompt = TRUE,
      title = "Expected date not calculated"
    )
  }

  ## Add EXPECTED_DATE to main dt
  cols <- c(
    "DTE_FORMULA",
    "PUBLICATION_DATE",
    "HOLIDAY_KEY",
    "DISPLAY_TYPE_ID",
    "WEEKENDISHOLIDAY_YN"
  )

  dt[dt_uniq_dts, EXPECTED_DATE := i.EXPECTED_DATE, on = cols]

  ## Replace NA's with publication date if expected dates were not calculated
  dt[, EXPECTED_DATE := data.table::fifelse(is.na(EXPECTED_DATE), PUBLICATION_DATE, EXPECTED_DATE)]

  ## Flag the Latest available data with LATEST = TRUE flag
  dt[, LATEST_DATE := max(EXPECTED_DATE), by = QUOTE_PRICETYPE_ID]

  dt[, LATEST := (PUBLICATION_DATE == LATEST_DATE)]
}
