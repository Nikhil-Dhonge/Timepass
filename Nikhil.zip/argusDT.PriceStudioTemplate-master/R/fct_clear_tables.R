#' clear_ind_tables
#' @description remove the tables in the UI.
#' @param input The input object.
#' @param session The session object.
#' @param r The global environment variable 'r'.
#' @param displayed_tables displayed tables names
#'
#' @return Invisible NULL.
#' @noRd
fct_clear_tables <- function(input, session, r, displayed_tables) {
  ns <- session$ns

  log_info("fct_clear_tables:", get_ns(ns), level = 2)

  ### Removed tables displayed
  if (!is.null(displayed_tables)) {
    purrr::walk(
      .x = displayed_tables,
      .f = function(x, r) {
        id <- ns(x)

        ## Remove UI ----
        log_info("removeUI:", id, level = 3)

        shiny::removeUI(selector = paste0("#", id, "-text_output"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-tabulator"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-div"), immediate = TRUE)

        ## Remove inputs ----
        argusDT.PriceStudioMain::fct_remove_shiny_inputs(id = x, input, ns)

        ## Remove observeEvents
        if (!is.null(r$rv$observeEvent[[x]])) {
          r$rv$observeEvent[[x]]$destroy()
          r$rv$observeEvent[[x]] <- NULL
        }
      },
      r = r
    )
  }
}
