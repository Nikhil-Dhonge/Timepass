#' fct_render_tabulator_stg
#' Render `argusDS.tabulator` table for Staged Prices
#'
#' @description
#' `fct_render_tabulator_stg()` renders an `argusDS.tabulator` table with
#' customizable columns configuration parameters for Staged Prices.
#'
#' @param dt A data.table object to display in tabulator output.
#' @param visible_cols A list of columns to be displayed.
#' @param show_filters A logical object that controls whether filters will be shown in the
#' tabulator table or not. If not passed, it defaults to FALSE (filters not shown).
#'
#' @returns
#' The rendered `argusDS.tabulator` table.
#'
#' @export
#'
#' @family   argusDS.tabulator
#'
fct_render_tabulator_stg <- function(
  dt,
  visible_cols,
  show_filters = FALSE
) {
  log_info("fct_render_tabulator_stg", level = 5)

  # Column variables (alphabetical order) ----
  ## CF ----
  col_cf <- argusDS.tabulator::colDef(
    title = "CF",
    field = "CF",
    visible = visible_cols[["CF"]],
    headerFilter = show_filters,
    minWidth = 50,
    widthGrow = 0
  )

  ## CODE_DESCRIPTION ----
  col_code_description <- argusDS.tabulator::colDef(
    title = "Code Description",
    field = "CODE_DESCRIPTION",
    visible = visible_cols[["CODE_DESCRIPTION"]],
    headerFilter = show_filters,
    minWidth = 300
  )

  ## CODE_ID ----
  col_code_id <- argusDS.tabulator::colDef(
    title = "CODE ID",
    field = "CODE_ID",
    visible = visible_cols[["CODE_ID"]],
    headerFilter = show_filters
  )

  ## DBR ----
  col_dbr <- argusDS.tabulator::colDef(
    title = "New",
    field = "DBR",
    visible = visible_cols[["DBR"]],
    formatter = "compare",
    formatterParams = argusDS.tabulator::formatterParams(
      comparisonField = "OLD_DBR",
      mismatchClass = "cell-mismatch"
    )
  )

  ## FWD ----
  col_fwd <- argusDS.tabulator::colDef(
    title = "New",
    field = "FWD",
    visible = visible_cols[["FWD"]],
    formatter = "compare",
    formatterParams = argusDS.tabulator::formatterParams(
      comparisonField = "OLD_FWD",
      mismatchClass = "cell-mismatch"
    )
  )

  ## NOTES ----
  col_notes <- argusDS.tabulator::colDef(
    title = "New",
    field = "NOTES",
    visible = visible_cols[["NOTES"]],
    minWidth = 400,
    formatter = "compare",
    formatterParams = argusDS.tabulator::formatterParams(
      comparisonField = "OLD_NOTES",
      mismatchClass = "cell-mismatch"
    )
  )

  ## OLD_DBR ----
  col_old_dbr <- argusDS.tabulator::colDef(
    title = "Old",
    field = "OLD_DBR",
    visible = visible_cols[["OLD_DBR"]],
    headerFilter = show_filters
  )

  ## OLD_FWD ----
  col_old_fwd <- argusDS.tabulator::colDef(
    title = "Old",
    field = "OLD_FWD",
    visible = visible_cols[["OLD_FWD"]],
    headerFilter = show_filters
  )

  ## OLD_NOTES ----
  col_old_notes <- argusDS.tabulator::colDef(
    title = "Old",
    field = "OLD_NOTES",
    visible = visible_cols[["OLD_NOTES"]],
    minWidth = 400
  )

  ## OLD_VALUE ----
  col_old_value <- argusDS.tabulator::colDef(
    title = "Old",
    field = "OLD_VALUE",
    visible = visible_cols[["OLD_VALUE"]]
  )

  ## OLD_YEAR ----
  col_old_year <- argusDS.tabulator::colDef(
    title = "Old",
    field = "OLD_YEAR",
    visible = visible_cols[["OLD_YEAR"]]
  )

  ## PT ----
  col_pt <- argusDS.tabulator::colDef(
    title = "PT",
    field = "PT",
    visible = visible_cols[["PT"]],
    headerFilter = show_filters,
    minWidth = 50,
    widthGrow = 0
  )

  ## PUBLICATION_DATE ----
  col_publication_date <- argusDS.tabulator::colDef(
    title = "Date",
    field = "PUBLICATION_DATE",
    visible = visible_cols[["PUBLICATION_DATE"]],
    headerFilter = show_filters
  )

  ## TS ----
  col_ts <- argusDS.tabulator::colDef(
    title = "TS",
    field = "TS",
    visible = visible_cols[["TS"]],
    headerFilter = show_filters,
    minWidth = 50,
    widthGrow = 0
  )

  ## VALUE ----
  col_value <- argusDS.tabulator::colDef(
    title = "New",
    field = "VALUE",
    visible = visible_cols[["VALUE"]],
    formatter = "compare",
    formatterParams = argusDS.tabulator::formatterParams(
      comparisonField = "OLD_VALUE",
      mismatchClass = "cell-mismatch"
    )
  )

  ## YEAR ----
  col_year <- argusDS.tabulator::colDef(
    title = "New",
    field = "YEAR",
    visible = visible_cols[["YEAR"]],
    formatter = "compare",
    formatterParams = argusDS.tabulator::formatterParams(
      comparisonField = "OLD_YEAR",
      mismatchClass = "cell-mismatch"
    )
  )

  # Default Column ----
  col_default <- argusDS.tabulator::colDef(
    title = "",
    field = "",
    headerHozAlign = "center",
    headerTooltip = TRUE,
    headerFilter = if (show_filters) "input" else FALSE,
    headerSort = FALSE,
    hozAlign = "center",
    minWidth = 100,
    widthGrow = 1,
    frozen = FALSE
  )

  # Render table ----
  argusDS.tabulator::tabulator(
    data = dt,
    layout = "fitColumns",
    autoColumns = FALSE,
    index = "ID",
    history = TRUE,
    height = "100%",
    pagination = TRUE,
    paginationSize = 50,
    paginationSizeSelector = c(10, 20, 50, 100),
    headerSort = FALSE,
    columnDefaults = col_default,
    placeholder = "No data available",
    columns = list(
      col_publication_date,
      col_ts,
      col_cf,
      col_pt,
      col_code_id,
      col_code_description,
      argusDS.tabulator::colDef(
        title = "Value",
        columns = list(
          col_old_value,
          col_value
        )
      ),
      argusDS.tabulator::colDef(
        title = "Fwd",
        columns = list(
          col_old_fwd,
          col_fwd
        )
      ),
      argusDS.tabulator::colDef(
        title = "Year",
        columns = list(
          col_old_year,
          col_year
        )
      ),
      argusDS.tabulator::colDef(
        title = "Dbr",
        columns = list(
          col_old_dbr,
          col_dbr
        )
      ),
      argusDS.tabulator::colDef(
        title = "Notes",
        columns = list(
          col_old_notes,
          col_notes
        )
      )
    )
  )
}
