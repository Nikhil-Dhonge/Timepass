#' forex_tab UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_forex_tab_ui <- function(id) {
  ns <- NS(id)

  shiny::tagList(
    htmltools::tags$div(
      id = ns("tabulator_forex-div"),
      style = "overflow-x: auto; padding-top: 0.5rem;",
      class = "main-box",

      argusDS.tabulator::tabulatorOutput(
        outputId = ns("tabulator_forex"),
        height = "100%",
        width = "auto"
      ),

      shinyjs::hidden(
        htmltools::tags$div(
          id = ns("error_message_forex"),
          htmltools::tags$h5("No exchange rates values available for today.")
        )
      )
    )
  )
}

#' forex_tab Server Functions
#'
#' @noRd
mod_forex_tab_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    ## Add tabulator table in Forex tab
    output$tabulator_forex <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator_forex"), level = 4)

      if (!is.null(r$rv$dt_exrates)) {
        shinyjs::hide("error_message_forex")

        r$rv$dt_exrates[,
          .SD,
          .SDcols = c(
            "RATE",
            "RATE_DATE",
            "VALUE",
            "TIMING",
            "CONTINUOUS_FORWARD",
            "EX_TIME_CODE",
            "EQUATION"
          )
        ] %>%
          argusDT.PriceStudioMain::fct_render_tabulator_auto(paginationsize = 50)
      } else {
        shinyjs::show("error_message_forex")
      }
    })
  })
}
