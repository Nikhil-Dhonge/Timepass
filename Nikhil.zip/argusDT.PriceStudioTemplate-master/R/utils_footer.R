#' utils_footer
#' @description A utils function
#' @return The return value, if any, from executing the utility.
#' @noRd
utils_footer <- function() {
  log_info("utils_footer", level = 1)

  shiny::tagList(
    htmltools::tags$div(
      class = "footer-container",

      htmltools::tags$span(
        class = "footer-leftside",

        # Copyright ----
        htmltools::tags$i(
          class = "footer-title",
          paste0(
            "\u00a9 ",
            lubridate::year(Sys.Date()),
            " Argus Media group. All rights reserved. "
          )
        ),

        # Process ----
        htmltools::tags$i(
          class = "footer-title",
          paste0("Process: ", get_config("pid"))
        ),

        # Session ----
        htmltools::tags$i(
          class = "footer-title",
          id = "footer-session",
          paste0("Session: ")
        ),

        # App version ----
        htmltools::tags$i(
          class = "footer-title",
          paste(
            "",
            paste0("A: ", golem::get_golem_version()),
            paste0("M: ", utils::packageVersion("argusDT.PriceStudioMain")),
            paste0("F: ", utils::packageVersion("argusDT.PriceStudioFormulas")),
            "",
            sep = " | "
          )
        ),

        # Report date ----
        htmltools::tags$i(
          class = "footer-title",
          id = "footer-report_date_tz",
          paste0("Report Date: ")
        )
      ),

      htmltools::tags$span(
        class = "footer-rightside",

        htmltools::tags$a(
          class = "footer-link",
          "www.argusmedia.com",
          href = "https://www.argusmedia.com/",
          target = "_blank", # attribute to open link in a new tab
        )
      )
    ),
    htmltools::tags$div(
      class = "phantom-input",
      shiny::HTML(
        '<input type="text" id="autofill-this" style="position: absolute; z-index: -1; top: 20px; width: 0; height:0" />'
      )
    )
  )
}
