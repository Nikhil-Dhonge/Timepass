#' Get Default Company (TRADER_ID) for Market Survey Table
#'
#' @description
#' Determines the default TRADER_ID (company) to use when adding new rows to a Market Survey table.
#' Logic:
#' - If no TRADER_ID values exist in the table → return NULL (blank)
#' - If TRADER_IDs exist → return the most frequently used TRADER_ID
#' - If tie for most used → return the lowest TRADER_ID numerically
#'
#' @param dt_pivot data.table containing the pivoted market survey data
#' @param quote_id character The QUOTE_ID for the table
#'
#' @return
#' integer TRADER_ID to use as default, or NULL if no default should be used
#'
#' @export
#'
#' @family market survey
#'
fct_market_survey_get_default_company <- function(dt_pivot, quote_id) {
  # Return NULL if no data
  if (is.null(dt_pivot) || nrow(dt_pivot) == 0) {
    return(NULL)
  }

  # Filter to this table only
  dt_table <- dt_pivot[QUOTE_ID == quote_id]

  # Return NULL if no rows
  if (nrow(dt_table) == 0) {
    return(NULL)
  }

  # Get all non-empty TRADER_ID values
  trader_ids <- dt_table[!is.na(TRADER_ID) & TRADER_ID != "", TRADER_ID]

  # If no traders selected yet, return NULL
  if (length(trader_ids) == 0) {
    return(NULL)
  }

  # Count frequency of each TRADER_ID
  trader_counts <- table(trader_ids)

  # Get the maximum count
  max_count <- max(trader_counts)

  # Get all TRADER_IDs with max count
  most_used <- as.integer(names(trader_counts[trader_counts == max_count]))

  # If tie, sort numerically and take first (lowest ID)
  if (length(most_used) > 1) {
    most_used <- sort(most_used)
  }

  # Return the first (or only) most used TRADER_ID
  return(most_used[1])
}
