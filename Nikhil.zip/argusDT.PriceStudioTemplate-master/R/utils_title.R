#' utils_title
#' @description A utils function
#' @return The return value, if any, from executing the utility.
#' @noRd
utils_title <- function() {
  log_info("utils_title", level = 1)

  shiny::tagList(
    ## Argus logo
    htmltools::tags$span(
      class = "dashboard-logo",
      htmltools::tags$img(
        src = "https://www.argusmedia.com/images/argus-logo.png",
        height = "30px"
      )
    ),

    ## Publication
    htmltools::tags$span(
      class = "dashboard-title",
      gsub("^Argus ", "", golem::get_golem_options("subtitle"))
    )
  )
}
