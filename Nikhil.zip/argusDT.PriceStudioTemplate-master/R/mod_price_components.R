#' Price Components UI Function
#' @description A shiny Module.
#' @param id,input,output,session Internal parameters for {shiny}.
#' @noRd
mod_price_components_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_price_components_ui ns:", get_ns(ns), level = 2)

  htmltools::tagList(
    bslib::layout_columns(
      class = "main-nav",
      col_widths = 12,
      row_heights = list("auto", 1),

      bslib::layout_columns(
        col_widths = c(9, 3),
        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,
          bslib::layout_columns(
            col_widths = c(5, -1, 3, 3),

            ### Select market consisting of price components ----
            argusDT.PriceStudioMain::mod_pickerinput_ui(
              id = ns("price_components_market"),
              label = NULL,
              choices = "",
              options = list(title = "Select market..."),
              disabled_msg = "Select region first..."
            ),

            ### Refresh button to fetch price components ----
            argusDT.PriceStudioMain::mod_actionbutton_ui(
              id = ns("refresh_data"),
              label = "Refresh Data",
              disabled_msg = "Select a market first...",
              icon = shiny::icon("refresh", lib = "glyphicon"),
              style = "font-size: 16px"
            ),

            ### Download price components CSV ---
            mod_price_components_dwnld_csv_ui(
              id = ns("price_components_file"),
              label = "Download price components",
              icon = shiny::icon("download", lib = "glyphicon"),
              disabled_msg = "select market..."
            )
          )
        ),

        ### status box(waiter) ---
        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,
          id = ns("status-box")
        )
      ),

      ### Price component tabs---
      htmltools::tagList(
        htmltools::tags$div(
          shinyjs::hidden(
            htmltools::tags$div(
              class = "main-box",
              id = ns("error_message_prices"),
              htmltools::tags$h5("No price components available for today.")
            )
          ),
        ),

        htmltools::tags$div(
          class = "main-nav",
          bslib::navset_tab(
            id = ns("price_components_tabs")
          )
        )
      )
    )
  )
}

#' Price Components Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_price_components_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_price_components_server:", get_ns(ns), level = 2)

    ### market picker ---
    argusDT.PriceStudioMain::mod_pickerinput_server(
      id = "price_components_market",
      rv = r$rv,
      choices_rv = "price_components_markets",
      enable_trigger = "price_components_enable_market",
      disable_trigger = "price_components_disable_market"
    )

    ### Refresh button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "refresh_data",
      triggers = c("destroy_price_components_tabulators", "refresh_price_components"),
      enable_trigger = "price_components_enable_market",
      disable_trigger = "price_components_disable_market"
    )

    ## Change region ----
    ### When region picker input is updated, update market list and reset some
    ### global variables
    shiny::observeEvent(r$rv$region, {
      log_info("observeEvent-price components:", "r$rv$region", level = 2)

      r$rv$price_components_market <- NULL

      r$rv$price_components_markets <- sort(unique(
        r$rv$dt_market_content[DISPLAY_YN == "Y" & REGION == r$rv$region]$MARKET
      ))

      if (is_truthy(r$rv$price_components_markets)) {
        gargoyle::trigger("price_components_enable_market")
      }
    })

    ### call triggers to fetch price components from S3 ---
    shiny::observeEvent(
      r$rv$price_components_market,
      {
        log_info("observeEvent:", "r$rv$price_components_market", level = 2)

        gargoyle::trigger("destroy_price_components_tabulators")
        gargoyle::trigger("refresh_price_components")
      },
      ignoreInit = TRUE
    )

    ### fetch price components from S3 ---
    shiny::observeEvent(
      gargoyle::watch("refresh_price_components"),
      {
        log_info("observeEvent:", "refresh_price_components", level = 1)

        r$rv$price_components_dt <- NULL
        r$rv$price_components_dt_filenames <- NULL

        shiny::req(r$rv$price_components_market)

        ### Price components csv path S3 for selected market ---
        r$rv$s3_price_components_dir <- file.path(
          r$rv$s3_price_components_base_dir,
          tolower(gsub(" ", "_", r$rv$price_components_market))
        )

        r$rv$price_components_dt_filenames <- argusDT.S3::s3_get_bucket_dt(
          bucket = get_config("s3_bucket"),
          prefix = file.path(r$rv$s3_price_components_dir)
        )

        ### select price components csv
        r$rv$price_components_dt_filenames <- r$rv$price_components_dt_filenames[grepl(
          "price_components_final.csv",
          Key,
          ignore.case = TRUE
        )]

        ### read price components CSV ----
        if (nrow(r$rv$price_components_dt_filenames) > 0) {
          filename <- r$rv$price_components_dt_filenames[,
            filenames := data.table::tstrsplit(Key, "/", keep = 7)
          ][which.max(LastModified), filenames]

          r$rv$price_components_dt <- argusDT.S3::s3_read_using(
            FUN = data.table::fread,
            object = file.path(r$rv$s3_price_components_dir, filename),
            bucket = get_config("s3_bucket")
          )

          ### create price components tables grouped by formula/QPT ---
          r$rv$price_components_dt <- fct_create_price_components_tbls(
            price_components_dt = r$rv$price_components_dt,
            dt_prc_asmp = r$rv$dt_prc_asmp
          )
        }

        ### enable price components csv download ---
        if (is_truthy(r$rv$price_components_dt)) {
          gargoyle::trigger("price_components_enable_dwnld")
        } else {
          gargoyle::trigger("price_components_disable_dwnld")
        }

        ### price components download server ---
        mod_price_components_dwnld_csv_server(
          id = "price_components_file",
          filename = paste0(
            format(r$rv$report_date, "%Y%m%d"),
            "_",
            r$rv$price_components_market,
            "_price_components"
          ),
          dt = r$rv$price_components_dt,
          enable_trigger = "price_components_enable_dwnld",
          disable_trigger = "price_components_disable_dwnld",
          r = r
        )

        gargoyle::trigger("show_price_components_tbls")
      },
      ignoreInit = TRUE
    )

    ### render tabulator to show price components ----
    shiny::observeEvent(
      gargoyle::watch("show_price_components_tbls"),
      {
        log_info("observeEvent:", "show_price_components_tbls", level = 1)

        r$rv$price_components_tabs <- gsub("\\W", "_", paste(names(r$rv$price_components_dt)))

        ### dynamically create price components tabs ---
        if (is_truthy(r$rv$price_components_tabs)) {
          shinyjs::hide("error_message_prices")

          purrr::walk2(
            .x = ns(r$rv$price_components_tabs),
            .y = names(r$rv$price_components_dt),
            .f = mod_price_components_tabs_ui,
            navset_tab_id = "price_components_tabs",
            session = session
          )

          purrr::walk2(
            .x = r$rv$price_components_tabs,
            .y = r$rv$price_components_dt,
            .f = mod_price_components_tabs_server,
            r = r
          )

          r$rv$price_components_prevtabs <- r$rv$price_components_tabs
        } else {
          shinyjs::show("error_message_prices")
        }
      },
      ignoreInit = TRUE
    )

    shiny::observeEvent(
      gargoyle::watch("destroy_price_components_tabulators"),
      {
        log_info("observeEvent:", "destroy_price_components_tabulators", level = 1)

        ### destroy previously created price components tabs and tabulator---
        if (length(r$rv$price_components_prevtabs) > 0) {
          purrr::walk(.x = r$rv$price_components_prevtabs, .f = function(x) {
            id_nav_panel <- paste0(ns(x), "-nav_panel")
            bslib::nav_remove(
              target = id_nav_panel,
              id = "price_components_tabs",
              session = session
            )
            shiny::removeUI(selector = paste0("#", ns(x), "-div"), immediate = TRUE)
            shiny::removeUI(selector = paste0("#", ns(x), "-tabulator"), immediate = TRUE)
          })
        }
      },
      ignoreInit = TRUE
    )
  })
}
