#' mod_market_survey_tab_ui
#' @description A shiny Module inserting a nav panel into a nav set.
#' @param id,session Internal parameters for {shiny}
#' @param title character string for the nav tab title
#' @param navset_tab_id character string used to identify the nav container
#' @return nav_panel UI element inserted into `navset_tab_id`
mod_market_survey_tab_ui <- function(
  id,
  title,
  navset_tab_id,
  session = shiny::getDefaultReactiveDomain()
) {
  ns <- shiny::NS(id)

  log_info("mod_market_survey_tab_ui ns:", get_ns(ns), level = 3)

  id_nav_panel <- ns("nav_panel")
  id_div <- ns("nav_panel-div")

  log_info("nav panel ID: ", id_nav_panel, level = 4)

  bslib::nav_insert(
    id = navset_tab_id,
    position = "before",
    select = TRUE,
    session = session,

    nav = bslib::nav_panel(
      id = id_nav_panel,
      title = title,
      value = id_nav_panel,
      bslib::layout_columns(
        col_widths = 12,
        min_height = "65vh",
        htmltools::tags$div(
          id = id_div,
          class = "main-box"
        )
      )
    )
  )
}

#' mod_market_survey_tab_server
#' @param id A shiny id.
#' @param section section to filter the data.table
#' @param r The global environment variable 'r'.
mod_market_survey_tab_server <- function(id, section, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_market_survey_tab_server ns:", get_ns(ns), level = 3)

    fct_market_survey_show_tabulator(
      input,
      session,
      r,
      market = r$market_survey$market,
      section = section,
      box_id = "nav_panel-div"
    )
  })
}
