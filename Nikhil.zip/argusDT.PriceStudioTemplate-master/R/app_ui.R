#' The application User-Interface
#' @param request Internal parameter for `{shiny}`.
#' @noRd
app_ui <- function(request) {
  log_info("app_ui", level = 0)

  # Create app UI
  htmltools::tagList(
    # External resources ----
    golem_add_external_resources(),

    # UI components ----
    ## Navbar ----
    bslib::page_navbar(
      id = "navbar",
      title = utils_title(),
      footer = utils_footer(),
      theme = utils_theme(),
      window_title = golem::get_golem_options("subtitle"),
      navbar_options = bslib::navbar_options(
        position = "static-top",
        bg = "#333333",
        theme = "light"
      ),

      ### Input prices ----
      if (get_config("show_tab_price_input")) {
        bslib::nav_panel(
          title = "Price Input",
          mod_inputprices_ui(id = "input_prices")
        )
      },

      ### Prices summary ----
      if (get_config("show_tab_price_input")) {
        bslib::nav_panel(
          title = "Price Summary",
          mod_summary_ui(id = "summary")
        )
      },

      ### Market Survey ----
      if (get_config("show_tab_market_survey")) {
        bslib::nav_panel(
          title = "Market Survey",
          mod_market_survey_ui(id = "market_survey")
        )
      },

      ### Indesign ----
      if (get_config("show_tab_indesign")) {
        bslib::nav_panel(
          title = "In Design",
          mod_indesign_ui(id = "indesign")
        )
      },

      ### Admin ----
      if (get_config("show_tab_admin")) {
        bslib::nav_panel(
          title = "Admin",
          mod_admin_ui(id = "admin")
        )
      },

      ### Add Price Components module only when needed ----
      if (get_config("show_tab_price_components")) {
        bslib::nav_panel(
          title = "Price Components",
          mod_price_components_ui(id = "price_components")
        )
      },

      ### Toolbar ----
      bslib::nav_item(
        class = "toolbar",

        #### Report date ----
        shiny::textOutput(outputId = "report_date", inline = TRUE) |>
          shiny::tagAppendAttributes(class = "toolbar-report_date"),

        #### Database environment ----
        shiny::textOutput(outputId = "db_env", inline = TRUE) |>
          shiny::tagAppendAttributes(class = "toolbar-db_env"),

        #### Region picker input ----
        shiny::span("Region:"),
        argusDT.PriceStudioMain::mod_selectizeinput_ui(
          id = "region",
          label = NULL,
          choices = c("Select region" = "", golem::get_golem_options("regions")),
          selected = golem::get_golem_options("region"),
          width = "140px"
        ),

        #### Settings button ----
        shinyWidgets::dropdownButton(
          circle = FALSE,
          size = "xs",
          icon = shiny::icon("cog", lib = "glyphicon"),
          right = TRUE,
          width = "44rem",
          mod_settings_ui(id = "settings")
        ),

        #### Feedback icon ----
        shiny::actionButton(
          inputId = "feedback_ui",
          label = NULL,
          class = "btn-toolbar",
          width = "35.6094px",
          icon = shiny::icon("comment")
        ),

        #### Help icon ----
        shiny::actionButton(
          inputId = "help_ui",
          label = NULL,
          class = "btn-toolbar",
          width = "35.6094px",
          icon = shiny::icon("question")
        )
      )
    )
  )
}


#' Add external Resources to the Application
#' This function is internally used to add external resources inside the Shiny
#' application.
#' @noRd
golem_add_external_resources <- function(app_title = golem::get_golem_options("subtitle")) {
  log_info("add external resources", level = 1)

  # Add external resource paths
  golem::add_resource_path("www", app_sys("app/www"))
  golem::add_resource_path("img", app_sys("app/img"))

  htmltools::tags$head(
    # Add winbox dependencies
    winboxr::use_winbox(),

    # Add waiter dependencies
    waiter::useWaiter(),

    # Activate use of shinyjs:: functions
    shinyjs::useShinyjs(),

    # Add icon for browser tab
    golem::favicon(ico = "favicon", ext = "ico"),

    # Define HTML dependencies (i.e. CSS and/or JavaScript in inst/app/www)
    golem::bundle_resources(
      path = app_sys("app/www"),
      app_title = app_title
    )
  )
}
