#' Truthy and falsy values (imported from `shiny::isTruthy`)
#'
#' @description
#' The terms "truthy" and "falsy" generally indicate whether a value, when
#' coerced to a [base::logical()], is `TRUE` or `FALSE`. We use
#' the term a little loosely here; our usage tries to match the intuitive
#' notions of "Is this value missing or available?", or "Has the user provided
#' an answer?", or in the case of action buttons, "Has the button been
#' clicked?".
#'
#' @details
#' For example, a `textInput` that has not been filled out by the user has
#' a value of `""`, so that is considered a falsy value.
#'
#' To be precise, a value is truthy *unless* it is one of:
#' * `FALSE`
#' * `NULL`
#' * `""`
#' * An empty atomic vector
#' * An atomic vector that contains only missing values
#' * A logical vector that contains all `FALSE` or missing values
#' * An object of class `"try-error"`
#' * A value that represents an unclicked [actionButton()]
#'
#' Note in particular that the value `0` is considered truthy, even though
#' `as.logical(0)` is `FALSE`.
#'
#' @param x An expression whose truthiness value we want to determine.
#'
#' @returns A single `TRUE` or `FALSE` value.
#'
#' @keywords internal
#'
#' @family utility functions
#'
#' @examples
#' \dontrun{
#' is_truthy(TRUE)                # returns TRUE
#' is_truthy(FALSE)               # returns FALSE
#' is_truthy(NULL)                # returns FALSE
#' is_truthy("")                  # returns FALSE
#' is_truthy("Hello")             # returns TRUE
#' is_truthy(0)                   # returns TRUE
#' is_truthy(1:5)                 # returns TRUE
#' is_truthy(numeric(0))          # returns FALSE
#' is_truthy(c(NA, NA))           # returns FALSE
#' is_truthy(c(FALSE, NA))        # returns FALSE
#' is_truthy(c(TRUE, FALSE))      # returns TRUE
#' is_truthy(try(stop("error")))  # returns FALSE
#' }
#'
is_truthy <- function(x) {
  if (is.null(x)) {
    return(FALSE)
  }
  if (inherits(x, 'try-error')) {
    return(FALSE)
  }
  if (!is.atomic(x)) {
    return(TRUE)
  }
  if (is.null(x)) {
    return(FALSE)
  }
  if (length(x) == 0) {
    return(FALSE)
  }
  if (all(is.na(x))) {
    return(FALSE)
  }
  if (is.character(x) && !any(nzchar(stats::na.omit(x)))) {
    return(FALSE)
  }
  if (inherits(x, 'shinyActionButtonValue') && x == 0) {
    return(FALSE)
  }
  if (is.logical(x) && !any(stats::na.omit(x))) {
    return(FALSE)
  }

  return(TRUE)
}


#' Argus Rounding of Numbers with Optional Multiple
#'
#' @description
#' Rounds a numeric vector with enhanced precision, and allows rounding
#' to the specified multiple.
#'
#' @param x numeric vector to be rounded.
#' @param digits number of decimal places to round to (default is 0).
#' @param multiple Optional numeric value to round to the nearest multiple.
#'
#' @returns A numeric vector rounded according to Argus rounding rules.
#'
#' @keywords internal
#'
#' @family utility functions
#'
#' @examples
#' \dontrun{
#' # Standard rounding to nearest integer
#' argus_round(c(2.3, 2.5, 2.7))  # returns c(2, 3, 3)
#' # Rounding to 1 decimal place
#' argus_round(c(2.34, 2.35, 2.36), digits = 1)  # returns c(2.3, 2.4, 2.4)
#' # Rounding to nearest multiple of 5
#' argus_round(c(12, 13, 14, 15, 16), multiple = 5)  # returns c(10, 15, 15, 15, 15)
#' # Rounding to nearest multiple of 0.1
#' argus_round(c(2.34, 2.35, 2.36), multiple = 0.1)  # returns c(2.3, 2.4, 2.4)
#' # Invalid combination of digits and multiple
#' argus_round(2.5, digits = 1, multiple = 5)  # returns NA with warning
#' # Invalid multiple of zero
#' argus_round(2.5, multiple = 0)  # returns NA with warning
#' }
#'
argus_round <- function(x, digits = 0, multiple = NA_real_) {
  # Check digits and multiple are compatible
  if (!is.na(multiple) & any(digits != 0)) {
    log_warn("argus_round must have `digits` = 0 if a multiple is supplied")
    return(NA_real_)
  }

  # Special case: If multiple is zero, return NA
  if (!is.na(multiple) & multiple == 0) {
    log_warn("`multiple` cannot be 0")
    return(NA_real_)
  }

  # Round to the nearest multiple if multiple is not 1
  if (!is.na(multiple)) {
    posneg <- sign(x)
    x <- abs(x)
    x <- x / multiple
    x <- trunc(x + 0.5 + sqrt(.Machine$double.eps)) * multiple
    return(x * posneg)
  } else {
    posneg <- sign(x)
    x <- abs(x) * 10^digits
    x <- x + 0.5 + sqrt(.Machine$double.eps)
    x <- trunc(x)
    x <- x / 10^digits
    return(x * posneg)
  }
}


#' Raise and log a message
#'
#' @description
#' Raise a message to the console and the log file.
#'
#' @param level number of times to indent the log message.
#' @param session session object for the session variables.
#' @inheritParams base::paste
#' @inheritDotParams base::paste
#'
#' @section Details:
#' Prints a message to the console or the log file including the parts below,
#' if applicable:
#' * time stamp
#' * process id
#' * session id
#' * username
#' * custom message
#'
#' The `level` parameter allows for hierarchical logging by
#' indenting messages with dashes.
#'
#' @returns NULL invisibly.
#'
#' @keywords internal
#'
#' @family logging functions
#'
#' @examples
#' \dontrun{
#' log_info("This is an info message.")
#' log_info("This is an indented message.", level = 2)
#' }
#'
log_info <- function(
  ...,
  sep = " ",
  collapse = NULL,
  level = 0,
  session = shiny::getDefaultReactiveDomain()
) {
  # add dashes based on log level
  level <- level * 2
  indent <- paste0(rep("-", times = level), collapse = "")

  # build message string
  msg <- paste(..., sep = sep, collapse = collapse)
  msg <- paste(indent, msg, "\n")

  # retrieve session variables
  username <- ifnull(session$userData$username, character(1))
  username <- paste0("u:", stringr::str_pad(username, 20, side = "right"))
  process_id <- ifnull(session$userData$pid, Sys.getpid())
  process_id <- paste0("p:", stringr::str_pad(process_id, 7, side = "left"))
  session_id <- ifnull(session$userData$sid, "----")
  session_id <- paste0("s:", stringr::str_pad(session_id, 4, side = "left"))

  # build timestamp string
  timestamp <- paste0(Sys.time())

  paste(timestamp, process_id, session_id, username, msg, sep = " | ") |>
    message(appendLF = FALSE)

  return(invisible(NULL))
}


#' Raise and log a warning
#'
#' @description
#' Raise a warning message to the console and the log file, with
#' the option to raise a shinyalert for Shiny applications.
#'
#' @param prompt logical to show a `shinyalert::shinyalert()`. Ignored if not
#' called from a Shiny application.
#' @inheritParams shinyalert::shinyalert
#' @inheritParams base::paste
#' @inheritParams log_info
#' @inheritDotParams base::paste
#'
#' @returns The warning message as character string, invisibly.
#'
#' @keywords internal
#'
#' @family logging functions
#'
#' @examples
#' \dontrun{
#' log_warn("This is a warning message.")
#' log_warn("This is a warning message with a prompt.", prompt = TRUE, title = "Warning!")
#' }
#'
log_warn <- function(
  ...,
  sep = " ",
  collapse = NULL,
  prompt = FALSE,
  title = NULL,
  showCancelButton = FALSE,
  type = "error",
  inputId = "shinyalert",
  session = shiny::getDefaultReactiveDomain()
) {
  # build message string
  msg <- paste(..., sep = sep, collapse = collapse)
  msg <- stringr::str_trim(msg)

  # retrieve session variables
  username <- paste0("user:", ifnull(session$userData$username, NA_character_))
  process_id <- paste0("process:", ifnull(session$userData$pid, Sys.getpid()))
  session_id <- paste0("session:", ifnull(session$userData$sid, NA_character_))
  version_app <- paste0("A: v", session$userData$version_app)
  version_main <- paste0("M: v", session$userData$version_main)
  version_formulas <- paste0("F: v", session$userData$version_formulas)
  application_id <- paste0("app:", ifnull(session$userData$application_id, NA_character_))

  session_info <- paste(
    application_id,
    process_id,
    session_id,
    username,
    version_app,
    version_main,
    version_formulas,
    sep = ", "
  )

  # Show shinyalert only if in Shiny app and prompt is TRUE
  if (
    !rlang::is_installed("shinyalert") |
      !shiny::isRunning() |
      is.null(session) |
      is.null(title) |
      length(msg) == 0 |
      prompt == FALSE
  ) {
    return(warning(paste0(msg, " (", session_info, ")"), call. = FALSE))
  }

  # Build alert message
  email <- paste0("mailto:", ifnull(session$userData$feedback_email, character(1)))

  text <- paste0(
    shiny::tags$pre(shiny::tags$h5(msg), class = "sweet-alert-msg"),
    shiny::tags$sup(shiny::tags$i(session_info))
  )

  # Add prompt to email data team for errors and warnings
  if (type %in% c("error", "warning")) {
    text <- paste0(
      htmltools::tags$h5(
        "Please send a screen grab of this pop-up to",
        htmltools::tags$a(href = email, "Data team"),
        ":"
      ),
      text
    )
  }

  text <- paste0(shiny::tags$div(shiny::HTML(text), class = "sweet-alert-body"))

  shinyalert::shinyalert(
    title = title,
    text = text,
    type = type,
    html = TRUE,
    confirmButtonCol = "#0d569b",
    showCancelButton = showCancelButton,
    inputId = inputId,
    size = "s",
    session = session
  )

  return(warning(paste0(msg, " (", session_info, ")"), call. = FALSE))
}


#' Raise and log a change
#'
#' @description
#' Raise a message to the console and the log file, highlighting the object
#' and value that has changed.
#'
#' @param id object id.
#' @param from original value.
#' @param to new value.
#' @inheritParams log_info
#' @inheritSection log_info Details
#'
#' @returns A message as character string, invisibly.
#'
#' @keywords internal
#'
#' @family logging functions
#'
#' @examples
#' \dontrun{
#' log_change("input$age", 25, 30)
#' log_change("input$age", 25, 30, level = 3)
#' }
#'
log_change <- function(id, from, to, level = 2, session = shiny::getDefaultReactiveDomain()) {
  log_info("change `", id, "` from ", from, " to ", to, level = level, session = session)
}


#' Get namespace designation
#'
#' @param ns Namespace function object.
#'
#' @returns A character object with namespace designation.
#'
#' @keywords internal
#'
#' @family utility functions
#'
#' @examples
#' \dontrun{
#' ns <- shiny::NS("my_module")
#' get_ns(ns)  # returns "my_module"
#' }
#'
get_ns <- function(ns) {
  if (!inherits(ns, "function")) {
    stop("argument 'ns' is not a function.")
  }

  environment(ns)[["namespace"]]
}


#' Replace NULL with another value
#'
#' @param x Object to check for NULL.
#' @param y Replacement value if x is NULL.
#'
#' @returns x if not NULL, otherwise y.
#'
#' @keywords internal
#'
#' @family utility functions
#'
#' @examples
#' \dontrun{
#' ifnull(NULL, 5)       # returns 5
#' ifnull(10, 5)         # returns 10
#' ifnull(NA, "default") # returns NA
#' }
#'
ifnull <- function(x, y) {
  if (is.null(x)) y else x
}
