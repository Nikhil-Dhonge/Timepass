#' stage_prices UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_stage_prices_ui <- function(id) {
  ns <- NS(id)
  tagList(
    # This is a module with server part only
  )
}

#' stage_prices Server Functions
#'
#' @noRd
mod_stage_prices_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_stage_prices_server:", get_ns(ns), level = 3)

    ## Buttons ----
    ### "OK" button in stage modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "stage_check_user",
      triggers = "check_user_before_stg"
    )

    ## "Reset Inputs" button in stage modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "reset_to_staged",
      triggers = "reset_to_staged"
    )

    ### "OK" button in user check modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "stage_check_exrate",
      triggers = "check_exrates_before_stg"
    )

    ### "Reset" button in forex check modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "reset_exrates_to_staged",
      triggers = "reset_exrates_to_staged"
    )

    ### "OK" button in forex check modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "stage_final",
      triggers = "stage_prices_end"
    )

    ### "Cancel" button in forex reset modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "cancel_stage_err",
      triggers = "close_modal"
    )
    ### "Cancel" button in err modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "cancel_stage_exrates",
      triggers = "close_modal"
    )

    ### "Cancel" button in reset input modal ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "cancel_stage_reset",
      triggers = "close_modal"
    )

    ## Stage start ----
    shiny::observeEvent(
      gargoyle::watch("stage_prices_start"),
      {
        log_info("observeEvent:", "stage_prices_start", level = 1)

        ## Do not proceed if auto-calc is OFF
        if (!r$rv$auto_calc) {
          log_warn(
            "The \"Auto calculate\" switch must be turned ON before saving",
            prompt = TRUE,
            title = "\"Auto calculate\" switch is OFF"
          )

          return(NULL)
        }

        gargoyle::trigger("get_stg_prices")
        gargoyle::trigger("stage_check_errors")
      },
      ignoreInit = TRUE
    )

    ## Stage check errors ----
    shiny::observeEvent(
      gargoyle::watch("stage_check_errors"),
      {
        log_info("observeEvent:", "stage_check_errors", level = 1)

        ## Collect errors
        r$rv$dt_prices_all[
          MARKET == r$rv$market &
            RANK == 1 &
            PUBLISH == TRUE &
            EDIT_MID == FALSE &
            TYPE != "Imported",
          ERROR := data.table::fifelse(
            test = !is.na(VALUE),
            yes = is_truthy(VALUE[PRICETYPE_ADJ == "LOW"] > VALUE[PRICETYPE_ADJ == "HIGH"]),
            no = ERROR
          ),
          by = QPT_MID
        ]

        r$rv$dt_errors <- r$rv$dt_prices_all[
          MARKET == r$rv$market &
            ERROR == TRUE &
            TYPE != "Imported" &
            RANK == 1 &
            PUBLISH == TRUE &
            FINAL == TRUE
        ]

        if (nrow(r$rv$dt_errors) > 0) {
          shiny::showModal(shiny::modalDialog(
            inputId = "err_modal",
            size = "xl",

            shiny::tags$h2("Some of the prices contain errors. Would you like to proceed?"),

            htmltools::tags$div(
              id = ns("tabulator_box"),
              style = "overflow-x: auto;",
              argusDS.tabulator::tabulatorOutput(
                outputId = ns("tabulator_errors"),
                height = "100%",
                width = "auto"
              )
            ),

            footer = shiny::tagList(
              col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("stage_check_user"),
                label = "OK"
              )),
              col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("cancel_stage_err"),
                label = "Cancel"
              ))
            )
          ))
        } else {
          gargoyle::trigger("check_user_before_stg")
        }
      },
      ignoreInit = TRUE
    )

    ### Error table ----
    output$tabulator_errors <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator_errors"), level = 4)

      cols_err <- c(
        "CODE_ID",
        "SECTION",
        "CODE_DESCRIPTION",
        "TS",
        "CF",
        "PT",
        "PUBLICATION_DATE",
        "VALUE",
        "FWD",
        "YEAR",
        "DBR"
      )

      argusDT.PriceStudioMain::fct_render_tabulator_errors(
        r$rv$dt_errors[, .SD, .SDcols = cols_err],
        paginationsize = 10
      )
    }) %>%
      shiny::bindEvent(r$rv$dt_errors)

    ## Stage check user ----
    shiny::observeEvent(
      gargoyle::watch("check_user_before_stg"),
      {
        log_info("observeEvent:", "check_user_before_stg", level = 1)

        shiny::removeModal()

        if (!is.null(r$rv$dt_prices_stg)) {
          ## Get the values that have never been staged
          dt_never_staged <- r$rv$dt_prices_all[
            MARKET == r$rv$market & TYPE != "Imported" & RANK == 1 & is.na(STG_FINAL)
          ]

          dt_never_staged_value_changed <- dt_never_staged[
            (ifelse(is.na(STG_VALUE), "na", STG_VALUE) != ifelse(is.na(VALUE), "na", VALUE) |
              (ifelse(is.na(STG_FWD), "na", STG_FWD) != ifelse(is.na(FWD), "na", FWD) &
                EDIT_FWD == TRUE) |
              (ifelse(is.na(STG_YEAR), "na", STG_YEAR) != ifelse(is.na(YEAR), "na", YEAR) &
                EDIT_FWD == TRUE) |
              (ifelse(is.na(STG_DBR), "na", STG_DBR) != ifelse(is.na(DBR), "na", DBR) &
                EDIT_DBR == TRUE))
          ]

          ## Get the values that have changed in the current session
          dt_staged_value_changed <- r$rv$dt_prices_all[
            MARKET == r$rv$market &
              TYPE != "Imported" &
              RANK == 1 &
              !(QPT_MID %in% dt_never_staged$QPT_MID) &
              (ifelse(is.na(STG_VALUE), "na", STG_VALUE) != ifelse(is.na(VALUE), "na", VALUE) |
                ifelse(is.na(STG_FWD), "na", STG_FWD) != ifelse(is.na(FWD), "na", FWD) |
                ifelse(is.na(STG_YEAR), "na", STG_YEAR) != ifelse(is.na(YEAR), "na", YEAR) |
                ifelse(is.na(STG_DBR), "na", STG_DBR) != ifelse(is.na(DBR), "na", DBR) |
                ifelse(is.na(STG_PUBLISH), "na", STG_PUBLISH) !=
                  ifelse(is.na(PUBLISH), "na", PUBLISH) |
                ifelse(is.na(STG_NOTES), "na", STG_NOTES) != ifelse(is.na(NOTES), "na", NOTES))
          ]

          ## Bind newly to be staged and updated values
          dt_check <- data.table::rbindlist(list(
            dt_never_staged_value_changed,
            dt_staged_value_changed
          ))

          dt_check <- dt_check[
            r$rv$dt_prices_stg,
            `:=`(
              STG_VALUE = i.VALUE,
              STG_FWD = i.FWD,
              STG_YEAR = i.YEAR,
              STG_DBR = i.DBR,
              STG_CHANGE = i.CHANGE,
              STG_PUBLISH = i.PUBLISH, # Keep track of last publish status staged
              STG_OVERRIDE_PUBLISH = i.OVERRIDE_PUBLISH, # Keep track of OVERRIDE_PUBLISH
              STG_FINAL = i.FINAL, # Keep track of last draft status staged
              STG_NOTES = i.NOTES, # Keep track of the notes
              STG_USERNAME = i.USERNAME, # Keep track of who last staged values
              STG_EXRATE_DATE = i.EXRATE_DATE,
              STG_EXRATE_TIME = i.EXRATE_TIME
            ),
            on = c("CODE_ID", "TS", "CF", "PT", "PUBLICATION_DATE")
          ]

          r$rv$dt_user_upd <- dt_check[
            MARKET == r$rv$market &
              TYPE != "Imported" &
              RANK == 1 &
              (ifelse(is.na(STG_VALUE), "na", STG_VALUE) != ifelse(is.na(VALUE), "na", VALUE) |
                ifelse(is.na(STG_FWD), "na", STG_FWD) != ifelse(is.na(FWD), "na", FWD) |
                ifelse(is.na(STG_YEAR), "na", STG_YEAR) != ifelse(is.na(YEAR), "na", YEAR) |
                ifelse(is.na(STG_DBR), "na", STG_DBR) != ifelse(is.na(DBR), "na", DBR) |
                ifelse(is.na(STG_PUBLISH), "na", STG_PUBLISH) !=
                  ifelse(is.na(PUBLISH), "na", PUBLISH) |
                ifelse(is.na(STG_OVERRIDE_PUBLISH), "na", STG_OVERRIDE_PUBLISH) !=
                  ifelse(is.na(OVERRIDE_PUBLISH), "na", OVERRIDE_PUBLISH) |
                ifelse(is.na(STG_FINAL), "na", STG_FINAL) != ifelse(is.na(FINAL), "na", FINAL) |
                ifelse(is.na(STG_NOTES), "na", STG_NOTES) != ifelse(is.na(NOTES), "na", NOTES)) &
              STG_USERNAME != get_config("username")
          ]

          r$rv$dt_user_upd <- r$rv$dt_user_upd[
            r$rv$dt_prices_stg,
            `:=`(
              OLD_VALUE = i.VALUE,
              OLD_FWD = i.FWD,
              OLD_YEAR = i.YEAR,
              OLD_DBR = i.DBR,
              OLD_NOTES = i.NOTES
            ),
            on = c("CODE_ID", "TS", "CF", "PT", "PUBLICATION_DATE")
          ]

          ## Keep only rows where the new staged values differ from previously staged values
          r$rv$dt_user_upd <- r$rv$dt_user_upd[
            (ifelse(is.na(OLD_VALUE), "na", OLD_VALUE) != ifelse(is.na(VALUE), "na", VALUE)) |
              (ifelse(is.na(OLD_FWD), "na", OLD_FWD) != ifelse(is.na(FWD), "na", FWD)) |
              (ifelse(is.na(OLD_YEAR), "na", OLD_YEAR) != ifelse(is.na(YEAR), "na", YEAR)) |
              (ifelse(is.na(OLD_DBR), "na", OLD_DBR) != ifelse(is.na(DBR), "na", DBR)) |
              (ifelse(is.na(OLD_NOTES), "na", OLD_NOTES) != ifelse(is.na(NOTES), "na", NOTES))
          ]

          ## Ignores NAs when there are final values staged by a different user
          r$rv$dt_user_upd <- r$rv$dt_user_upd[
            !(((!is.na(STG_VALUE) & is.na(VALUE)) |
              (!is.na(STG_FWD) & is.na(FWD)) |
              (!is.na(STG_YEAR) & is.na(YEAR)) |
              (!is.na(STG_DBR) & is.na(DBR)) |
              (!is.na(STG_PUBLISH) & is.na(PUBLISH)) |
              (!is.na(STG_FINAL) & is.na(FINAL)) |
              (!is.na(STG_OVERRIDE) & is.na(OVERRIDE)) |
              (!is.na(STG_NOTES) & is.na(NOTES))) &
              STG_FINAL == TRUE),
            .(
              PUBLICATION_DATE,
              CODE_ID,
              TS,
              CF,
              PT,
              CODE_DESCRIPTION,
              OLD_VALUE,
              VALUE,
              OLD_FWD,
              FWD,
              OLD_DBR,
              DBR,
              OLD_YEAR,
              YEAR,
              OLD_NOTES,
              NOTES
            )
          ]
        }

        ## Values staged in another session by a different user table
        if (nrow(r$rv$dt_user_upd) > 0) {
          log_info(
            nrow(r$rv$dt_user_upd),
            " different QUOTE_PRICETYPE_ID's have been saved by another user",
            level = 3
          )

          shiny::showModal(shiny::modalDialog(
            inputId = "user_check_modal",
            size = "xl",

            htmltools::tags$h2(paste0(
              "You are modifying prices below that have been saved by another user.",
              "\n\nWould you like to proceed and update them?"
            )),

            htmltools::tags$div(
              id = ns("staged_upd_box"),
              style = "overflow-x: auto; padding-top: 0.5rem;",

              argusDS.tabulator::tabulatorOutput(
                outputId = ns("tabulator_dt_user_upd"),
                height = "100%",
                width = "auto"
              )
            ),

            footer = shiny::tagList(
              col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("stage_check_exrate"),
                label = "Continue"
              )),
              col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("reset_to_staged"),
                label = "Reset inputs",
              )),
              col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                id = ns("cancel_stage_reset"),
                label = "Cancel"
              ))
            )
          ))
        } else {
          gargoyle::trigger("check_exrates_before_stg")
        }
      },
      ignoreInit = TRUE
    )

    ### User staged tbl ----
    output$tabulator_dt_user_upd <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator_dt_user_upd"), level = 4)

      fct_render_tabulator_stg(
        r$rv$dt_user_upd,
        visible_cols = list(
          "PUBLICATION_DATE",
          "CODE_ID",
          "TS",
          "CF",
          "PT",
          "CODE_DESCRIPTION",
          "OLD_VALUE",
          "VALUE",
          "OLD_FWD",
          "FWD",
          "OLD_YEAR",
          "YEAR",
          "OLD_DBR",
          "DBR",
          "OLD_NOTES",
          "NOTES"
        ),
        show_filters = TRUE
      )
    }) %>%
      shiny::bindEvent(r$rv$dt_user_upd)

    ## Stage check forex ----
    shiny::observeEvent(
      gargoyle::watch("check_exrates_before_stg"),
      {
        log_info("observeEvent:", "check_exrates_before_stg", level = 1)

        shiny::removeModal()

        ### Check if forex date and time previously staged for the current market are different than the selected ones
        if (!is.na(r$rv$xr_dte_stg_curr_m)) {
          exrate_date_check_curr_market <- r$rv$exrate_date != r$rv$xr_dte_stg_curr_m
        } else {
          exrate_date_check_curr_market <- FALSE
        }
        if (!is.na(r$rv$xr_time_stg_curr_m)) {
          exrate_time_check_curr_market <- r$rv$exrate_time != r$rv$xr_time_stg_curr_m
        } else {
          exrate_time_check_curr_market <- FALSE
        }

        ### Check if forex date and time previously staged for the other markets are different than the selected ones
        if (!is.na(r$rv$xr_dte_stg_other_m)) {
          exrate_date_check_other_markets <- r$rv$exrate_date != r$rv$xr_dte_stg_other_m
        } else {
          exrate_date_check_other_markets <- FALSE
        }
        if (!is.na(r$rv$xr_time_stg_other_m)) {
          exrate_time_check_other_markets <- r$rv$exrate_time != r$rv$xr_time_stg_other_m
        } else {
          exrate_time_check_other_markets <- FALSE
        }

        if (exrate_date_check_other_markets | exrate_time_check_other_markets) {
          log_warn(
            paste(
              "Different forex date(s) / time(s) than the selected ones were used to save prices for other markets! \n\n",
              "All markets in the same region need to use the same forex date(s) / time(s) settings, please rectify this before uploading again.",
              collapse = "\n"
            ),
            prompt = TRUE,
            title = "Error in saved forex date / time"
          )

          gargoyle::trigger("hide_waiter")
        } else {
          ### If the check for the current market is TRUE then warn the user and ask him to take action
          if (exrate_date_check_curr_market | exrate_time_check_curr_market) {
            if (exrate_date_check_curr_market) {
              log_info(
                "selected forex date ",
                r$rv$exrate_date,
                " is different to the previously saved (for this market) forex date ",
                r$rv$exrate_date_staged,
                level = 3
              )
            }

            if (exrate_time_check_curr_market) {
              log_info(
                "selected forex timing ",
                r$rv$exrate_time,
                " is different to the previously saved (for this market) forex timing ",
                r$rv$exrate_time_staged,
                level = 3
              )
            }

            shiny::showModal(shiny::modalDialog(
              inputId = "exrate_check_modal",
              size = "xl",

              shiny::tags$h2(
                "Warning! Selected forex date / timing might be different to the one(s) currently saved within the selected market."
              ),
              shiny::tags$br(),
              shiny::tags$h5("Please choose one of the following options:"),
              shiny::tags$h5(
                "- Continue with the current forex date (",
                format(r$rv$exrate_date, '%d-%b'),
                ") and timing (",
                r$rv$exrate_time,
                ")"
              ),
              shiny::tags$h5(
                "- Reset to the saved forex date (",
                format(r$rv$xr_dte_stg_curr_m, '%d-%b'),
                ") and timing (",
                r$rv$xr_time_stg_curr_m,
                ")"
              ),
              shiny::tags$h5("- Cancel"),

              footer = shiny::tagList(
                col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                  id = ns("stage_final"),
                  label = "Continue"
                )),
                col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                  id = ns("reset_exrates_to_staged"),
                  label = "Reset forex timing"
                )),
                col_2(argusDT.PriceStudioMain::mod_actionbutton_ui(
                  id = ns("cancel_stage_exrates"),
                  label = "Cancel"
                ))
              )
            ))
          } else {
            gargoyle::trigger("stage_prices_end")
          }
        }
      },
      ignoreInit = TRUE
    )

    ## Stage end ----
    shiny::observeEvent(
      gargoyle::watch("stage_prices_end"),
      {
        log_info("observeEvent:", "stage_prices_end", level = 1)

        shiny::removeModal()

        staged <- argusDT.PriceStudioMain::fct_stage_prices(
          dt_prices_all = r$rv$dt_prices_all,
          dt_prices_stg = r$rv$dt_prices_stg,
          username = get_config("username"),
          market = r$rv$market,
          db_env = r$rv$db_env,
          connection = r$rv$ora_connection,
          exrate_date = r$rv$exrate_date,
          exrate_time = r$rv$exrate_time,
          process_id = get_config("pid"),
          session_id = session$userData$sid,
          application_id = get_config("application_id"),
          app_version = as.character(utils::packageVersion(pkg = pkgload::pkg_name()))
        )

        ### Check if prices were staged
        total <- as.numeric(staged[1])
        finalized <- as.numeric(staged[2])
        drafted <- as.numeric(staged[3])

        #calculate remaining values that can be entered
        pending <- total - drafted - finalized

        # Check if prices were staged
        if (drafted == 0 & finalized == 0) {
          log_warn(
            "No new values drafted or finalized.\n",
            prompt = TRUE,
            type = "info",
            title = "Nothing to save"
          )

          gargoyle::trigger("hide_waiter")
        } else if (drafted > 0 & finalized == 0) {
          log_warn(
            paste0(
              drafted,
              " drafted",
              "\n ",
              finalized,
              " finalized \n",
              pending,
              " pending"
            ),
            prompt = TRUE,
            type = "success",
            title = "Prices saved successfully"
          )

          gargoyle::trigger("hide_waiter")
        } else if (drafted == 0 & finalized > 0) {
          log_warn(
            paste0(
              drafted,
              " drafted",
              "\n ",
              finalized,
              " finalized \n",
              pending,
              " pending"
            ),
            prompt = TRUE,
            type = "success",
            title = "Prices saved successfully"
          )
          gargoyle::trigger("hide_waiter")
        } else if (drafted > 0 & finalized > 0) {
          log_warn(
            paste0(
              drafted,
              " drafted",
              "\n ",
              finalized,
              " finalized \n",
              pending,
              " pending"
            ),
            prompt = TRUE,
            type = "success",
            title = "Prices saved successfully"
          )
          gargoyle::trigger("hide_waiter")

          ### Remove input values for market staged
          if (!is.null(r$rv$dt_prices_input)) {
            r$rv$dt_prices_input <- r$rv$dt_prices_input[MARKET != r$rv$market]
          }

          ### Refresh data
          gargoyle::trigger("get_stg_prices")
          gargoyle::trigger("combine_price_data")
          gargoyle::trigger("calculate_prices")
          gargoyle::trigger("check_prices")
          gargoyle::trigger("pivot_prices")
          gargoyle::trigger("show_price_input")
          gargoyle::trigger("create_summary")
          gargoyle::trigger("get_prices_status")
        } else if (drafted < 0 | finalized < 0) {
          log_warn("Prices failed to save", prompt = TRUE, title = "saving failed")
        }

        ### Save combined price components ----
        if (r$rv$region == "Automated" & finalized > 0 && get_config("show_tab_price_components")) {
          log_info("create:", "price components final csv to s3", level = 2)

          r$rv$s3_price_components_dir <- file.path(
            r$rv$s3_price_components_base_dir,
            tolower(gsub(" ", "_", r$rv$market))
          )

          price_components_csv_filenames <- argusDT.S3::s3_get_bucket_dt(
            bucket = get_config("s3_bucket"),
            prefix = file.path(r$rv$s3_price_components_dir)
          )

          if (nrow(price_components_csv_filenames) > 0) {
            filenames <- basename(price_components_csv_filenames[[1]])

            qpt_csv <- filenames[grepl("^[0-9]+_price_components\\.csv$", filenames)]

            dt_list <- list()

            for (file in qpt_csv) {
              dt <- argusDT.S3::s3_read_using(
                FUN = data.table::fread,
                object = file.path(r$rv$s3_price_components_dir, file),
                bucket = get_config("s3_bucket")
              )

              if (!is.null(dt)) {
                dt_list[[length(dt_list) + 1]] <- dt
              }
            }

            ### Combine csvs
            merged_price_components_dt <- data.table::rbindlist(
              dt_list,
              use.names = TRUE,
              fill = TRUE
            )

            filename <- paste(
              gsub(" ", "_", tolower(r$rv$market)),
              "price_components_final.csv",
              sep = "_"
            )

            ### Save price_components_final.csv
            argusDT.PriceStudioMain::fct_save_csv_to_s3(
              dt_csv = merged_price_components_dt,
              file_path = file.path(r$rv$s3_price_components_dir, filename),
              s3_bucket = get_config("s3_bucket")
            )

            ### Copy file to archive folder
            archive_filename <- paste(
              gsub(" ", "_", tolower(r$rv$market)),
              "price_components_final",
              format(lubridate::now(tzone = r$rv$user_timezone), "-%Y%m%d_%H%M%S_%Z"),
              ".csv",
              sep = "_"
            )

            argusDT.S3::s3_copy_object(
              from_object = file.path(r$rv$s3_price_components_dir, filename),
              to_object = file.path(r$rv$s3_price_components_dir, "archive", archive_filename),
              from_bucket = get_config("s3_bucket"),
              to_bucket = get_config("s3_bucket")
            )
          }
        }
      },
      ignoreInit = TRUE
    )

    ## Reset forex timestamp to staged ----
    shiny::observeEvent(
      gargoyle::watch("reset_exrates_to_staged"),
      {
        log_change("r$rv$exrate_time", r$rv$exrate_time, r$rv$exrate_time_staged, level = 2)
        log_change("r$rv$exrate_date", r$rv$exrate_date, r$rv$exrate_date_staged, level = 2)

        shiny::removeModal()

        r$rv$exrate_day_offset <- bizdays::bizdays(
          from = r$rv$report_date,
          to = r$rv$xr_dte_stg_curr_m,
          cal = r$rv$calendar$name
        )

        r$rv$exrate_date <- r$rv$xr_dte_stg_curr_m
        r$rv$exrate_time <- r$rv$xr_time_stg_curr_m
      },
      ignoreInit = TRUE
    )

    shiny::observeEvent(
      gargoyle::watch("close_modal"),
      {
        shiny::removeModal()
        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )
  })
}
