#' feedback UI Function
#' @description A shiny Module.
#' @param id A shiny id.
#' @noRd
mod_feedback_ui <- function(id) {
  ns <- NS(id)

  log_info("mod_feedback_ui ns:", get_ns(ns), level = 3)

  htmltools::tagList(
    bslib::layout_columns(
      col_widths = 12,

      bslib::card(
        shiny::radioButtons(
          inputId = ns("feedback_type"),
          label = "Select Feedback Type",
          choices = c(
            "Immediate Support" = "immediate_support",
            "Bug Report" = "bug",
            "New Project" = "new_project",
            "Feature Request" = "feature_request"
          ),
          selected = "immediate_support"
        )
      ),

      bslib::card(
        shiny::conditionalPanel(
          condition = "input.feedback_type != 'new_project'
          && input.feedback_type != 'feature_request'",
          ns = ns,
          bslib::layout_columns(
            col_widths = c(12, 6, 12),
            row_heights = c(1, "auto"),

            shiny::textAreaInput(
              inputId = ns("msg"),
              label = "Feedback message : ",
              width = "100%",
              height = "200px"
            ),

            argusDT.PriceStudioMain::mod_fileinput_ui(
              id = ns("fileinput"),
              button_label = "Upload Attachment",
              placeholder = "Select file"
            ),

            bslib::layout_columns(
              col_widths = c(6, 6),
              row_heights = c("auto"),
              shiny::actionButton(
                inputId = ns("send"),
                label = "Submit"
              ),
              shiny::actionButton(
                inputId = ns("cancel"),
                label = "Cancel"
              )
            )
          )
        ),

        shiny::conditionalPanel(
          condition = "input.feedback_type == 'new_project'",
          ns = ns,
          bslib::layout_columns(
            col_widths = c(12, 12),
            row_heights = c(1, "auto"),
            shiny::tags$div(
              shiny::tags$p("To raise a new pricing project, please visit the link below:"),
              shiny::tags$a(
                href = "https://wkf.ms/44fWQgw",
                "Click here for a new pricing project",
                target = "_blank",
                class = "link-dark"
              )
            ),
            shiny::actionButton(
              inputId = ns("cancel"),
              label = "Cancel"
            )
          )
        ),
        shiny::conditionalPanel(
          condition = "input.feedback_type == 'feature_request'",
          ns = ns,
          bslib::layout_columns(
            col_widths = c(12, 12),
            row_heights = c(1, "auto"),
            shiny::tags$div(
              shiny::tags$p("To raise a feature request, please visit the link below:"),
              shiny::tags$a(
                href = "https://wkf.ms/4cPnjoD",
                "Click here for new feature request",
                target = "_blank",
                class = "link-dark"
              )
            ),
            shiny::actionButton(
              inputId = ns("cancel"),
              label = "Cancel"
            )
          )
        )
      )
    )
  )
}

#' feedback Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_feedback_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_feedback_server ns:", get_ns(ns), level = 3)

    argusDT.PriceStudioMain::mod_fileinput_server(
      id = "fileinput",
      rv = r$rv
    )

    shiny::observeEvent(
      input$send,
      {
        log_info("observeEvent:", "input$send", level = 4)

        if (input$msg == "") {
          shiny::showNotification(
            "Please complete the 'Feedback message' field to continue.",
            type = "warning"
          )
        }

        shiny::req(input$msg)

        subject <- paste0(
          "Price Studio Feedback - ",
          "APPLICATION ID: ",
          get_config("application_id"),
          "; ",
          "USER: ",
          get_config("username"),
          "; ",
          "PROCESS: ",
          get_config("pid"),
          "; ",
          "SESSION: ",
          session$userData$sid,
          ";"
        )

        body <- glue::glue(
          " Feedback received from {r$subtitle}
            ----------------------------------------------------------------------------------
            {input$msg}
            ----------------------------------------------------------------------------------
            Application ID: {get_config('application_id')}
            Application Name: {r$subtitle}
            Active tab: {r$rv$selected_nav_panel}
            Region: {r$rv$region}
            Market: {r$rv$market}
            Time / Timezone: {Sys.time()} {r$rv$user_timezone}
            Process: {get_config('pid')}
            Session: {session$userData$sid}",
          .null = "--"
        )

        attachment_paths <- NULL

        if (!is.null(r$rv$fileinput) && nrow(r$rv$fileinput) > 0) {
          attachment_paths <- lapply(seq_len(nrow(r$rv$fileinput)), function(i) {
            original_path <- r$rv$fileinput$datapath[i]
            new_path <- file.path(dirname(original_path), r$rv$fileinput$name[i])
            file.rename(original_path, new_path)
            return(new_path)
          })

          # Convert list to character vector
          attachment_paths <- unlist(attachment_paths)
        }

        # Set email headers for high importance if "Immediate Support" is selected
        headers <- NULL
        if (input$feedback_type == "immediate_support") {
          headers <- list(
            "X-Priority" = "1 (Highest)",
            "X-MSMail-Priority" = "High",
            "Importance" = "High"
          )
        }

        shiny::showNotification("Sending email...")

        argusDT.PriceStudioMain::fct_send_email(
          to = get_config("feedback_email"),
          subject = subject,
          body = body,
          attach.files = attachment_paths,
          headers = headers
        )

        # Clear file input
        r$rv$fileinput <- NULL

        shiny::showNotification("Your feedback has been submitted. Thank you!")

        shiny::updateTextAreaInput(inputId = "msg", value = "")

        gargoyle::trigger("close_feedback_form")
      },
      ignoreNULL = TRUE,
      ignoreInit = TRUE
    )

    shiny::observeEvent(
      input$cancel,
      {
        gargoyle::trigger("close_feedback_form")
      },
      ignoreNULL = TRUE,
      ignoreInit = TRUE
    )
  })
}
