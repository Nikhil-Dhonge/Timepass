#' utils_theme
#' @description A function to create a bootstrap theme
#' @return A bs theme
#' @noRd
utils_theme <- function() {
  log_info("utils_theme", level = 1)

  bslib::bs_theme(
    preset = "bootstrap",
    version = 5,
    bootswatch = NULL,
    bg = "#212121",
    fg = "#FFFFFF",
    primary = "#333333",
    secondary = NULL,
    success = "#0055a0",
    info = "#4D4D4D",
    warning = NULL,
    danger = "#BF616A",
    base_font = bslib::font_google("Montserrat", local = FALSE),
    code_font = bslib::font_google("Fira Code", local = FALSE),
    heading_font = bslib::font_google("Montserrat", local = FALSE),
    font_scale = 0.9,
    "navbar-padding-y" = "0",
    "navbar-padding-x" = "0",
    "btn-disabled-opacity" = ".4",
    "zindex-tooltip" = 10000,
    "code-color" = "#0055a0",
    "progress-bar-bg" = "#0055a0",
    "progress-bar-color" = "#FFFFFF",
    "accent" = "#FF6900",
    "status-complete" = "#44AB05",
    "status-success" = "#C6E0B4",
    "status-empty" = "#FFFFCC",
    "status-warning" = "#FFC107",
    "status-error" = "#FF9999"
  ) |>
    bslib::bs_add_rules(c(
      ".tooltip-dark {--bs-tooltip-color: #FFFFFF; --bs-tooltip-bg:#212121;}",

      # Page ----
      ":root {--bslib-mb-spacer: 0;}",

      # Navbar ----
      ".navbar .nav.nav-underline {--bs-navbar-nav-link-padding-x: 0.5rem;}",
      ".nav-underline {--bs-nav-underline-gap: 0;}",

      # Checkbox group ----
      ".checkbtn {margin: 3px 1px;}",

      # Tabulator ----
      ".tabulator-menu-item {color:#555555; font-weight:700;}",
      ".tabulator .tabulator-tableholder {overflow: scroll !important;}",
      ".tabulator-tooltip {
        border-radius: 5px;
        color: #FFFFFF;
        background-color: #4D4D4D !important;
      }",

      ".tabulator-row.tabulator-row-exclude {font-style: italic; color: var(--bs-gray-800);}",

      ".tabulator-cell-editable-empty {background-color: #FFFFCC;}",
      ".tabulator-cell-editable-filled {background-color: #C6E0B4;}",

      ".tabulator-cell-error{background-color: $status-error !important;}",
      ".tabulator-cell-warning{background-color: $status-warning !important;}",
      ".tabulator-cell-success{background-color: $status-success !important;}",
      ".tabulator-cell-complete{background-color: $status-complete !important;}",

      ".tabulator-cell-changed {color: var(--bs-success); font-weight: bold;}",

      ".tabulator-cell.tabulator-change-positive {color: #44AB05;}",
      ".tabulator-cell.tabulator-change-negative {color: #DD2303;}",
      ".tabulator-cell.tabulator-change-zero {background-color: #0188ff50;}",
      ".tabulator-cell.tabulator-threshold-above {background-color: #ff000050;}",
      ".tabulator-cell.tabulator-threshold-below {background-color: #ff000050;}",
      ".tabulator-header-red {background-color: #FFD580 !important;}",
      ".tabulator-header-green {background-color: #93C572 !important;}",

      # Value box ----9cd7ff
      ".bslib-value-box .value-box-value {font-size:1.0rem;}",

      # Notes column popup ----
      ".edit-popup {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 400px;
        height: 300px;
        z-index: 1000;
        padding: 0;
        border: 1px solid $accent;
        background-color: var(--bs-body-bg);
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        color: #333333;
      }",
      ".edit-popup-header {
        padding: 10px;
        background-color: var(--bs-primary);
        border-bottom: 1px solid var(--bs-info);
        font-weight: bold;
        text-align: center;
        font-size: 18px;
        color: var(--bs-body-color);
      }",
      ".edit-popup-content {
        padding: 10px;
        flex-grow: 1;
        overflow-y: auto
      }",
      ".edit-popup textarea {
        width: 100%;
        box-sizing: border-box;
        resize: none;
        overflow-y: auto;
        font-size: 14px;
        height: 14em;
        color: var(--bs-body-bg);
      }",
      ".edit-popup-footer {
        padding: 10px;
        background-color: var(--bs-primary);
        border-top: 1px solid var(--bs-info);
        text-align: right
      }",
      ".edit-popup-footer button {margin-left: 10px}",

      # Assumptions tab ----
      ".assumptions-box {color: var(--bs-body-color);}",

      # Correction status output text ----
      ".correction-status-output-text {
        align-items: center;
        display: grid;
        height: 100%;
      }",

      # InDesign ----
      ".indesign-send-charts-button {
        align-items: center;
        background-color: #646464;
        border: 1px solid #646464;
        border-radius: 7px;
        color: #fff;
        font-size: 14px;
        margin-bottom: 10px;
        padding: 6px;
        text-align: center;
        text-decoration: underline;
        text-decoration-color: #646464;
      }",

      # Other ----
      ".help-block {--bs-secondary-color: #212121;}",
      ".admin-code-block {--bs-emphasis-color-rgb: 170,170,170;}",
      ".checkbox-default-container {position:relative; top:35%; font-size:smaller;}",
      ".form-group {margin:0;}",
      ".text-output-right-align {margin-left:auto;}"
    ))
}
