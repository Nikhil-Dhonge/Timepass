#' admin UI Function
#' @description A shiny Module for an admin tab.
#' @param id,input,output,session Internal parameters for {shiny}.
#' @noRd

mod_admin_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_admin_ui ns:", get_ns(ns), level = 2)

  htmltools::tagList(
    shiny::div(
      class = "main-nav",

      bslib::layout_columns(
        col_widths = c(9, 3, 12),
        row_heights = list("auto", 1),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,

          shiny::textInput(
            inputId = ns("variable"),
            label = "Variable:"
          ),

          shiny::verbatimTextOutput(
            outputId = ns("text_variable"),
            placeholder = TRUE
          ) |>
            shiny::tagAppendAttributes(class = "admin-code-block")
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,

          argusDT.PriceStudioMain::mod_switchinput_ui(
            id = ns("browser_active_switch"),
            label = "Activate browsers",
            value = FALSE
          ),

          shiny::verbatimTextOutput(
            outputId = ns("browser_code"),
            placeholder = TRUE
          ) |>
            shiny::tagAppendAttributes(class = "admin-code-block"),

          shiny::helpText(
            "The above line can be used instead of a normal browser() to activate the
            same only when the switch is turned on"
          )
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,

          shiny::textInput(
            inputId = ns("dt_variable"),
            label = "dt variable:"
          ),

          argusDS.tabulator::tabulatorOutput(
            outputId = ns("tabulator_dt_variable")
          )
        )
      )
    )
  )
}

#' admin Server Functions
#'
#' @noRd
mod_admin_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    # Add widgets ----
    ## Switches ----
    ### Browsers active
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "browser_active_switch",
      rv = r$rv
    )

    ## Outputs ----
    ### Variable ----
    output$text_variable <- shiny::renderPrint(tryCatch(
      eval(parse(text = input$variable)),
      error = function(e) e$message,
      warning = function(w) w$message
    ))

    ### Browser code ----
    output$browser_code <- shiny::renderText("browser(expr = {r$rv$browser_active_switch})")

    ### Table Variable ----
    output$tabulator_dt_variable <- argusDS.tabulator::renderTabulator({
      dt <- tryCatch(
        eval(parse(text = input$dt_variable)),
        error = function(e) e$message,
        warning = function(w) w$message
      )

      if (is_truthy(dt)) {
        argusDT.PriceStudioMain::fct_render_tabulator_auto(dt)
      } else {
        data.table(NULL)
      }
    })
  })
}
