#' prices_status UI Function
#' @description A shiny Module.
#' @param id,input,output,session Internal parameters for {shiny}.
#' @noRd
mod_prices_status_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_prices_status_ui ns:", get_ns(ns), level = 3)

  correctionBox <- ns("correction_box")
  buttonId <- ns("review_corrections")
  outputId <- ns("textoutput")

  log_info("correction_box", correctionBox, level = 3)
  log_info("textOutput ID:", outputId, level = 3)
  log_info("actionButton ID:", buttonId, level = 3)

  tag_live <- mod_progressbar_ui(id = ns("progress-live"), title = "Uploaded")
  tag_stg_draft <- mod_progressbar_ui(id = ns("progress-staged-draft"), title = "Saved as Draft")
  tag_stg_final <- mod_progressbar_ui(id = ns("progress-staged-final"), title = "Saved as Final")

  tag_corr <- shinyjs::hidden(
    htmltools::tags$div(
      id = correctionBox,
      class = "correction-status",
      bslib::layout_columns(
        col_widths = c(4, 8),
        gap = 0,
        argusDT.PriceStudioMain::mod_actionbutton_ui(
          id = buttonId,
          label = "Review",
          icon = shiny::icon("zoom-in", lib = "glyphicon")
        ),
        shiny::textOutput(outputId) |>
          shiny::tagAppendAttributes(class = "correction-status-output-text")
      )
    )
  )

  return(shiny::tagList(tag_live, tag_stg_final, tag_stg_draft, tag_corr))
}


#' prices_status Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_prices_status_server <- function(id, r, is_summary = FALSE) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_prices_status_server ns:", get_ns(ns), level = 3)

    ## Review corrections
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "review_corrections",
      triggers = ns("review_corrections")
    )

    ## Get status ----
    shiny::observeEvent(
      gargoyle::watch("get_prices_status"),
      {
        log_info("observeEvent:", ns("get_prices_status"), level = 1)

        shiny::req(r$rv$dt_prices_all)

        ## Select the correct data.table and filter by market if is_summary argument is FALSE.
        ## If a filter is applied in Summary, use the filtered data.table in order to show the
        ## correct stats
        if (!is_summary) {
          dt <- r$rv$dt_prices_all[MARKET == r$rv$market]
        } else {
          if (!is.null(r$rv$dt_summary_total_filtered)) {
            dt <- r$rv$dt_summary_total_filtered
          } else {
            dt <- r$rv$dt_summary_total
          }
        }

        dt <- dt[TYPE != "Imported" & RANK == 1 & PUBLISH == TRUE]

        ## Get total count of price assessments
        total <- dt[, .N]

        ## Uploaded progress
        ct_upload <- dt[
          !is.na(LIVE_VALUE) &
            (is.na(STG_VALUE) |
              (STG_VALUE == LIVE_VALUE &
                STG_FWD == LIVE_FWD &
                STG_DBR == LIVE_DBR &
                STG_YEAR == LIVE_YEAR)),
          .N
        ]

        mod_progressbar_server(id = "progress-live", ct_upload, total, "Uploaded")

        ## Staged as Draft progress
        ct_stg_draft <- dt[
          !is.na(STG_VALUE) &
            VALUE == STG_VALUE &
            FWD == STG_FWD &
            DBR == STG_DBR &
            YEAR == STG_YEAR,
          .N
        ]

        mod_progressbar_server(id = "progress-staged-draft", ct_stg_draft, total, "Saved as Draft")

        ## Staged as Final progress
        ct_stg_final <- dt[
          !is.na(STG_VALUE) &
            STG_FINAL == TRUE &
            VALUE == STG_VALUE &
            FWD == STG_FWD &
            DBR == STG_DBR &
            YEAR == STG_YEAR,
          .N
        ]

        mod_progressbar_server(id = "progress-staged-final", ct_stg_final, total, "Saved as Final")

        if (!is_summary) {
          ct_input <- dt[!is.na(VALUE) & ERROR == FALSE, .N]

          ct_stg <- dt[
            !is.na(STG_VALUE) &
              VALUE == STG_VALUE &
              FWD == STG_FWD &
              DBR == STG_DBR &
              YEAR == STG_YEAR,
            .N
          ]

          # If prices are entered/changed but not staged, show the user a message
          # if he/she tries to exit the app before staging new prices
          session$sendCustomMessage("prices_changed", (ct_input != ct_stg))
        }

        ## Count corrections
        ct <- dt[CORRECTION == TRUE, .N]

        ## Show correction status box if ct > 0
        if (ct > 0) {
          log_warn("total corrections: ", ct)
          shinyjs::show(id = "correction_box")

          text <- glue::glue("CORRECTIONS REQUIRED: {ct} out of {dt[, .N]}")
          output$textoutput <- shiny::renderText(text)
        } else {
          log_info("No corrections found", level = 5)
          shinyjs::hide(id = "correction_box")
        }
      },
      ignoreInit = TRUE
    )
  })
}
