#' show_prices
#' @description A fct function
#' @param input A shiny input object.
#' @param session A shiny session object.
#' @param r The global environment variable 'r'.
#' @param box_id The box id where to insert the price input tables.
#' @param iteration An iteration identifier to ensure unique IDs.
#' @return The return value, if any, from executing the function.
#' @noRd
fct_show_price_input <- function(input, session, r, box_id, iteration) {
  ns <- session$ns

  log_info("fct_show_price_input ns:", get_ns(ns), level = 2)

  ## Remove prior tables ----
  if (!is.null(r$rv$prices_curr_tabulator_ids)) {
    purrr::walk(
      .x = r$rv$prices_curr_tabulator_ids,
      .f = function(x, r) {
        id <- ns(x)
        x_destroy <- paste0(x, "_destroy")
        x_reformat <- paste0(x, "_reformat")

        ## Remove UI
        log_info("removeUI:", id, level = 3)

        shiny::removeUI(selector = paste0("#", id, "-text_output"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-tabulator"), immediate = TRUE)
        shiny::removeUI(selector = paste0("#", id, "-div"), immediate = TRUE)

        ## Remove inputs
        argusDT.PriceStudioMain::fct_remove_shiny_inputs(id = x, input, ns)

        ## Remove observeEvents
        if (!is.null(r$rv$observeEvent[[x]])) {
          r$rv$observeEvent[[x]]$destroy()
          r$rv$observeEvent[[x]] <- NULL
        }

        ## Remove observeEvents
        if (!is.null(r$rv$observeEvent[[x_destroy]])) {
          r$rv$observeEvent[[x_destroy]]$destroy()
          r$rv$observeEvent[[x_destroy]] <- NULL
        }

        ## Remove observeEvents
        if (!is.null(r$rv$observeEvent[[x_reformat]])) {
          r$rv$observeEvent[[x_reformat]]$destroy()
          r$rv$observeEvent[[x_reformat]] <- NULL
        }
      },
      r = r
    )
  }

  ## Add new tables ----

  ### Get prices section for just the current MARKET
  r$rv$prices_curr_sections <- unique(
    r$rv$dt_prices_pivot[!is.na(SECTION) & MARKET == r$rv$market]$SECTION
  )

  r$rv$prices_curr_tabulator_ids <- gsub(
    "\\W",
    "_",
    paste(r$rv$market, r$rv$prices_curr_sections, iteration)
  )

  r$rv$dt_prices_market <- r$rv$dt_prices_pivot[MARKET == r$rv$market]

  # Insert UI, all input tables
  purrr::walk2(
    .x = ns(r$rv$prices_curr_tabulator_ids),
    .y = r$rv$prices_curr_sections,
    .f = mod_tabulator_inp_ui,
    input_box_id = ns(box_id),
    dt = r$rv$dt_prices_market
  )

  ### Add tabulator server
  purrr::walk2(
    .x = r$rv$prices_curr_tabulator_ids,
    .y = r$rv$prices_curr_sections,
    .f = mod_tabulator_inp_server,
    dt = r$rv$dt_prices_market,
    r = r
  )
}
