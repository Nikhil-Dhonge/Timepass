#' Set the initial report date
#'
#' @description `fct_set_report_date_init()` sets the report date when the app
#'   is first loaded, using the `frequency_id` and `publish_day` from
#'   PRC_APPLICATION table. No holidays are taken into consideration in this
#'   function.
#'
#' @param today Date object that expresses the day to start from.
#' @param frequency Character object that expresses the application frequency.
#'   See the ARGUS.FREQUENCY table for accepted values.
#' @param publish_day Numeric object that expresses the publish day in reference
#'   to the frequency provided. See details for more information.
#' @param app_end_date Date object that expresses the end date of the
#' application. If the calculated report date is after this date, the end
#' date will be used instead. Default is NULL, meaning the application has no end
#' date.
#'
#' @details The following list details how the publish day is used for each
#' frequency:
#' - Daily (1): `publish_day` has no effect, `today` is used.
#' - Weekly (2): `publish_day` will determine the day of the week on which the
#' application should load (1 = Monday, ..., 7 = Sunday).
#' - Monthly (3): `publish_day` will determine the day of the month on which the
#' application should load.
#' - Quarterly (4): `publish_day` will determine the day from the start of the
#' quarter on which the application should load.
#' - Fortnightly (8): `publish_day` will determine the day of the week as well
#' as the week number (odd or even) on which the application should load. (1 =
#' Monday on odd weeks, 2 = Tuesday on odd weeks, ..., 13 = Saturday on even
#' weeks, 14 = Sunday on even weeks).
#' - Others: `publish_day` has no effect, `today` is used.
#'
#' @return A date object to be used as the report date for initializing the app.
#'
#' @export
#'
#' @family dates
#' @family app load
#'
fct_set_report_date_init <- function(today, frequency, publish_day, app_end_date = NULL) {
  log_info("fct_set_report_date_init, passed date:", today, level = 2)

  # Only if frequency is 'Fortnightly' use the publish_day to determine the week
  # number on which the app should be loaded
  if (frequency == "Fortnightly") {
    week_num <- lubridate::isoweek(today)
    if (!publish_day %in% c(1:7)) {
      publish_day <- publish_day - 7
      offset_week <- if ((week_num %% 2) == 1) 1 else 0
    } else {
      offset_week <- if ((week_num %% 2) == 1) 0 else 1
    }
  }

  report_date <- switch(
    frequency,
    # frequency_id 1
    "Daily" = today,
    # frequency_id 2
    "Weekly" = lubridate::ceiling_date(
      today,
      unit = "week",
      week_start = publish_day,
      change_on_boundary = FALSE
    ),
    # frequency_id 3
    "Monthly" = lubridate::ceiling_date(today, unit = "month", change_on_boundary = FALSE) -
      1 +
      publish_day,
    # frequency_id 4
    "Quarterly" = lubridate::ceiling_date(today, unit = "quarter", change_on_boundary = FALSE) -
      1 +
      publish_day,
    # frequency_id 8
    "Fortnightly" = lubridate::ceiling_date(
      today,
      unit = "week",
      week_start = publish_day,
      change_on_boundary = FALSE
    ) +
      lubridate::dweeks(offset_week),
    # other frequencies
    today
  )

  # If an app has stopped, set the report date to the end date.
  if (shiny::isTruthy(app_end_date < report_date)) {
    report_date <- app_end_date
  }

  log_info("Report date (", frequency, ") set to: ", report_date, level = 2, sep = "")

  return(report_date)
}
