#' pivot market survey data
#' @description This function takes two data.tables as input arguments and uses
#' these to return a final pivoted data.table to be passed to rendering functions.
#' @param dt_market_survey data.table containing the market survey data
#' @param dt_market_content data.table object containing the app metadata
#' @return A data.table that has been pivoted (for user display)
#' @export
fct_market_survey_pivot <- function(dt_market_survey, dt_market_content) {
  log_info("fct_market_survey_pivot", level = 2)

  dt <- data.table::copy(dt_market_survey)

  # Create value source table ----
  ## to define value source by QUOTE_ID
  dt_sources <- unique(dt[, .(QPT_MID, MARKET_SURVEY_ITEM_ID, VALUE_SOURCE)]) %>%
    data.table::dcast(QPT_MID + MARKET_SURVEY_ITEM_ID ~ VALUE_SOURCE, value.var = "VALUE_SOURCE")

  dt_sources[, VALUE_SOURCE := NA_character_]

  # Update VALUE_SOURCE ----
  ## in the following order of precedence:
  ## 1. INPUT
  ## 2. MS
  ## 3. NEW
  if (!is.null(dt_sources$INPUT)) {
    dt_sources[!is.na(INPUT) & is.na(VALUE_SOURCE), VALUE_SOURCE := "INPUT"]
  }

  if (!is.null(dt_sources$MS)) {
    dt_sources[!is.na(MS) & is.na(VALUE_SOURCE), VALUE_SOURCE := "MS"]
  }

  if (!is.null(dt_sources$NEW)) {
    dt_sources[!is.na(NEW) & is.na(VALUE_SOURCE), VALUE_SOURCE := "NEW"]
  }

  dt[dt_sources, VALUE_SOURCE := i.VALUE_SOURCE, on = c("QPT_MID", "MARKET_SURVEY_ITEM_ID")]

  # Pivot data ----
  ## Remove cols that are specific to QUOTE_PRICETYPE
  cols <- c(
    "QUOTE_PRICETYPE_ID",
    "ALLOWUPLOAD_YN",
    "IN_MARKET_CONTENT",
    "MS_VALUE",
    "INPUT_VALUE",
    "NEW_VALUE"
  )
  dt <- dt[, .SD, .SDcols = -cols]

  ## Pivot by PRICETYPE_ADJ to include values for high/low/mids on the same row
  cols_pivot <- c("PT", "DECIMALPLACES", "VALUE", "PCT_LIMIT")

  dt_pivot <- data.table::dcast(dt, ... ~ PRICETYPE_ADJ, value.var = cols_pivot)

  # Check columns ----
  ## Rename columns
  cols_new <- gsub("VALUE_", "", names(dt_pivot))

  data.table::setnames(dt_pivot, names(dt_pivot), cols_new)

  ## Create price type columns if any are missing
  pt_adj_check <- c("LOW", "HIGH", "MID")

  for (x in pt_adj_check) {
    if (!x %in% names(dt_pivot)) {
      dt_pivot[, eval(x) := NA]
      dt_pivot[, eval(paste0("DECIMALPLACES_", x)) := NA]
      dt_pivot[, eval(paste0("PCT_LIMIT_", x)) := NA]
      dt_pivot[, eval(paste0("PT_", x)) := NA]
    }
  }

  ## Update existing columns with MID values
  dt_pivot[, `:=`(PT = PT_MID, DECIMALPLACES = DECIMALPLACES_MID, PCT_LIMIT = PCT_LIMIT_MID)]

  # Get `dt_market_content` cols ----
  dt_pivot[
    dt_market_content,
    `:=`(
      QUOTE_PRICETYPE_ID = i.QUOTE_PRICETYPE_ID,
      MARKET = i.MARKET,
      SECTION = i.SECTION,
      SECTION_DISPLAY_ORDER = i.SECTION_DISPLAY_ORDER,
      TYPE = i.TYPE
    ),
    on = c("CODE_ID", "TS", "CF", "PT")
  ]

  # Select columns ----
  cols_ret <- c(
    ## Code ----
    "MARKET_SURVEY_ITEM_ID",
    "QPT_MID",
    "QUOTE_ID",
    "CODE_ID",
    "TS",
    "CF",
    "PT_LOW",
    "PT_HIGH",
    "PT_MID",
    "PA_CODE",
    "CODE_DESCRIPTION",
    "TYPE",
    "OUT_DIFF_TYPE",
    "EDIT_MID",
    "FREQUENCY",
    "REGION",
    "MARKET",
    "DISPLAY_ORDER",
    "SECTION",
    "SECTION_DISPLAY_ORDER",
    ## Forward ----
    "TIMING",
    ## Differential ----
    "DIFF_BASE",
    "DBR_TIMING",
    ## Price ----
    "DECIMALPLACES_LOW",
    "DECIMALPLACES_HIGH",
    "DECIMALPLACES_MID",
    "PUBLICATION_DATE",
    "PRICE_CATEGORY_ID",
    "COMM_REPORTER",
    "COMM_METHOD_ID",
    "COMM_CONTACT_NAME",
    "COMM_TIMESTAMP",
    "COMM_TIMESTAMP_UTC",
    "TRADER_ID",
    "PORT_ID",
    "DELIVERY_PERIOD_ID",
    "DELIVERY_YEAR",
    "LOW",
    "HIGH",
    "MID",
    "UNIT_ID1",
    "UNIT_ID2",
    "NOTES",
    "INCLUDE",
    "ADD",
    "DELETED",
    ## Status ----
    "SOURCE",
    "PUBLISH",
    "EDITED"
  )

  dt_pivot <- dt_pivot[, .SD, .SDcols = cols_ret]

  # Set order ----
  # by MARKET, SECTION_DISPLAY_ORDER and DISPLAY_ORDER
  data.table::setorder(
    dt_pivot,
    MARKET,
    SECTION_DISPLAY_ORDER,
    DISPLAY_ORDER,
    MARKET_SURVEY_ITEM_ID
  )

  return(dt_pivot)
}
