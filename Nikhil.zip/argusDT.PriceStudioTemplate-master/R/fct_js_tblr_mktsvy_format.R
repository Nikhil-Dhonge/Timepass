#' Generate `argusDS.tabulator` Input Cells JavaScript Formatter
#'
#' @description
#' `fct_js_tblr_mktsvy_format()` Generates a JavaScript function that
#' formats and styles input cells in `argusDS.tabulator` table based on
#' specified conditions, including color highlighting and number formatting.
#'
#' @param target_column name of target column in the `argusDS.tabulator` table
#' @param target_column_DP decimal places to display in the target column.
#' @param format_region Region code for number formatting (e.g., 'en-US').
#' @param color_green color code for highlighting cells in an editable and
#' published state.
#' @param color_yellow color code for highlighting cells with missing values in
#' an editable and published state.
#' @param color_red color code for highlighting cells with invalid data
#' (e.g., LOW > HIGH).
#' @param color_highlight color code for highlighting cells with focus or
#' special attention.
#'
#' @returns
#' JavaScript code for `argusDS.tabulator` tables that formats and styles
#' input cells.
#'
#' @export
#'
#' @family   JavaScript argusDS.tabulator
#'
fct_js_tblr_mktsvy_format <- function(
  target_column,
  target_column_DP,
  format_region,
  color_green,
  color_yellow,
  color_red,
  color_highlight
) {
  htmlwidgets::JS(glue::glue(
    " function(cell) {

        let data = cell.getRow().getData();

        if (data.<<target_column>> === '' || data.<<target_column>> === null) {
          rv = cell.getValue();
        } else {
          dp = parseFloat(data.<<target_column_DP>>);
          rv = Intl.NumberFormat('<<format_region>>', {minimumFractionDigits: dp}).format(cell.getValue());
        }

        if (data.<<target_column_DP>> === null) {
          return rv
        }

        if (data.PUBLISH == true) {
          cell.getElement().style.backgroundColor = '<<color_green>>';
        }

        if ((data.<<target_column>> === '' || data.<<target_column>> === null)) {
          cell.getElement().style.backgroundColor = '<<color_yellow>>';
        }

        return rv;
      }",
    .open = "<<",
    .close = ">>"
  ))
}
