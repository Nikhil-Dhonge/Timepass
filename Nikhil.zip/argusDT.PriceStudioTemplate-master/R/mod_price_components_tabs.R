#' mod_price_components_tabs UI Function
#' @description A shiny Module.
#' @param id,title,navset_tab_id,session Internal parameters for {shiny}.
#' @noRd

mod_price_components_tabs_ui <- function(
  id,
  title,
  navset_tab_id,
  session = shiny::getDefaultReactiveDomain()
) {
  ns <- shiny::NS(id)

  log_info("mod_price_components_tabs_ui:", get_ns(ns), level = 3, session = session)

  id_nav_panel <- ns("nav_panel")
  id_div <- ns("div")
  id_tabulator <- ns("tabulator")

  log_info("nav panel ID:", id_nav_panel, level = 4, session = session)

  log_info("div ID:", id_div, level = 4, session = session)

  bslib::nav_insert(
    id = navset_tab_id,
    position = "before",
    select = TRUE,
    session = session,

    nav = bslib::nav_panel(
      id = id_nav_panel,
      title = title,
      value = id_nav_panel,

      bslib::layout_columns(
        col_widths = 12,
        min_height = "65vh",

        htmltools::tagList(
          htmltools::tags$div(
            id = id_div,
            style = "overflow-x: auto; padding-top: 0.5rem;",
            class = "main-box",

            shinyjs::hidden(
              htmltools::tags$div(
                id = ns("error_message_price_components"),
                htmltools::tags$h5("No price components available for today.")
              )
            ),

            argusDS.tabulator::tabulatorOutput(
              outputId = id_tabulator,
              height = "100%",
              width = "auto"
            )
          )
        )
      )
    )
  )
}

#' mod_price_components_tabs Server Functions
#' @param id,price_components,r parameters
#' @noRd
mod_price_components_tabs_server <- function(id, price_components, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_price_components_tabs_server:", get_ns(ns), level = 3, session = session)

    output$tabulator <- argusDS.tabulator::renderTabulator({
      log_info("tabulatorOutput ID:", ns("tabulator"), level = 4)

      if (is_truthy(price_components)) {
        shinyjs::hide("error_message_price_components")

        argusDT.PriceStudioMain::fct_render_tabulator_auto(price_components)
      } else {
        shinyjs::show("error_message_price_components")
      }
    })
  })
}
