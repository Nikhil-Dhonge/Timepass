#' Progress Bar UI Module
#'
#' @description
#' `mod_progressbar_ui()` Module for creation of [shinyWidgets::progressBar] UI
#' element
#'
#' @inheritParams shinyWidgets::progressBar
#'
#' @returns
#' [shiny::tagList] UI element that consists of a [shinyWidgets::progressBar]
#' widget wrapped inside a [shiny::div] division.
#'
#' @family shiny module
#'
mod_progressbar_ui <- function(
  id,
  title,
  value = 0,
  total = 100,
  display_pct = TRUE,
  size = c("xxs", "xs", "sm")[2],
  status = "danger",
  striped = TRUE
) {
  ns <- shiny::NS(id)

  log_info("mod_progressbar_ui ns:", get_ns(ns), level = 4)

  inputId <- ns("progressbar")

  log_info("progressBar ID:", inputId, level = 5)

  shiny::tagList(
    htmltools::tags$div(
      shinyWidgets::progressBar(
        id = inputId,
        title = title,
        value = value,
        total = total,
        display_pct = display_pct,
        size = size,
        status = status,
        striped = striped
      )
    )
  )
}


#' Action Button Server Module
#'
#' @description
#' `mod_progressbar_server()` Server-side logic for `mod_progressbar_ui`
#' with updates total, count and styling based on values passed in.
#'
#' @inheritParams shinyWidgets::updateProgressBar
#'
#' @returns
#' Side effects include:
#'  - updates to the progress bar
#'
#' @family shiny module
#'
mod_progressbar_server <- function(id, value, total, title) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_progressbar_server ns:", get_ns(ns), level = 4)

    inputId <- ns("progressbar")

    log_info("progressBar ID:", inputId, level = 5)

    if (total == 0) {
      pct <- 0
    } else {
      pct <- round(value / total * 100, 2)
    }
    status <- if (pct < 25) {
      "danger"
    } else if (pct < 100) {
      "warning"
    } else {
      "success"
    }

    shinyWidgets::updateProgressBar(
      id = inputId,
      value = value,
      total = total,
      status = status,
      title = title
    )
  })
}
