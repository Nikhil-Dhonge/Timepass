#' Indesign UI Function
#' @description A shiny Module.
#' @param id,input,output,session Internal parameters for {shiny}.
#' @noRd
mod_indesign_ui <- function(id) {
  ns <- shiny::NS(id)

  log_info("mod_indesign_ui ns:", get_ns(ns), level = 2)

  htmltools::tags$div(
    class = "main-nav",

    bslib::layout_columns(
      col_widths = 12,
      row_heights = list("auto", 1),
      bslib::layout_columns(
        col_widths = c(2, 2, 5, 3),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,

          #### Table picker ----
          argusDT.PriceStudioMain::mod_pickerinput_ui(
            id = ns("selected_tables"),
            choices = "",
            disabled_msg = if (length(golem::get_golem_options("regions")) > 1) {
              "Refresh InDesign data first..."
            } else {
              NULL
            },
            options = list(title = "Select tables", `actions-box` = TRUE),
            multiple = TRUE
          ),

          #### Refresh Data ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("refresh_indesign"),
            label = "1. Refresh Data",
            disabled_msg = if (length(golem::get_golem_options("regions")) > 1) {
              "Select a region first..."
            } else {
              NULL
            },
            icon = shiny::icon("refresh", lib = "glyphicon")
          ),

          #### Send tables ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("send_tables"),
            label = "2. Send Tables",
            disabled_msg = "Refresh InDesign data first...",
            icon = shiny::icon("send", lib = "glyphicon")
          )
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,

          #### Send charts ----
          shiny::uiOutput(outputId = ns("send_charts"))
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = c(6, 6, 4, 4, 4),
          style = "text-align: center",

          #### Show tables ----
          argusDT.PriceStudioMain::mod_actionbutton_ui(
            id = ns("show_tables"),
            label = "Show Tables",
            disabled_msg = "Refresh InDesign data first...",
            icon = shiny::icon("table", lib = "font-awesome")
          ),

          #### Download tables ----
          mod_download_excel_ui(
            id = ns("download_tables"),
            label = "Download Tables",
            disabled_msg = "Refresh InDesign data first...",
            icon = shiny::icon("cloud-download", lib = "glyphicon"),
            style = "font-size: 16px"
          ),

          ### DB Source radio buttons ----
          argusDT.PriceStudioMain::mod_radiobutton_ui(
            id = ns("indesign_source"),
            label = NULL,
            choices = c("Live", "Saved"),
            inline = TRUE,
            status = "info",
            icon = "check",
            disabled_msg = "Refresh InDesign data first...",
          ),

          ### PA code switch ----
          argusDT.PriceStudioMain::mod_switchinput_ui(
            id = ns("pacode_mode_selection"),
            label = "PA mode",
            disabled_msg = "Refresh InDesign data first...",
            value = get_config("indesign_pacode_mode_initial")
          ),

          ### Indesign folder radio button ----
          argusDT.PriceStudioMain::mod_radiobutton_ui(
            id = ns("indesign_folder_selection"),
            label = NULL,
            choices = c("in", "err"),
            selected = get_config("indesign_folder_initial"),
            inline = TRUE,
            status = "info",
            icon = "check",
            disabled_msg = "Refresh InDesign data first..."
          )
        ),

        bslib::layout_columns(
          class = "main-box",
          col_widths = 12,
          id = ns("status-box"),
          mod_prices_status_ui(id = ns("ind_status"))
        )
      ),

      bslib::layout_columns(
        class = "main-box",
        col_widths = 12,
        min_height = "65vh",
        # IND tables ----
        id = ns("tables-row"),
        htmltools::tags$div(id = ns("box_insert_tables"))
      )
    )
  )
}


#' Indesign Server Functions
#' @param id A shiny id.
#' @param r The global environment variable 'r'.
#' @noRd
mod_indesign_server <- function(id, r) {
  shiny::moduleServer(id, function(input, output, session) {
    ns <- session$ns

    log_info("mod_indesign_server:", get_ns(ns), level = 2)

    # Initialise triggers ----
    gargoyle::init(ns("ind_status-review_corrections"))

    # Modules ----
    ## Price status and correction box ----
    mod_prices_status_server(id = "ind_status", r, is_summary = TRUE)

    # Add widgets ----
    ## Table picker ----
    argusDT.PriceStudioMain::mod_pickerinput_server(
      id = "selected_tables",
      rv = r$rv,
      choices_rv = "tables",
      enable_trigger = "get_indesign_status",
      disable_trigger = "disable_market",
      ignoreNULL = FALSE
    )

    ## Source radio button ----
    argusDT.PriceStudioMain::mod_radiobutton_server(
      id = "indesign_source",
      rv = r$rv,
      enable_trigger = "get_indesign_status",
      disable_trigger = "disable_buttons"
    )

    ## Indesign folder radio button ----
    argusDT.PriceStudioMain::mod_radiobutton_server(
      id = "indesign_folder_selection",
      rv = r$rv,
      enable_trigger = "get_indesign_status",
      disable_trigger = "disable_buttons"
    )

    ## Linkfile view radio button ----
    argusDT.PriceStudioMain::mod_switchinput_server(
      id = "pacode_mode_selection",
      rv = r$rv,
      enable_trigger = "auto_show_ind_tables",
      disable_trigger = "disable_buttons"
    )

    ## Refresh button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "refresh_indesign",
      triggers = c(
        "show_waiter",
        "fill_empty_market",
        "get_ind_tables",
        "create_ind_tables",
        "get_indesign_status",
        "hide_waiter"
      ),
      enable_trigger = "enable_market",
      disable_trigger = "disable_market"
    )

    ## Get tables button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "show_tables",
      triggers = "auto_show_ind_tables",
      enable_trigger = "get_indesign_status",
      disable_trigger = "disable_buttons"
    )

    ## Send Tables button ----
    argusDT.PriceStudioMain::mod_actionbutton_server(
      id = "send_tables",
      triggers = c("show_waiter", "send_tables", "hide_waiter"),
      enable_trigger = "enable_send_tables_button",
      disable_trigger = "disable_send_tables_button"
    )

    ## Download linkfile button ----
    mod_download_excel_server(
      id = "download_tables",
      r = r,
      enabled = FALSE
    )

    # Add obs. events ----
    ## Get InDesign Tables ----
    shiny::observeEvent(
      gargoyle::watch("get_ind_tables"),
      {
        log_info("observeEvent:", "get_ind_tables", level = 2, session = session)

        ## Get raw link file
        wb <- tryCatch(
          {
            argusDT.S3::s3_read_using(
              FUN = openxlsx::loadWorkbook,
              object = file.path(r$rv$s3_linkfile_raw_dir, r$linkfile_filename),
              bucket = get_config("s3_bucket")
            )
          },
          error = function(e) {
            e
          }
        )

        ## Notify user if the file is missing
        if (any(class(wb) == "error")) {
          log_warn(
            "The following LinkFile",
            r$linkfile_filename,
            "does not exist in",
            r$rv$s3_linkfile_raw_dir,
            prompt = TRUE,
            type = "info",
            title = "LinkFile missing"
          )
        } else {
          ## Get a data.table with all ranges that contain "IND_" from raw link file
          r$rv$dt_ind_ranges <- tryCatch(
            argusDT.PriceStudioMain::fct_get_ind_ranges(wb),
            error = function(e) e
          )

          if (any(class(r$rv$dt_ind_ranges) == "error")) {
            log_warn(
              "No named ranges found in the following LinkFile",
              r$linkfile_filename,
              "in",
              r$rv$s3_linkfile_raw_dir,
              prompt = TRUE,
              type = "info",
              title = "Named ranges missing"
            )
          } else if (nrow(r$rv$dt_ind_ranges) == 0) {
            log_warn(
              "No IND* named ranges found in the following LinkFile",
              r$linkfile_filename,
              "in",
              r$rv$s3_linkfile_raw_dir,
              prompt = TRUE,
              type = "info",
              title = "IND* named ranges missing"
            )
          } else {
            ## Duplicate the tables only when single IND range is present in Dashboard
            if (nrow(r$rv$dt_ind_ranges) == 1) {
              r$rv$dt_ind_ranges <- rbind(r$rv$dt_ind_ranges[1, ], r$rv$dt_ind_ranges[1, ])
            }

            ## Get a list of data.tables with "IND_" ranges from raw link file
            r$rv$ind_tables_raw <- argusDT.PriceStudioMain::fct_get_ind_tables(
              wb,
              r$rv$dt_ind_ranges
            )

            ## Keep selection
            r$rv$tables <- r$rv$dt_ind_ranges$RANGE
            r$rv$selected_tables <- r$rv$tables
          }
        }
      },
      ignoreInit = TRUE
    )

    ## Create IndTables ----
    shiny::observeEvent(
      gargoyle::watch("create_ind_tables"),
      {
        log_info("observeEvent:", "create_summary", level = 2)

        r$rv$dt_indesign <- fct_create_prices_table(
          report_date = r$rv$report_date,
          all_dates = r$rv$all_dates,
          dt_market_content = r$rv$dt_market_content,
          dt_codemaster = unique(
            r$rv$dt_codemaster[QUOTE_ID %in% r$rv$quote_id],
            by = "QUOTE_PRICETYPE_ID"
          ),
          dt_prc_asmp = r$rv$dt_prc_asmp,
          dt_holidays = r$rv$dt_holidays,
          fwd_list_start = r$rv$fwd_list_start,
          fwd_list_count = r$rv$fwd_list_count,
          dbr_list_start = r$rv$dbr_list_start,
          dbr_list_count = r$rv$dbr_list_count,
          calendars = r$rv$all_calendars
        )

        r$rv$dt_prices_live_all_regions <- argusDT.PriceStudioMain::fct_get_prices_repository(
          quote_id = r$rv$quote_id,
          date_from = r$rv$from_date,
          date_to = r$rv$report_date,
          live_count = r$data_points,
          db_env = r$rv$db_env,
          connection = r$rv$ora_connection
        )

        r$rv$dt_indesign <- argusDT.PriceStudioMain::fct_combine_price_data(
          report_date = r$rv$report_date,
          dt_prices_all = r$rv$dt_indesign,
          dt_prices_live = r$rv$dt_prices_live_all_regions,
          dt_prices_stg = r$rv$dt_prices_stg_all_regions,
          dt_latest_notes = NULL,
          dt_prices_input = NULL,
          dt_pricetype = argusDT.PriceStudioMain::dt_pricetype,
          tab = "InDesign",
          include_imported = TRUE,
          from_live = if (r$rv$indesign_source == "Live") TRUE else FALSE
        )

        ### Add ERROR and CORRECTION columns
        argusDT.PriceStudioMain::fct_check_prices(r$rv$dt_indesign, is_summary = TRUE)
      },
      ignoreInit = TRUE
    )

    ## Get status ----
    shiny::observeEvent(
      gargoyle::watch("get_indesign_status"),
      {
        log_info("observeEvent:", "get_indesign_status", level = 2)

        ## Check only records that are due to be uploaded today
        shiny::req(nrow(r$rv$dt_indesign[EXPECTED_DATE == r$rv$report_date]) > 0)

        mod_download_excel_server(id = "download_tables", r = r, enabled = TRUE)

        gargoyle::trigger("update_send_tables_button_status")
      },
      ignoreInit = TRUE
    )

    ## Auto show indesign ----
    shiny::observeEvent(
      gargoyle::watch("auto_show_ind_tables"),
      {
        log_info("observeEvent:", "auto_show_ind_tables", level = 1)

        gargoyle::trigger("show_waiter")
        gargoyle::trigger("populate_ind_tables")
        gargoyle::trigger("show_ind_tables")
        gargoyle::trigger("update_send_tables_button_status")

        gargoyle::trigger("hide_waiter")
      },
      ignoreInit = TRUE
    )

    ## Populate InDesign Tables ----
    shiny::observeEvent(
      gargoyle::watch("populate_ind_tables"),
      {
        log_info("observeEvent:", "populate_ind_tables", level = 2, session = session)

        shiny::req(!is.null(r$rv$ind_tables_raw))

        ## Populate the data.tables with final values from price data.table
        r$rv$ind_tables_calc <- argusDT.PriceStudioMain::fct_calc_ind_tables(
          ind_tables = r$rv$ind_tables_raw,
          dt_prices = r$rv$dt_indesign,
          dt_exrates = r$rv$dt_exrates,
          dt_deals = r$rv$dt_deals,
          dt_bbs_deals = r$rv$dt_bbs_deals,
          data_source = r$rv$indesign_source,
          report_date = r$rv$report_date,
          pa_code_mode = r$rv$pacode_mode_selection,
          replace_errors = FALSE,
          showCancelButton = FALSE,
          calendars = r$rv$all_calendars,
          dt_market_content = r$rv$dt_market_content,
          r = r
        )
      },
      ignoreInit = TRUE
    )

    ## Auto Refresh Pa Mode ----
    shiny::observeEvent(
      r$rv$pacode_mode_selection,
      {
        log_info("observeEvent:", "r$rv$pacode_mode_selection", level = 1)

        gargoyle::trigger("auto_show_ind_tables")
      },
      ignoreInit = TRUE
    )

    ## Auto Refresh Live and Staged ----
    shiny::observeEvent(
      r$rv$indesign_source,
      {
        log_info("observeEvent:", "r$rv$indesign_source", level = 1)

        gargoyle::trigger("auto_show_ind_tables")
        gargoyle::trigger("update_send_tables_button_status")
      },
      ignoreInit = TRUE
    )

    ## Show InDesign tables ----
    shiny::observeEvent(
      gargoyle::watch("show_ind_tables"),
      {
        log_info("observeEvent:", "show_ind_tables", level = 2)

        shiny::req(!is.null(r$rv$ind_tables_calc$final_tbls))

        fct_show_ind_tables(input, session, r, box_id = "box_insert_tables")
      },
      ignoreInit = TRUE
    )

    ## Send tables ----
    shiny::observeEvent(
      gargoyle::watch("send_tables"),
      {
        log_info("observeEvent:", "send_tables", level = 2)

        shiny::req(!is.null(r$rv$ind_tables_raw))

        ### Populate tables from Live DB with PA code mode = TRUE
        r$rv$ind_tables_calc <- argusDT.PriceStudioMain::fct_calc_ind_tables(
          ind_tables = r$rv$ind_tables_raw,
          dt_prices = r$rv$dt_indesign,
          dt_exrates = r$rv$dt_exrates,
          dt_deals = r$rv$dt_deals,
          dt_bbs_deals = r$rv$dt_bbs_deals,
          data_source = "Live",
          report_date = r$rv$report_date,
          pa_code_mode = r$rv$pacode_mode_selection,
          replace_errors = TRUE,
          showCancelButton = TRUE,
          inputId = "log_warn_send_tables",
          calendars = r$rv$all_calendars,
          dt_market_content = r$rv$dt_market_content,
          r = r
        )

        ### Create excel file and save it in S3
        if (length(r$rv$ind_tables_calc$err_list) == 0) {
          gargoyle::trigger("send_tables_censhare")
        }
      },
      ignoreInit = TRUE
    )

    ## OK button on Modal ----
    shiny::observeEvent(
      input$log_warn_send_tables,
      {
        log_info("observeEvent:", "input$log_warn_send_tables", level = 2)

        if (input$log_warn_send_tables == TRUE) {
          gargoyle::trigger("send_tables_censhare")
        }
      },
      ignoreInit = TRUE
    )

    ## Send linkfile to Censhare folder ----
    shiny::observeEvent(
      gargoyle::watch("send_tables_censhare"),
      {
        log_info("observeEvent:", "send_tables_censhare", level = 2)

        ### Create the linkfile and save it in S3 folder
        output_name <- argusDT.PriceStudioMain::fct_create_ind_tables_file(
          tbl_list = r$rv$ind_tables_calc$final_tbls,
          save_dir = r$rv$s3_linkfile_dir,
          s3_bucket = get_config("s3_bucket"),
          censharetag = r$censhare_tag,
          raw_name = r$linkfile_filename,
          ind_ranges = r$rv$dt_ind_ranges,
          report_date = r$rv$report_date
        )

        wc <- tryCatch(
          {
            argusDT.PriceStudioMain::fct_send_file_censhare(
              output_name = output_name,
              censhare_folder = file.path(
                get_config("indesign_link_dir"),
                r$rv$indesign_folder_selection
              )
            )
          },
          warning = function(w) {{ w }},
          error = function(e) {{ e }}
        )

        ### Notify if failed to send
        if (any(class(wc) == "warning") || any(class(wc) == "error")) {
          log_warn(
            "Failed to send the file",
            output_name,
            "to",
            file.path(get_config("indesign_link_dir"), r$rv$indesign_folder_selection),
            prompt = TRUE,
            title = "Send to Censhare",
            type = "error"
          )
        } else {
          log_warn(
            "The following file",
            output_name,
            "has been sent to",
            file.path(get_config("indesign_link_dir"), r$rv$indesign_folder_selection),
            prompt = TRUE,
            title = "Send to Censhare",
            type = "success"
          )
        }
      },
      ignoreInit = TRUE
    )

    ## Send Charts ----
    output$send_charts <- shiny::renderUI({
      if (!shiny::isTruthy(r$charts_folders)) {
        # Return a disabled button if no chart folders are available
        argusDT.PriceStudioMain::mod_actionbutton_ui(
          id = ns("netcharts"),
          label = "3. Send Charts",
          disabled_msg = "No charts available.",
          tooltip_placement = "top",
          shiny::icon("chart-line", lib = "font-awesome")
        )
      } else {
        # Create a list of shiny tags to display in the UI, each shiny tag
        # represents a chart folder
        shiny_tags <- list()

        for (i in 1:length(r$charts_folders)) {
          current_project <- r$charts_folders[[i]]

          chart_url <- paste0(
            get_config("indesign_chart_server"),
            get_config("indesign_chart_jsp"),
            "?thisProject=",
            current_project,
            "&censhareTag=",
            format(r$rv$report_date, "%Y%m%d"),
            r$censhare_tag,
            "&censhareChartOutputLocation=",
            file.path(get_config("indesign_chart_dir"), r$rv$indesign_folder_selection),
            "/&alternateOutputLocation=&genericNaming=False&outputXML=False"
          )

          log_info(paste("renderUI:", chart_url), level = 2)

          shiny_tags[[i]] <- shiny::tags$a(
            shiny::div(
              shiny::icon("chart-line", lib = "font-awesome"),
              glue::glue("3. Send Charts ({current_project})"),
              class = "indesign-send-charts-button"
            ),
            target = "_blank",
            href = chart_url
          )
        }
        shiny_tags
      }
    })

    ## Clear indesign tables ----
    shiny::observeEvent(
      gargoyle::watch("clear_ind_tables"),
      {
        log_info("observeEvent:", "clear_ind_tables", level = 2)

        fct_clear_tables(input, session, r, displayed_tables = r$rv$displayed_tables)

        r$rv$displayed_tables <- NULL
      },
      ignoreInit = TRUE
    )

    ## Enable or disable Send Tables button based on source selected ---
    shiny::observeEvent(
      gargoyle::watch("update_send_tables_button_status"),
      {
        log_info("observeEvent:", "update_send_tables_button_status", level = 2)

        if (r$rv$indesign_source == "Saved") {
          gargoyle::trigger("disable_send_tables_button")
        } else {
          gargoyle::trigger("enable_send_tables_button")
        }
      },
      ignoreInit = TRUE
    )

    ## Review corrections specific to module ----
    r$rv$observeEvent_correction_box <- shiny::observeEvent(
      gargoyle::watch(ns("ind_status-review_corrections")),
      {
        log_info("observeEvent:", ns("ind_status-review_corrections"), level = 2)

        r$rv$dt_correction_review <- data.table::copy(r$rv$dt_pivot_summary)
        gargoyle::trigger("review_corrections")
      },
      ignoreInit = TRUE
    )
  })
}
