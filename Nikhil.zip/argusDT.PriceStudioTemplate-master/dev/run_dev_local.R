# Clear console
cat("\014")

# Set options here
Sys.setenv(GOLEM_CONFIG_ACTIVE = "dev")
options(gargoyle.talkative = TRUE)
options(golem.app.prod = FALSE)
options(scipen = 999)
options(digits = 15)
# To allow shiny::fileInput() uploads up to 20 MB
options(shiny.maxRequestSize = 20 * 1024^2)

# Detach all loaded packages and clean your environment
golem::detach_all_attached()
rm(list = ls(all.names = TRUE))

## Uncomment to load local packages
# devtools::load_all("../argusDS.tabulator")
# devtools::load_all("../argusDT.S3")
# devtools::load_all("../argusDT.PriceStudioFormulas")
# devtools::load_all("../argusDT.PriceStudioMain")

# Document and reload your package
pkgload::load_all()

## Uncomment to debug functions
# debug(argusDT.PriceStudioFormulas::fct_val_outright_1)

# --- START: WORKAROUND FOR POSITRON IDE's ARK KERNEL ----

#' A robust, OS-aware function to force opening a URL in an external browser.
#' @param url The URL to open.
force_external_browser <- function(url) {
  os_name <- Sys.info()["sysname"]

  message("Attempting to launch browser for OS: ", os_name)

  if (os_name == "Windows") {
    # On Windows, `start` is a cmd.exe built-in, not a program.
    # The correct R function to use the Windows Shell API is `shell.exec()`.
    message("Using shell.exec() for Windows...")
    shell.exec(url)
  } else if (os_name == "Darwin") {
    # On macOS, `open` is the command-line utility to open files/URLs.
    message("Using 'open' command for macOS...")
    system2("open", args = shQuote(url), wait = FALSE, stdout = FALSE, stderr = FALSE)
  } else if (os_name == "Linux") {
    # On Linux, `xdg-open` is the standard command.
    message("Using 'xdg-open' command for Linux...")
    system2("xdg-open", args = shQuote(url), wait = FALSE, stdout = FALSE, stderr = FALSE)
  } else {
    warning("Could not determine the OS command to open a browser.")
    message("Please open this URL manually: ", url)
  }
}

# Find an available port and construct the URL
port <- httpuv::randomPort()
url <- paste0("http://127.0.0.1:", port)

message("App will run on: ", url)
message("Scheduling external browser launch...")

# Schedule the browser to launch in 1 seconds.
later::later(
  function() {
    force_external_browser(url)
  },
  delay = 1
)

# Run the application in the main process. ----
run_app(options = list(port = port, launch.browser = FALSE))

# --- END: WORKAROUND ---
