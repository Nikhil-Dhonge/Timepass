# Setting up the environment ----
golem::detach_all_attached()
rm(list = ls(all.names = TRUE))

### --> Function name replaced here for notes, etc:
testing_function <- "fct_calculate_prices"

# Create data ----
## 1. Add a browser just before the function to be benchmarked.
## 2. Run the app to the browser.

## 3. Set any reactive values to a list:
r$rv <- shiny::reactiveValuesToList(r$rv)

## 4. assign all of the items in the local environment to the global environemnt.
##    Some commonly used examples are provided here:
assign("r", r, envir = .GlobalEnv)
assign("dt_today", dt_today, envir = .GlobalEnv)
assign("dt_prices", dt_prices, envir = .GlobalEnv)
assign("dt_deals", dt_deals, envir = .GlobalEnv)
assign("dt_exrates", dt_exrates, envir = .GlobalEnv)
assign("dt_fixed_conv", dt_fixed_conv, envir = .GlobalEnv)
assign("dt_prc_asmp", dt_prc_asmp, envir = .GlobalEnv)
assign("exrate_time", exrate_time, envir = .GlobalEnv)
assign("market", market, envir = .GlobalEnv)
assign("dt_edit_latest", dt_edit_latest, envir = .GlobalEnv)

## 5. Exit the browser.
## 6. Define a name for the RData file (it should be descriptive to the contents).
##    An example can be generated with the lines below:
fn_note <- as.character(readline(
  prompt = "Describe the changes in a few words (blank for no changes): "
))

fn <- paste(
  fn_note,
  r$subtitle,
  r$rv$region,
  r$rv$market,
  r$rv$report_date,
  testing_function,
  sep = " - "
)

## 7. Save the environment:
save.image(paste0(fn, ".RData"))

#------------------------------------------------------------------------------#

# Initializing the environment ----
## 1. Empty environment
golem::detach_all_attached()
rm(list = ls(all.names = TRUE))

## 2. Load the RData file by selecting it from the Files panel

## 3. OPTIONAL: If it doesn't exist, create data.table file that results are saved to
dt_bm <- data.table::data.table(
  timestamp = structure(numeric(0), class = "POSIXct"),
  change = character(0),
  note = character(0),
  avg = numeric(0),
  stdev = numeric(0)
)
saveRDS(dt_bm, paste0("dt_bm_", testing_function, ".rds"))

## 4. Create function for benchmarking.
run_bm <- function(store_result = FALSE) {
  changes <- as.character(readline(
    prompt = "Describe the changes in a few words (blank for no changes): "
  ))

  result <- data.table::data.table(NULL)
  devtools::load_all("../argusDT.PriceStudioMain")
  devtools::load_all("../argusDT.PriceStudioFormulas")

  dt_bm <- data.table::as.data.table(readRDS(paste0("dt_bm_", testing_function, ".rds")))

  if (store_result == TRUE) {
    result <- argusDT.PriceStudioMain::fct_calculate_prices(
      report_date = r$rv$report_date,
      dt_prices = r$rv$dt_prices_all,
      dt_deals = r$rv$dt_deals,
      dt_exrates = r$rv$dt_exrates,
      dt_fixed_conv = r$rv$dt_fixed_conv,
      dt_prc_asmp = r$rv$region_dt_prc_asmp,
      exrate_time = r$rv$exrate_time,
      market = r$rv$market,
      dt_edit_latest = r$rv$dt_edit_latest,
      r = r
    )
  }

  res <- microbenchmark::microbenchmark(
    ## Place the function and arguments to be benchmarked here.
    ## fct_calculate_prices is given as an example.
    argusDT.PriceStudioMain::fct_calculate_prices(
      report_date = r$rv$report_date,
      dt_prices = r$rv$dt_prices_all,
      dt_deals = r$rv$dt_deals,
      dt_exrates = r$rv$dt_exrates,
      dt_fixed_conv = r$rv$dt_fixed_conv,
      dt_prc_asmp = r$rv$region_dt_prc_asmp,
      exrate_time = r$rv$exrate_time,
      market = r$rv$market,
      dt_edit_latest = r$rv$dt_edit_latest,
      r = r
    ),
    times = 20
  )

  if (store_result == TRUE & !is.null(result)) {
    saveRDS(result, paste0("Result - ", fn, ".rds"))
  }

  dt_bm <- rbind(
    dt_bm,
    list(
      timestamp = Sys.time(),
      change = changes,
      note = fn,
      avg = round(mean(res$time / 1000000)),
      stdev = round(sd(res$time / 1000000))
    )
  )

  saveRDS(dt_bm, paste0("dt_bm_", testing_function, ".rds"))

  readRDS(paste0("dt_bm_", testing_function, ".rds"))
}

# Run the benchmark ----
run_bm()
## Run the benchmark and store a copy of the result
run_bm(store_result = TRUE)

# Print table ----
## 1. Load data.table
dt_bm <- data.table::as.data.table(readRDS(paste0("dt_bm_", testing_function, ".rds")))

## 2. Add any additional statistics (if required)
dt_bm[, `:=`(`+95%` = avg + 2 * stdev, `-95%` = avg - 2 * stdev)]

## 3. Print table as markdown
knitr::kable(dt_bm, row.names = T)
knitr::kable(dt_bm[, note := NULL], row.names = T)
