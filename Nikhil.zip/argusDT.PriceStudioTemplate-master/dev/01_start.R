# Building a Prod-Ready, Robust Shiny Application.
#
# README: each step of the dev files is optional, and you don't have to
# fill every dev scripts before getting started.
# 01_start.R should be filled at start.
# 02_dev.R should be used to keep track of your development during the project.
# 03_deploy.R should be used once you need to deploy your app.

# First time install ----
if (!"renv" %in% installed.packages()) {
  install.packages("renv")
}
renv::install()

# Golem set up ----
## Fill DESCRIPTION ----
## Add meta data about your application
##
## /!\ Note: if you want to change the name of your app during development,
## either re-run this function, call golem::set_golem_name(), or don't forget
## to change the name in the app_sys() function in app_config.R /!\
##
if (!"golem" %in% installed.packages()) {
  install.packages("golem")
}
usethis::use_package("golem", type = "Imports")

if (!"devtools" %in% installed.packages()) {
  install.packages("devtools")
}
usethis::use_package("devtools", type = "Suggests")

golem::fill_desc(
  # The Name of the package containing the App
  pkg_name = "argusDT.PriceStudioTemplate",
  # The Title of the package containing the App
  pkg_title = "Price Assessment application for <Publication Name>",
  # The Description of the package containing the App
  pkg_description = "An internal Shiny application for entering <Publication Name> price assessments.",
  authors = person(
    given = "Argus Media",
    email = "data@argusmedia.com",
    role = c("cre", "aut", "cph")
  ),
  pkg_version = golem::get_golem_version(),
  repo_url = "https://github.com/Argus-Media-DS/argusDT.PriceStudioTemplate"
)

## Set {golem} options ----
golem::set_golem_options(app_prod = FALSE, talkative = TRUE)

## Favicon ----
# If you want to change the favicon (default is golem's one)
golem::use_favicon(path = "https://www.argusmedia.com/Media/favicon.ico")

## Add helper functions ----
golem::use_utils_ui()
golem::use_utils_server()


# Environment set up ----
## Edit .Rprofile ----
usethis::edit_r_profile(scope = "project")
## Paste the following into .Rprofile, save and restart Rstudio session
local({
  r <- getOption("repos")
  r["CRAN"] <- "https://cloud.r-project.org/"
  r["RSPM"] <- "https://rspm.argusmedia.com/live/latest/"
  options(repos = r)
})


## Edit .Renviron ----
usethis::edit_r_environ()
## Paste the following into .Renviron, save and restart Rstudio session
## Github and AWS keys will need to be obtained from the relevant sources
# AWS_ACCESS_KEY_ID=
# AWS_SECRET_ACCESS_KEY=
# AWS_SESSION_TOKEN=
# GITHUB_PAT=
# AWS_DEFAULT_REGION=eu-west-1
# RENV_CONFIG_AUTO_SNAPSHOT=FALSE

rstudioapi::restartSession()


## Initialize renv ----
if (!"renv" %in% installed.packages()) {
  install.packages("renv")
}
renv::init(bare = TRUE, restart = TRUE)


## Install dependencies ----
### CRAN dependencies ----
pkgs_cran <- c(
  "assertthat",
  "bslib",
  "connectapi",
  "config",
  "data.table",
  "gargoyle",
  "glue",
  "htmltools",
  "htmlwidgets",
  "lubridate",
  "magrittr",
  "pkgload",
  "purrr",
  "shiny",
  "shinyalert",
  "shinydashboard",
  "shinyjs",
  "shinyWidgets",
  "stringr",
  "waiter",
  "mirai"
)

#### Install packages and amend DESCRIPTION
install.packages(pkgs_cran, type = "binary")
purrr::walk(.x = pkgs_cran, .f = usethis::use_package)

### Argus dependencies ----
pkgs_argus <- c(
  "argusDS.tabulator",
  "argusDT.PriceStudioMain",
  "argusDT.PriceStudioFormulas",
  "argusDT.S3",
  "winboxr"
)

#### Install packages and amend DESCRIPTION
install.packages(pkgs_argus, type = "source")
purrr::walk(.x = pkgs_argus, .f = usethis::use_package)


## Setup tests ----
## Add one line by test you want to create
usethis::use_testthat(3)
usethis::use_test("utils_get_ns")
devtools::test()


## Create README ----
if (!"markdown" %in% installed.packages()) {
  install.packages("markdown")
}

if (!"rmarkdown" %in% installed.packages()) {
  install.packages("rmarkdown")
}

usethis::use_package("markdown", type = "Suggests")
usethis::use_package("rmarkdown", type = "Suggests")
usethis::use_proprietary_license(copyright_holder = "Argus Media Group")
usethis::use_readme_rmd()
usethis::use_lifecycle_badge("Experimental")


## Code Coverage ----
if (!"covr" %in% installed.packages()) {
  install.packages("covr")
}

if (!"DT" %in% installed.packages()) {
  install.packages("DT")
}

if (!"htmltools" %in% installed.packages()) {
  install.packages("htmltools")
}

usethis::use_package("covr", type = "Suggests")
rstudioapi::restartSession()
covr::report()
devtools::build_readme()


## Create manifest ----
if (!"rsconnect" %in% installed.packages()) {
  install.packages("rsconnect")
}
usethis::use_package("rsconnect", type = "Suggests")
rsconnect::writeManifest()


# Open 02_dev.R ----
rstudioapi::navigateToFile("dev/02_dev.R")
