# Building a Prod-Ready, Robust Shiny Application.
#
# README: each step of the dev files is optional, and you don't have to
# fill every dev scripts before getting started.
# 01_start.R should be filled at start.
# 02_dev.R should be used to keep track of your development during the project.
# 03_deploy.R should be used once you need to deploy your app.

# Common dev tasks ----
## Update keys ----
usethis::edit_r_environ()

## Restore packages ----
renv::restore()
renv::restore(exclude = c("argusDT.PriceStudioMain", "argusDT.PriceStudioFormulas"))

## Snapshot packages ----
renv::snapshot()
rsconnect::writeManifest()
devtools::build_readme(quiet = FALSE)

## Update version ----
usethis::use_version()
golem::set_golem_version(utils::packageVersion(pkgload::pkg_name()))
usethis::use_package("argusDT.PriceStudioMain", min_version = "1.5.19")
usethis::use_package("argusDT.PriceStudioFormulas", min_version = "1.3.22")

## Run checks ----
devtools::check()
devtools::document()
devtools::test()

## Load a local package ----
devtools::load_all("../argusDT.PriceStudioMain")

## Update a package ----
renv::refresh()
renv::update(prompt = FALSE, exclude = c("httr2", "connectapi", "paws.common"))
renv::update("argusDT.PriceStudioMain", prompt = FALSE)
renv::update("argusDT.PriceStudioFormulas", prompt = FALSE)
renv::update("argusDS.tabulator", exclude = c("htmltools", "bslib", "glue", "shiny", "rmarkdown"))


# Github ----
## Set up github actions ----
argusDS.ArgusThis::use_github_action("R-CMD-check") # automate R CMD checks
argusDS.ArgusThis::use_github_action("update_fork") # sync a fork with upstream
argusDS.ArgusThis::use_github_action("UAT-DEV-PR") # open pr dev --> uat


## Install from GitHub ----
devtools::install_github(
  repo = "Argus-Media-DS/argusDT.PriceStudioMain",
  ref = "",
  upgrade = "never"
)

devtools::install_github(
  repo = "Argus-Media-DS/argusDT.PriceStudioFormulas",
  ref = "",
  upgrade = "never"
)


# Creating files ----
## Add modules ----
## Create a module infrastructure in R/
golem::add_module(name = "<name>", with_test = TRUE)
golem::add_module(name = "<name>", with_test = TRUE)

## Add helper functions ----
## Creates fct_* and utils_*
golem::add_fct("<name>", with_test = TRUE)
golem::add_utils("<name>", with_test = TRUE)

## External resources
## Creates .js and .css files at inst/app/www
golem::add_js_file("<name>")
golem::add_css_file("<name>")
golem::add_sass_file("<name>")

## Add internal datasets ----
## If you have data in your package
usethis::use_data_raw(name = "<name>", open = TRUE)


# Open 01_start.R ----
rstudioapi::navigateToFile("dev/01_start.R")

# Open 03_deploy.R ----
rstudioapi::navigateToFile("dev/03_deploy.R")
