# Clear console
cat("\014")

# Set options here
Sys.setenv(GOLEM_CONFIG_ACTIVE = "dev")
options(gargoyle.talkative = TRUE)
options(golem.app.prod = FALSE)
options(scipen = 999)
options(digits = 15)
# To allow shiny::fileInput() uploads up to 20 MB
options(shiny.maxRequestSize = 20 * 1024^2)

# Detach all loaded packages and clean your environment
golem::detach_all_attached()
rm(list = ls(all.names = TRUE))

## Uncomment to load local packages
# devtools::load_all("../argusDT.PriceStudioFormulas")
# devtools::load_all("../argusDT.PriceStudioMain")
# devtools::load_all("../argusDS.tabulator")

# Document and reload your package
pkgload::load_all()

## Uncomment to debug functions
# debug(argusDT.PriceStudioFormulas::fct_val_outright_1)

# Run the application
run_app()
