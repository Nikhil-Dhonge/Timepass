# Building a Prod-Ready, Robust Shiny Application.
#
# README: each step of the dev files is optional, and you don't have to
# fill every dev scripts before getting started.
# 01_start.R should be filled at start.
# 02_dev.R should be used to keep track of your development during the project.
# 03_deploy.R should be used once you need to deploy your app.

# Test your app ----

## Run checks ----
## Check the package before sending to prod
devtools::check()
## Document or test separately
devtools::document()
devtools::test()


## Check coverage ----
rstudioapi::restartSession()
covr::report()


## Build readme ----
devtools::build_readme(quiet = FALSE)


## Write manifest ----
rsconnect::writeManifest()


# Open 02_dev.R ----
rstudioapi::navigateToFile("dev/02_dev.R")


# Open run_dev.R ----
rstudioapi::navigateToFile("dev/run_dev.R")
